import React, { useState } from 'react';
import {
  Shield,
  Users,
  Tag,
  Plus,
  Trash2,
  Check,
  X,
  Printer,
  Clock,
  AlertCircle,
  MapPin,
  TrendingUp,
  Percent,
  ShoppingBag,
  Eye,
  Settings,
  BarChart3,
  Package,
  FileText,
  Truck,
  CreditCard,
  Megaphone,
  Briefcase,
  ChevronRight,
  MessageSquare,
  HelpCircle,
  Upload,
  Download,
  Search
} from 'lucide-react';
import { Product, Order, User, Coupon, Employee, ShippingMethod, PaymentGateway, AbandonedCart, Category, OrderStatus, UserRole, Banner, Inquiry, StoreSettings } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import ImageUploader from './ImageUploader';
import { getAllUsers, updateUserRoleInFirestore } from '../lib/authService';

interface AdminPanelProps {
  products: Product[];
  orders: Order[];
  vendors: User[];
  coupons: Coupon[];
  employees: Employee[];
  shippingMethods: ShippingMethod[];
  paymentGateways: PaymentGateway[];
  abandonedCarts: AbandonedCart[];
  currentRole: UserRole;
  activeEmployeeId: string;
  onVerifyVendor: (vendorId: string) => void;
  onUpdateVendorCommission: (vendorId: string, rate: number) => void;
  onAddCoupon: (newCoupon: Coupon) => void;
  onDeleteCoupon: (code: string) => void;
  onAddEmployee: (emp: Employee) => void;
  onDeleteEmployee: (id: string) => void;
  onUpdateShippingMethod: (id: string, updated: Partial<ShippingMethod>) => void;
  onUpdatePaymentGateway: (id: string, updated: Partial<PaymentGateway>) => void;
  onAddPaymentGateway: (newGateway: PaymentGateway) => void;
  onDeletePaymentGateway: (id: string) => void;
  onSendCartReminder: (id: string) => void;
  onUpdateOrderStatus: (orderId: string, status: OrderStatus, cancelReason?: string) => void;
  onAddProduct: (newProductData: any) => Promise<void>;
  onEditProduct: (updatedProduct: Product) => Promise<void>;
  onDeleteProduct: (productId: string) => Promise<void>;
  onOpenChat: (customerId: string, productTitle?: string, productId?: string) => void;
  categories: Category[];
  onAddCategory: (name: string, slug: string) => void;
  banners: Banner[];
  onUpdateBanners: (banners: Banner[]) => void;
  onAddNotification: (title: string, message: string, type: 'order' | 'offer' | 'system' | 'chat') => void;
  inquiries: Inquiry[];
  onMarkInquiryRead: (id: string) => void;
  onDeleteInquiry: (id: string) => void;
  storeSettings: StoreSettings;
  onUpdateStoreSettings: (settings: Partial<StoreSettings>) => void;
}

export default function AdminPanel({
  products,
  orders,
  vendors,
  coupons,
  employees,
  shippingMethods,
  paymentGateways,
  abandonedCarts,
  currentRole,
  activeEmployeeId,
  onVerifyVendor,
  onUpdateVendorCommission,
  onAddCoupon,
  onDeleteCoupon,
  onAddEmployee,
  onDeleteEmployee,
  onUpdateShippingMethod,
  onUpdatePaymentGateway,
  onAddPaymentGateway,
  onDeletePaymentGateway,
  onSendCartReminder,
  onUpdateOrderStatus,
  onAddProduct,
  onEditProduct,
  onDeleteProduct,
  onOpenChat,
  categories,
  onAddCategory,
  banners = [],
  onUpdateBanners,
  onAddNotification,
  inquiries = [],
  onMarkInquiryRead,
  onDeleteInquiry,
  storeSettings,
  onUpdateStoreSettings,
}: AdminPanelProps) {
  const activeEmp = employees.find(e => e.id === activeEmployeeId);
  const isEmployee = currentRole === 'employee';
  const employeePermission = isEmployee ? activeEmp?.permission : null;

  // Tabs switching logic depending on permissions
  const getAvailableTabs = () => {
    if (!isEmployee) {
      return [
        { id: 'reports', label: 'التقارير والإحصائيات', icon: BarChart3 },
        { id: 'products', label: 'المنتجات والتصنيفات', icon: Package },
        { id: 'orders', label: 'إدارة الطلبات والصفقات', icon: FileText },
        { id: 'customers', label: 'قاعدة بيانات العملاء', icon: Users },
        { id: 'shipping_payment', label: 'الشحن ووسائل الدفع', icon: Truck },
        { id: 'marketing', label: 'التسويق والسلات المتروكة', icon: Megaphone },
        { id: 'banners_offers', label: 'إدارة البنرات والعروض', icon: Megaphone },
        { id: 'notifications', label: 'إدارة الإشعارات', icon: MessageSquare },
        { id: 'inquiries', label: 'استفسارات نموذج الاتصال', icon: HelpCircle },
        { id: 'store_settings', label: 'إعدادات المتجر والـ CSS', icon: Settings },
        { id: 'staff', label: 'الموظفين والصلاحيات', icon: Briefcase },
      ];
    }

    // Filtered tabs for employee simulation
    const tabs = [];
    if (employeePermission === 'products') {
      tabs.push({ id: 'products', label: 'إدارة المنتجات والتصنيفات', icon: Package });
    } else if (employeePermission === 'orders') {
      tabs.push({ id: 'orders', label: 'إدارة الطلبات والصفقات', icon: FileText });
    } else if (employeePermission === 'customers') {
      tabs.push({ id: 'customers', label: 'قاعدة بيانات العملاء', icon: Users });
      tabs.push({ id: 'inquiries', label: 'استفسارات نموذج الاتصال', icon: HelpCircle });
    } else if (employeePermission === 'marketing') {
      tabs.push({ id: 'marketing', label: 'التسويق والسلات المتروكة', icon: Megaphone });
    }
    return tabs;
  };

  const availableTabs = getAvailableTabs();
  const [activeTab, setActiveTab] = useState(availableTabs[0]?.id || 'reports');

  // Order search state and deep link listener
  const [orderSearchQuery, setOrderSearchQuery] = useState('');

  React.useEffect(() => {
    const handleDeepLink = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (detail && detail.orderId) {
        setActiveTab('orders');
        setOrderSearchQuery(detail.orderId);
        
        // Highlight order element if visible
        setTimeout(() => {
          const orderRow = document.getElementById(`admin-order-row-${detail.orderId}`);
          if (orderRow) {
            orderRow.scrollIntoView({ behavior: 'smooth', block: 'center' });
            orderRow.classList.add('bg-amber-500/10', 'border-amber-500', 'ring-2', 'ring-amber-500/25');
            setTimeout(() => {
              orderRow.classList.remove('bg-amber-500/10', 'border-amber-500', 'ring-2', 'ring-amber-500/25');
            }, 5000);
          }
        }, 300);
      }
    };
    window.addEventListener('open_order_deep_link', handleDeepLink);
    return () => window.removeEventListener('open_order_deep_link', handleDeepLink);
  }, []);

  // Firestore User Management States
  const [firestoreUsers, setFirestoreUsers] = useState<User[]>([]);
  const [userSearchQuery, setUserSearchQuery] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState<'all' | 'admin' | 'employee' | 'customer'>('all');
  const [loadingUsers, setLoadingUsers] = useState(false);

  const fetchFirestoreUsers = async () => {
    setLoadingUsers(true);
    try {
      const usersList = await getAllUsers();
      setFirestoreUsers(usersList);
    } catch (err) {
      console.error('Error fetching users:', err);
    } finally {
      setLoadingUsers(false);
    }
  };

  React.useEffect(() => {
    if (activeTab === 'staff') {
      fetchFirestoreUsers();
    }
  }, [activeTab]);

  // Auto adjust tab if current selection is not available for employee
  React.useEffect(() => {
    if (availableTabs.length > 0 && !availableTabs.some(t => t.id === activeTab)) {
      setActiveTab(availableTabs[0].id);
    }
  }, [currentRole, activeEmployeeId]);

  // Modals for Printing
  const [printingOrder, setPrintingOrder] = useState<Order | null>(null);
  const [printType, setPrintType] = useState<'invoice' | 'shipping_label' | null>(null);

  // Stats Calculations
  const totalGMV = orders
    .filter(o => o.status !== 'cancelled')
    .reduce((acc, o) => acc + o.finalPrice, 0);

  const totalCommission = orders
    .filter(o => o.status !== 'cancelled')
    .reduce((acc, o) => acc + o.commissionEarned, 0);

  const completedOrders = orders.filter(o => o.status === 'delivered').length;
  const pendingOrders = orders.filter(o => o.status === 'pending').length;

  // New Category States
  const [newCatName, setNewCatName] = useState('');
  const [newCatSlug, setNewCatSlug] = useState('');

  // New Employee States
  const [newEmpName, setNewEmpName] = useState('');
  const [newEmpEmail, setNewEmpEmail] = useState('');
  const [newEmpPerm, setNewEmpPerm] = useState<'products' | 'orders' | 'customers' | 'marketing'>('products');

  // New Shipping States
  const [newShipName, setNewShipName] = useState('');
  const [newShipCost, setNewShipCost] = useState('');
  const [newShipTime, setNewShipTime] = useState('');
  const [newShipRegions, setNewShipRegions] = useState('');

  // New Product Form States
  const [productToDelete, setProductToDelete] = useState<string | null>(null);
  const [gatewayToDelete, setGatewayToDelete] = useState<string | null>(null);
  const [employeeToDelete, setEmployeeToDelete] = useState<string | null>(null);
  const [userToPromote, setUserToPromote] = useState<string | null>(null);

  const [isProductFormOpen, setIsProductFormOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [prodTitle, setProdTitle] = useState('');
  const [prodDesc, setProdDesc] = useState('');
  const [prodPrice, setProdPrice] = useState('');
  const [prodOrigPrice, setProdOrigPrice] = useState('');
  const [prodCategory, setProdCategory] = useState(categories[0]?.slug || '');
  const [prodStock, setProdStock] = useState('');
  const [prodImage, setProdImage] = useState('');
  const [prodYoutubeUrl, setProdYoutubeUrl] = useState('');
  const [prodNotes, setProdNotes] = useState('');
  const [prodOptionsText, setProdOptionsText] = useState('');
  const [prodWeight, setProdWeight] = useState('');
  const [prodAdditionalImages, setProdAdditionalImages] = useState<string[]>([]);
  const [imageSourceTab, setImageSourceTab] = useState<'upload' | 'url'>('upload');
  const [bannerImage, setBannerImage] = useState('');
  const [bannerImageSourceTab, setBannerImageSourceTab] = useState<'upload' | 'url'>('upload');

  const [storeLogoUrl, setStoreLogoUrl] = useState(storeSettings?.logo || '👑');
  const [storeLogoSourceTab, setStoreLogoSourceTab] = useState<'upload' | 'url'>('url');
  const [storeThemeColor, setStoreThemeColor] = useState(storeSettings?.themeColor || '#f59e0b');

  const [newPayName, setNewPayName] = useState('');
  const [newPayLogo, setNewPayLogo] = useState('');
  const [newPayLogoSourceTab, setNewPayLogoSourceTab] = useState<'upload' | 'url'>('url');
  const [newPayAccount, setNewPayAccount] = useState('');
  const [newPayInstructions, setNewPayInstructions] = useState('');
  const [isAddingGateway, setIsAddingGateway] = useState(false);

  const parseOptionsText = (text: string) => {
    if (!text.trim()) return [];
    const lines = text.split('\n');
    const parsed: { name: string, values: string[] }[] = [];
    lines.forEach(line => {
      const parts = line.split(':');
      if (parts.length >= 2) {
        const name = parts[0].trim();
        const vals = parts[1].split(/[،,]/).map(v => v.trim()).filter(v => v.length > 0);
        if (name && vals.length > 0) {
          parsed.push({ name, values: vals });
        }
      }
    });
    return parsed;
  };

  const formatOptionsToText = (options?: { name: string, values: string[] }[]) => {
    if (!options || options.length === 0) return '';
    return options.map(opt => `${opt.name}: ${opt.values.join('، ')}`).join('\n');
  };

  // Custom commission rate edit states
  const [editingCommissionId, setEditingCommissionId] = useState<string | null>(null);
  const [customRateInput, setCustomRateInput] = useState('');

  // Coupon Form States
  const [isCouponFormOpen, setIsCouponFormOpen] = useState(false);
  const [couponCode, setCouponCode] = useState('');
  const [discountType, setDiscountType] = useState<'percentage' | 'fixed'>('percentage');
  const [couponValue, setCouponValue] = useState('');
  const [minSpend, setMinSpend] = useState('');

  // Toast message simulation
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleAddCategorySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName || !newCatSlug) return;
    onAddCategory(newCatName, newCatSlug);
    setNewCatName('');
    setNewCatSlug('');
    triggerToast('تمت إضافة التصنيف بنجاح 🎉');
  };

  const handleAddEmployeeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmpName || !newEmpEmail) return;
    onAddEmployee({
      id: `emp_${Date.now()}`,
      name: newEmpName,
      email: newEmpEmail,
      permission: newEmpPerm,
      joinedDate: new Date().toISOString().split('T')[0]
    });
    setNewEmpName('');
    setNewEmpEmail('');
    triggerToast('تم تسجيل الموظف الجديد ومنحه الصلاحيات 💼');
  };

  const handleAddShippingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newShipName || !newShipCost) return;
    onUpdateShippingMethod(`ship_${Date.now()}`, {
      name: newShipName,
      cost: parseFloat(newShipCost),
      deliveryTime: newShipTime || '2-3 أيام',
      regions: newShipRegions ? newShipRegions.split(',').map(r => r.trim()) : ['جميع المحافظات'],
      isActive: true
    });
    setNewShipName('');
    setNewShipCost('');
    setNewShipTime('');
    setNewShipRegions('');
    triggerToast('تم إضافة شركة توصيل جديدة 🚚');
  };

  const handleSaveCommission = (vendorId: string) => {
    const rate = parseInt(customRateInput);
    if (!isNaN(rate) && rate >= 0 && rate <= 100) {
      onUpdateVendorCommission(vendorId, rate);
      triggerToast('تم تعديل عمولة المتجر بنجاح ⚙️');
    }
    setEditingCommissionId(null);
  };

  const handleCreateCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponCode.trim() || !couponValue.trim()) return;

    onAddCoupon({
      code: couponCode.trim().toUpperCase(),
      discountType,
      value: parseFloat(couponValue),
      minSpend: minSpend ? parseFloat(minSpend) : undefined,
      isActive: true,
    });

    setCouponCode('');
    setCouponValue('');
    setMinSpend('');
    setIsCouponFormOpen(false);
    triggerToast('تم إطلاق الكوبون التسويقي بنجاح 🏷');
  };

  const handleProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prodTitle || !prodPrice || !prodStock) return;

    const imagesArray = [
      prodImage || 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=500',
      ...prodAdditionalImages
    ].filter(Boolean);

    const data = {
      title: prodTitle,
      description: prodDesc,
      price: parseFloat(prodPrice),
      originalPrice: prodOrigPrice ? parseFloat(prodOrigPrice) : undefined,
      images: imagesArray,
      category: prodCategory,
      stock: parseInt(prodStock),
      youtubeUrl: prodYoutubeUrl || undefined,
      notes: prodNotes || undefined,
      options: parseOptionsText(prodOptionsText),
      weight: prodWeight ? parseFloat(prodWeight) : undefined
    };

    try {
      if (editingProduct) {
        await onEditProduct({
          ...editingProduct,
          ...data
        });
        triggerToast('تم تحديث بيانات السلعة بنجاح 📦');
      } else {
        await onAddProduct(data);
        triggerToast('تم إضافة السلعة الجديدة للمتجر العام 📦');
      }

      setEditingProduct(null);
      setProdTitle('');
      setProdDesc('');
      setProdPrice('');
      setProdOrigPrice('');
      setProdStock('');
      setProdImage('');
      setProdYoutubeUrl('');
      setProdNotes('');
      setProdOptionsText('');
      setProdWeight('');
      setProdAdditionalImages([]);
      setImageSourceTab('upload');
      setIsProductFormOpen(false);
    } catch (error) {
      console.error('[AdminPanel] Error saving product:', error);
      triggerToast('خطأ: فشل حفظ السلعة في قاعدة البيانات ⚠️');
    }
  };

  const handleEditProductClick = (prod: Product) => {
    setEditingProduct(prod);
    setProdTitle(prod.title);
    setProdDesc(prod.description);
    setProdPrice(prod.price.toString());
    setProdOrigPrice(prod.originalPrice ? prod.originalPrice.toString() : '');
    setProdCategory(prod.category);
    setProdStock(prod.stock.toString());
    const firstImg = (prod.images && prod.images[0]) || '';
    setProdImage(firstImg);
    setProdAdditionalImages(prod.images ? prod.images.slice(1) : []);
    setImageSourceTab(firstImg.startsWith('data:') || !firstImg ? 'upload' : 'url');
    setProdYoutubeUrl(prod.youtubeUrl || '');
    setProdNotes(prod.notes || '');
    setProdWeight(prod.weight ? prod.weight.toString() : '');
    setProdOptionsText(formatOptionsToText(prod.options));
    setIsProductFormOpen(true);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPDF = () => {
    if (!printingOrder) return;
    const element = document.getElementById('printable-area');
    if (!element) return;

    const opt = {
      margin:       [10, 10, 10, 10],
      filename:     `فاتورة_طلب_${printingOrder.id}.pdf`,
      image:        { type: 'jpeg', quality: 0.98 },
      html2canvas:  { 
        scale: 2.5, 
        useCORS: true,
        letterRendering: true,
        scrollX: 0,
        scrollY: 0
      },
      jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };

    triggerToast('⏳ جاري إعداد وتصدير ملف الـ PDF بألوان الهوية البصرية...');

    if ((window as any).html2pdf) {
      (window as any).html2pdf().from(element).set(opt).save()
        .then(() => {
          triggerToast('✅ تم تحميل فاتورة الـ PDF بنجاح!');
        })
        .catch((err: any) => {
          console.error('PDF Generation Error:', err);
          triggerToast('❌ فشل تصدير الـ PDF، جاري استخدام الطباعة المباشرة كبديل');
          window.print();
        });
    } else {
      triggerToast('⚠️ أداة الـ PDF غير مستعدة بالكامل بعد، جاري فتح الطباعة المباشرة...');
      window.print();
    }
  };

  return (
    <div id="admin-panel-workspace" className="max-w-7xl mx-auto px-4 py-8 space-y-8 text-right w-full min-h-screen" dir="rtl">
      {/* Toast Alert Banner */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-20 left-1/2 -translate-x-1/2 bg-zinc-950 text-white font-bold text-xs px-6 py-3.5 rounded-full shadow-2xl z-50 flex items-center gap-2 border border-zinc-800"
          >
            <span>✨</span>
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Overview/Permission Header */}
      <div className="bg-white p-6 rounded-3xl border border-zinc-150 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl md:text-2xl font-black text-zinc-950 flex items-center gap-2">
            <Shield className="w-6 h-6 text-amber-500" />
            <span>
              {isEmployee
                ? `لوحة الموظف: ${activeEmp?.name} (${activeEmp?.permission === 'products' ? 'إدارة المنتجات' : activeEmp?.permission === 'orders' ? 'إدارة الطلبات' : activeEmp?.permission === 'customers' ? 'خدمة العملاء' : 'التسويق'})`
                : 'غرفة القيادة العامة للمنصة (المدير الرئيسي)'}
            </span>
          </h2>
          <p className="text-zinc-500 text-xs mt-1">
            {isEmployee
              ? `صلاحياتك محدودة بـ "${activeEmp?.permission === 'products' ? 'تعديل السلع والتصنيفات' : activeEmp?.permission === 'orders' ? 'إصدار بوليصات الشحن والفواتير وتحديث الطلبات' : activeEmp?.permission === 'customers' ? 'قاعدة بيانات العملاء والدعم المباشر' : 'إدارة الحملات الترويجية والكوبونات والسلات المتروكة'}" كجزء من موظفي متجر سلة اليمن.`
              : 'مرحباً بك مجدداً. تملك صلاحيات مطلقة للتحكم الكامل بالتصنيفات، المبيعات، توثيق البائعين، العمولات، شاشات الشحن والدفع، والموظفين.'}
          </p>
        </div>

        {/* Quick Identity Badge */}
        <div className="flex items-center gap-2.5 bg-zinc-50 px-4 py-2 rounded-2xl border border-zinc-150">
          <div className="w-8 h-8 rounded-full bg-amber-500/10 text-amber-600 flex items-center justify-center font-bold">
            👤
          </div>
          <div>
            <span className="text-[10px] text-zinc-400 block">الصفة الحالية</span>
            <span className="text-xs font-extrabold text-zinc-950">
              {isEmployee ? `موظف مبيعات` : 'مدير رئيسي (مالك المنصة)'}
            </span>
          </div>
        </div>
      </div>

      {/* Tabs Navigation Rail */}
      <div className="flex gap-2 border-b border-zinc-150 pb-2 mb-4 overflow-x-auto">
        {availableTabs.map((tab) => {
          const IconComponent = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-zinc-950 text-white shadow-md'
                  : 'text-zinc-500 hover:text-zinc-900 hover:bg-zinc-100'
              }`}
            >
              <IconComponent className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB CONTENT RENDERING */}

      {/* 1. REPORTS & STATS TAB */}
      {activeTab === 'reports' && !isEmployee && (
        <div className="space-y-6">
          {/* Main Cards Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-zinc-950 text-white p-5 rounded-2xl border border-zinc-800 shadow-sm relative overflow-hidden">
              <div className="absolute top-0 left-0 translate-x-2 translate-y-1 text-5xl opacity-5">💰</div>
              <span className="text-[10px] text-zinc-400 block font-bold">إجمالي أرباح متجر مها الصافية</span>
              <span className="text-lg font-black text-amber-400 font-mono mt-1 block">
                {Math.round(totalGMV * 0.35).toLocaleString()} <span className="text-[10px] text-zinc-300">ر.ي</span>
              </span>
              <span className="text-[9px] text-emerald-400 block mt-1.5 font-bold">✓ عوائد مستقرة من مبيعات متجر مها المباشرة</span>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-zinc-150 shadow-xs">
              <span className="text-[10px] text-zinc-500 block font-bold">مبيعات متجر مها الإجمالية</span>
              <span className="text-lg font-black text-zinc-950 font-mono mt-1 block">
                {totalGMV.toLocaleString()} <span className="text-[10px] text-zinc-500">ر.ي</span>
              </span>
              <span className="text-[9px] text-zinc-400 block mt-1.5">شاملاً كافة الأقسام والتصنيفات المتاحة</span>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-zinc-150 shadow-xs">
              <span className="text-[10px] text-zinc-500 block font-bold">معدل قيمة السلة (AOV)</span>
              <span className="text-lg font-black text-zinc-950 font-mono mt-1 block">
                {orders.length > 0 ? Math.round(totalGMV / orders.length).toLocaleString() : 0} <span className="text-[10px] text-zinc-500">ر.ي</span>
              </span>
              <span className="text-[9px] text-emerald-600 block mt-1.5 font-bold">📈 نمو بنسبة 4% عن الشهر السابق</span>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-zinc-150 shadow-xs">
              <span className="text-[10px] text-zinc-500 block font-bold font-sans">إجمالي الطلبات (المنجزة / الكلية)</span>
              <span className="text-lg font-black text-zinc-950 font-mono mt-1 block">
                {completedOrders} / {orders.length} <span className="text-[10px] text-zinc-500">طلبيات</span>
              </span>
              <span className="text-[9px] text-zinc-400 block mt-1.5">يوجد حالياً {pendingOrders} طلب بانتظار الشحن</span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Visitors & Orders Graph Simulation */}
            <div className="lg:col-span-8 bg-white p-6 rounded-3xl border border-zinc-150 space-y-4">
              <h3 className="font-extrabold text-sm text-zinc-950 flex items-center gap-1.5">
                <TrendingUp className="w-4.5 h-4.5 text-amber-500" />
                <span>إحصائيات المبيعات الأسبوعية لمتجر مها</span>
              </h3>
              <p className="text-[10px] text-zinc-400">رسم بياني توضيحي لمعدل الطلبيات والصفقات الناجحة خلال الـ 7 أيام الماضية</p>
              
              {/* Graphical simulation bars */}
              <div className="h-52 flex items-end justify-between gap-1.5 sm:gap-3 md:gap-4 pt-6 pb-2 border-b border-zinc-100 px-1 sm:px-4 overflow-x-auto min-w-0">
                {[
                  { day: 'السبت', val: 120000, color: 'bg-zinc-800' },
                  { day: 'الأحد', val: 95000, color: 'bg-zinc-600' },
                  { day: 'الإثنين', val: 180000, color: 'bg-amber-500' },
                  { day: 'الثلاثاء', val: 240000, color: 'bg-zinc-900' },
                  { day: 'الأربعاء', val: 150000, color: 'bg-zinc-700' },
                  { day: 'الخميس', val: 320000, color: 'bg-zinc-950' },
                  { day: 'الجمعة', val: 410000, color: 'bg-amber-600' },
                ].map((item, i) => {
                  const percent = Math.min(100, Math.round((item.val / 410000) * 100));
                  return (
                    <div key={i} className="flex flex-col items-center gap-2 flex-grow h-full justify-end">
                      <span className="text-[9px] font-bold font-mono text-zinc-600">{(item.val / 1000)}k</span>
                      <div
                        className={`w-full rounded-t-lg transition-all ${item.color}`}
                        style={{ height: `${percent}%` }}
                      ></div>
                      <span className="text-[10px] font-extrabold text-zinc-500">{item.day}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Best Sellers sidepanel */}
            <div className="lg:col-span-4 bg-white p-6 rounded-3xl border border-zinc-150 space-y-4">
              <h3 className="font-extrabold text-sm text-zinc-950 flex items-center gap-1.5">
                <span>🔥 المنتجات الأكثر مبيعاً ورواجاً</span>
              </h3>
              <div className="space-y-4 pt-2">
                {products
                  .sort((a, b) => b.salesCount - a.salesCount)
                  .slice(0, 4)
                  .map((p, idx) => (
                    <div key={p.id} className="flex gap-2.5 items-center justify-between">
                      <div className="flex gap-2 items-center min-w-0">
                        <img
                          src={p.images?.[0] || 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=600'}
                          alt=""
                          className="w-10 h-10 rounded-lg object-cover border border-zinc-150 flex-shrink-0"
                        />
                        <div className="min-w-0">
                          <h4 className="font-bold text-zinc-900 text-xs truncate leading-normal">{p.title}</h4>
                          <span className="text-[10px] text-zinc-400 block">{p.vendorName}</span>
                        </div>
                      </div>
                      <div className="text-left flex-shrink-0">
                        <span className="text-xs font-black text-zinc-950 font-mono">{p.salesCount}</span>
                        <span className="text-[9px] text-zinc-400 block">صفقة ناجحة</span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </div>

          {/* Maha Store status and local payment accounts */}
          <div className="bg-white p-6 rounded-3xl border border-zinc-150 space-y-4">
            <h3 className="font-extrabold text-sm text-zinc-950 flex items-center gap-1.5">
              <span>🛡️ بوابات وحسابات الدفع المحلية لمتجر مها</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="border border-zinc-150 p-4 rounded-2xl flex justify-between items-center bg-zinc-50/50">
                <div className="flex gap-3 items-center">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center font-bold text-amber-700">الكريمي</div>
                  <div>
                    <h4 className="font-bold text-xs text-zinc-900">بنك الكريمي الإسلامي</h4>
                    <p className="text-[10px] text-zinc-500 mt-1">حساب رقم: <span className="font-mono font-bold">12345678</span> • باسم: مها أحمد الصنعاني</p>
                  </div>
                </div>
                <span className="bg-emerald-50 text-emerald-600 text-[9px] font-bold px-2 py-0.5 rounded">نشط</span>
              </div>

              <div className="border border-zinc-150 p-4 rounded-2xl flex justify-between items-center bg-zinc-50/50">
                <div className="flex gap-3 items-center">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center font-bold text-amber-700">جيب</div>
                  <div>
                    <h4 className="font-bold text-xs text-zinc-900">محفظة جيب الإلكترونية</h4>
                    <p className="text-[10px] text-zinc-500 mt-1">حساب رقم: <span className="font-mono font-bold">777000111</span> • باسم: متجر مها للأناقة</p>
                  </div>
                </div>
                <span className="bg-emerald-50 text-emerald-600 text-[9px] font-bold px-2 py-0.5 rounded">نشط</span>
              </div>

              <div className="border border-zinc-150 p-4 rounded-2xl flex justify-between items-center bg-zinc-50/50">
                <div className="flex gap-3 items-center">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center font-bold text-amber-700">تحويل</div>
                  <div>
                    <h4 className="font-bold text-xs text-zinc-900">التحويل البنكي المباشر</h4>
                    <p className="text-[10px] text-zinc-500 mt-1">حساب التضامن رقم: <span className="font-mono font-bold">99988822</span> • باسم: متجر مها</p>
                  </div>
                </div>
                <span className="bg-zinc-100 text-zinc-500 text-[9px] font-bold px-2 py-0.5 rounded">معطل مؤقتاً</span>
              </div>

              <div className="border border-zinc-150 p-4 rounded-2xl flex justify-between items-center bg-zinc-50/50">
                <div className="flex gap-3 items-center">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center font-bold text-amber-700">COD</div>
                  <div>
                    <h4 className="font-bold text-xs text-zinc-900">الدفع عند الاستلام</h4>
                    <p className="text-[10px] text-zinc-500 mt-1">متاح لجميع المدن: صنعاء، عدن، تعز، حضرموت، إلخ.</p>
                  </div>
                </div>
                <span className="bg-emerald-50 text-emerald-600 text-[9px] font-bold px-2 py-0.5 rounded">نشط</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. PRODUCTS & CATEGORIES TAB */}
      {activeTab === 'products' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center border-b border-zinc-150 pb-3">
            <h3 className="font-extrabold text-sm text-zinc-950 flex items-center gap-1.5">
              <Package className="w-4.5 h-4.5 text-amber-500" />
              <span>إدارة المنتجات والتصنيفات في المعرض ({products.length})</span>
            </h3>

            <button
              onClick={() => {
                setEditingProduct(null);
                setProdTitle('');
                setProdDesc('');
                setProdPrice('');
                setProdOrigPrice('');
                setProdStock('');
                setProdImage('');
                setIsProductFormOpen(true);
              }}
              className="bg-zinc-950 hover:bg-zinc-800 text-white font-bold text-xs py-2 px-4 rounded-xl flex items-center gap-1 shadow-sm cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة سلعة جديدة للمنصة</span>
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Products Table (col-span-8) */}
            <div className="lg:col-span-8 bg-white rounded-2xl border border-zinc-150 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead>
                    <tr className="bg-zinc-50 text-zinc-500 border-b border-zinc-150">
                      <th className="p-3 font-bold">المنتج</th>
                      <th className="p-3 font-bold">التصنيف</th>
                      <th className="p-3 font-bold">السعر (ر.ي)</th>
                      <th className="p-3 font-bold">المخزون</th>
                      <th className="p-3 font-bold">المبيعات</th>
                      <th className="p-3 font-bold text-left">التحكم</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-100 text-zinc-700">
                    {products.map((p) => (
                      <tr key={p.id} className="hover:bg-zinc-50/50">
                        <td className="p-3 flex items-center gap-2.5">
                          <img src={p.images?.[0] || 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=600'} alt="" className="w-9 h-9 rounded-lg object-cover border border-zinc-150" />
                          <div className="min-w-0">
                            <h4 className="font-bold text-zinc-900 truncate max-w-40">{p.title}</h4>
                            <span className="text-[10px] text-zinc-400 block">{p.vendorName}</span>
                          </div>
                        </td>
                        <td className="p-3 font-bold text-zinc-600">
                          {categories.find(c => c.slug === p.category)?.name || p.category}
                        </td>
                        <td className="p-3 font-bold font-mono text-zinc-950">{(p.price ?? 0).toLocaleString()}</td>
                        <td className="p-3">
                          {p.stock <= 3 ? (
                            <span className="text-red-500 font-bold bg-red-50 px-1.5 py-0.5 rounded text-[10px]">
                              شبه نافذ ({p.stock})
                            </span>
                          ) : (
                            <span className="text-zinc-600 font-bold font-mono">{p.stock} قطعة</span>
                          )}
                        </td>
                        <td className="p-3 font-mono font-bold">{p.salesCount} صفقة</td>
                        <td className="p-3 text-left space-x-1.5 space-x-reverse">
                          <button
                            onClick={() => handleEditProductClick(p)}
                            className="text-amber-600 font-bold text-[11px] hover:underline cursor-pointer"
                          >
                            تعديل
                          </button>
                          {productToDelete === p.id ? (
                            <span className="inline-flex items-center gap-1">
                              <button
                                onClick={async () => {
                                  try {
                                    await onDeleteProduct(p.id);
                                    triggerToast('تم حذف السلعة من المتجر بنجاح 🗑');
                                    setProductToDelete(null);
                                  } catch (error) {
                                    console.error('[AdminPanel] Error deleting product:', error);
                                    triggerToast('خطأ: فشل حذف السلعة من قاعدة البيانات ⚠️');
                                  }
                                }}
                                className="text-red-600 bg-red-50 hover:bg-red-100 px-1.5 py-0.5 rounded text-[10px] font-black cursor-pointer"
                              >
                                نعم، احذف
                              </button>
                              <button
                                onClick={() => setProductToDelete(null)}
                                className="text-zinc-500 bg-zinc-100 hover:bg-zinc-200 px-1.5 py-0.5 rounded text-[10px] font-bold cursor-pointer"
                              >
                                إلغاء
                              </button>
                            </span>
                          ) : (
                            <button
                              onClick={() => setProductToDelete(p.id)}
                              className="text-red-500 font-bold text-[11px] hover:underline cursor-pointer"
                            >
                              حذف
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Categories Administration (col-span-4) */}
            <div className="lg:col-span-4 space-y-6">
              <div className="bg-white p-5 rounded-3xl border border-zinc-150 space-y-4">
                <h4 className="font-black text-xs text-zinc-900 flex items-center gap-1 border-b border-zinc-100 pb-2">
                  <span>✨ إضافة تصنيف منتجات جديد</span>
                </h4>
                <form onSubmit={handleAddCategorySubmit} className="space-y-3">
                  <div>
                    <label className="text-[10px] text-zinc-400 font-bold block mb-1">اسم التصنيف باللغة العربية *</label>
                    <input
                      type="text"
                      required
                      placeholder="مثال: ساعات ونظارات"
                      value={newCatName}
                      onChange={(e) => setNewCatName(e.target.value)}
                      className="w-full text-xs p-2 rounded-xl border border-zinc-200 focus:outline-none focus:border-amber-500 text-right bg-zinc-50"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-zinc-400 font-bold block mb-1">رمز التصنيف (أحرف إنجليزية - Slug) *</label>
                    <input
                      type="text"
                      required
                      placeholder="مثال: watches"
                      value={newCatSlug}
                      onChange={(e) => setNewCatSlug(e.target.value)}
                      className="w-full text-xs p-2 rounded-xl border border-zinc-200 focus:outline-none focus:border-amber-500 text-left font-mono bg-zinc-50"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-zinc-950 text-white text-xs font-bold py-2 rounded-xl transition-all hover:bg-amber-500 hover:text-zinc-950 cursor-pointer"
                  >
                    تفعيل التصنيف الجديد
                  </button>
                </form>
              </div>

              {/* Active Categories List */}
              <div className="bg-white p-5 rounded-3xl border border-zinc-150 space-y-3">
                <h4 className="font-bold text-xs text-zinc-900 border-b border-zinc-100 pb-2">التصنيفات المفعلة حالياً ({categories.length})</h4>
                <div className="space-y-2">
                  {categories.map(cat => (
                    <div key={cat.id} className="flex justify-between items-center text-xs bg-zinc-50 p-2.5 rounded-xl border border-zinc-100">
                      <span className="font-bold text-zinc-800">{cat.name}</span>
                      <span className="font-mono text-[10px] text-zinc-400 bg-white px-2 py-0.5 rounded border border-zinc-150">{cat.slug}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* New Product Form Popup / Dialog Overlay */}
          {isProductFormOpen && (
            <div className="fixed inset-0 bg-zinc-950/40 backdrop-blur-xs flex items-center justify-center z-50 p-4">
              <motion.div
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-zinc-150 max-h-[85vh] overflow-y-auto space-y-4"
              >
                <div className="flex justify-between items-center border-b border-zinc-100 pb-3">
                  <h4 className="font-black text-sm text-zinc-950">
                    {editingProduct ? `تعديل السلعة: ${editingProduct.title}` : 'إضافة سلعة جديدة للمنصة'}
                  </h4>
                  <button onClick={() => setIsProductFormOpen(false)} className="text-zinc-400 hover:text-zinc-900 cursor-pointer">
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <form onSubmit={handleProductSubmit} className="space-y-3">
                  <div>
                    <label className="text-[10px] text-zinc-400 font-bold block mb-1">اسم السلعة / المنتج *</label>
                    <input
                      type="text"
                      required
                      value={prodTitle}
                      onChange={(e) => setProdTitle(e.target.value)}
                      className="w-full text-xs p-2.5 rounded-xl border border-zinc-200"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] text-zinc-400 font-bold block mb-1">وصف المنتج وتفاصيله *</label>
                    <textarea
                      required
                      value={prodDesc}
                      onChange={(e) => setProdDesc(e.target.value)}
                      className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 h-20"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] text-zinc-400 font-bold block mb-1">السعر الفعلي (ر.ي) *</label>
                      <input
                        type="number"
                        required
                        value={prodPrice}
                        onChange={(e) => setProdPrice(e.target.value)}
                        className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 font-mono text-left"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-zinc-400 font-bold block mb-1">السعر قبل الخصم (اختياري)</label>
                      <input
                        type="number"
                        value={prodOrigPrice}
                        onChange={(e) => setProdOrigPrice(e.target.value)}
                        className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 font-mono text-left"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="text-[10px] text-zinc-400 font-bold block mb-1">التصنيف *</label>
                      <select
                        value={prodCategory}
                        onChange={(e) => setProdCategory(e.target.value)}
                        className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white"
                      >
                        {categories.map(c => (
                          <option key={c.slug} value={c.slug}>{c.name}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="text-[10px] text-zinc-400 font-bold block mb-1">المخزون المتوفر *</label>
                      <input
                        type="number"
                        required
                        value={prodStock}
                        onChange={(e) => setProdStock(e.target.value)}
                        className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 font-mono text-left bg-zinc-50 focus:bg-white"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-zinc-400 font-bold block mb-1">الوزن (جرام/كجم)</label>
                      <input
                        type="text"
                        placeholder="مثال: 500 جرام"
                        value={prodWeight}
                        onChange={(e) => setProdWeight(e.target.value)}
                        className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 font-mono text-left bg-zinc-50 focus:bg-white"
                      />
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="space-y-1.5">
                      <label className="text-[10px] text-zinc-400 font-bold block">صورة المنتج الرئيسية *</label>
                      <ImageUploader
                        value={prodImage}
                        onChange={(val) => setProdImage(val)}
                        placeholderUrl="https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=500"
                      />
                    </div>

                    <div className="space-y-2 border-t border-zinc-100 pt-3">
                      <div className="flex justify-between items-center">
                        <label className="text-[10px] text-zinc-400 font-bold block">صور إضافية للمنتج (معاينة الصور قبل الحفظ)</label>
                        <span className="text-[9px] text-zinc-500">{prodAdditionalImages.length} / 8 صور</span>
                      </div>
                      
                      <div className="grid grid-cols-4 gap-2 mb-2">
                        {prodAdditionalImages.map((img, idx) => (
                          <div key={idx} className="relative aspect-square rounded-xl overflow-hidden border border-zinc-200 bg-zinc-50 group">
                            <img src={img} alt={`إضافية ${idx + 1}`} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                            <button
                              type="button"
                              onClick={() => {
                                setProdAdditionalImages(prev => prev.filter((_, i) => i !== idx));
                              }}
                              className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 shadow transition-all cursor-pointer"
                            >
                              <X className="w-2.5 h-2.5" />
                            </button>
                          </div>
                        ))}
                        
                        {prodAdditionalImages.length < 8 && (
                          <label className="aspect-square rounded-xl border-2 border-dashed border-zinc-200 hover:border-amber-500 bg-zinc-50 hover:bg-zinc-100/50 flex flex-col items-center justify-center text-center cursor-pointer transition-all">
                            <Upload className="w-4 h-4 text-zinc-400 mb-1 animate-bounce" />
                            <span className="text-[8.5px] text-zinc-500 font-bold">رفع صورة</span>
                            <input
                              type="file"
                              accept="image/*"
                              multiple
                              onChange={(e) => {
                                if (e.target.files) {
                                  const filesArray = Array.from(e.target.files);
                                  filesArray.forEach((file: any) => {
                                    if (file.size > 2.5 * 1024 * 1024) {
                                      triggerToast('⚠️ حجم إحدى الصور كبير جداً (أكبر من 2.5 ميجابايت)');
                                      return;
                                    }
                                    const reader = new FileReader();
                                    reader.onload = (re) => {
                                      if (re.target?.result && typeof re.target.result === 'string') {
                                        setProdAdditionalImages(prev => [...prev, re.target!.result as string]);
                                      }
                                    };
                                    reader.readAsDataURL(file);
                                  });
                                }
                              }}
                              className="hidden"
                            />
                          </label>
                        )}
                      </div>
                      <p className="text-[9px] text-zinc-400">يمكنك رفع حتى 8 صور إضافية للمنتج مباشرة من جهازك وعرضها في معرض الصور.</p>
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] text-zinc-400 font-bold block mb-1">رابط فيديو توضيحي يوتيوب (اختياري)</label>
                    <input
                      type="url"
                      placeholder="https://www.youtube.com/watch?v=..."
                      value={prodYoutubeUrl}
                      onChange={(e) => setProdYoutubeUrl(e.target.value)}
                      className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 font-mono text-left"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] text-zinc-400 font-bold block mb-1">ملاحظة أو تنبيه خاص بالمنتج يظهر للزبون (اختياري)</label>
                    <input
                      type="text"
                      placeholder="مثال: هذا المنتج يتطلب تفصيل لمدة 3 أيام عمل..."
                      value={prodNotes}
                      onChange={(e) => setProdNotes(e.target.value)}
                      className="w-full text-xs p-2.5 rounded-xl border border-zinc-200"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <label className="text-[10px] text-zinc-400 font-bold block">خيارات المنتج المتوفرة للزبون (اختياري)</label>
                      <span className="text-[9px] text-zinc-400 bg-zinc-100 px-1.5 py-0.5 rounded font-mono">كل خيار في سطر</span>
                    </div>
                    <textarea
                      placeholder="المقاس: S، M، L، XL&#10;اللون: أحمر، أزرق، أسود"
                      value={prodOptionsText}
                      onChange={(e) => setProdOptionsText(e.target.value)}
                      className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 h-16 font-mono"
                    />
                    <span className="text-[9.5px] text-zinc-400 block leading-relaxed">اكتب الخيار متبوعاً بنقطتين ":" ثم القيم تفصلها فاصلة "،".</span>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-zinc-950 text-white font-bold py-2.5 rounded-xl mt-3 hover:bg-amber-500 hover:text-zinc-950 transition-all cursor-pointer text-xs"
                  >
                    {editingProduct ? 'حفظ التغييرات وتحديث البيانات' : 'تفعيل السلعة وعرضها في المتجر'}
                  </button>
                </form>
              </motion.div>
            </div>
          )}
        </div>
      )}

      {/* 3. ORDERS & INVOICES TAB */}
      {activeTab === 'orders' && (() => {
        const filteredOrders = orders.filter((o) => {
          if (!orderSearchQuery) return true;
          const query = orderSearchQuery.toLowerCase();
          return (
            o.id.toLowerCase().includes(query) ||
            o.customerName.toLowerCase().includes(query) ||
            o.customerPhone.toLowerCase().includes(query) ||
            o.customerAddress.toLowerCase().includes(query)
          );
        });

        return (
          <div className="space-y-6">
            <div className="border-b border-zinc-150 pb-3">
              <h3 className="font-extrabold text-sm text-zinc-950 flex items-center gap-1.5">
                <FileText className="w-4.5 h-4.5 text-amber-500" />
                <span>إدارة الطلبيات والفواتير عبر المنصة ({filteredOrders.length})</span>
              </h3>
            </div>

            {/* Order Search & Filtering Input */}
            <div className="flex flex-col sm:flex-row gap-3 items-center justify-between bg-zinc-50 p-3.5 rounded-2xl border border-zinc-200">
              <div className="relative w-full sm:max-w-md">
                <span className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-zinc-400">
                  <Search className="w-4 h-4" />
                </span>
                <input
                  type="text"
                  placeholder="ابحث برقم الطلب، اسم المشتري، الهاتف..."
                  value={orderSearchQuery}
                  onChange={(e) => setOrderSearchQuery(e.target.value)}
                  className="w-full text-xs pr-9 pl-4 py-2.5 rounded-xl border border-zinc-200 bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/20 text-right"
                  dir="rtl"
                />
                {orderSearchQuery && (
                  <button
                    onClick={() => setOrderSearchQuery('')}
                    className="absolute inset-y-0 left-0 pl-3 flex items-center text-zinc-400 hover:text-zinc-600 text-xs font-bold"
                  >
                    مسح
                  </button>
                )}
              </div>
              <span className="text-[11px] text-zinc-500 font-bold">عرض {filteredOrders.length} من {orders.length} طلبية بالمنصة</span>
            </div>

            <div className="bg-white rounded-2xl border border-zinc-150 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead>
                    <tr className="bg-zinc-50 text-zinc-500 border-b border-zinc-150">
                      <th className="p-3.5 font-bold">رقم الطلب</th>
                      <th className="p-3.5 font-bold">المشتري والهاتف</th>
                      <th className="p-3.5 font-bold">العنوان والموقع</th>
                      <th className="p-3.5 font-bold">قيمة الصفقة</th>
                      <th className="p-3.5 font-bold">الدفع</th>
                      <th className="p-3.5 font-bold">حالة الطلب</th>
                      <th className="p-3.5 font-bold text-center">الإجراءات والطباعة</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-100 text-zinc-700 font-medium">
                    {filteredOrders.map((o) => (
                      <tr key={o.id} id={`admin-order-row-${o.id}`} className="hover:bg-zinc-50/50 transition-all">
                        <td className="p-3.5 font-mono font-bold text-zinc-950">{o.id}</td>
                        <td className="p-3.5">
                          <div className="font-bold text-zinc-900">{o.customerName}</div>
                          <span className="text-[10px] text-zinc-400 font-mono block">{o.customerPhone}</span>
                        </td>
                        <td className="p-3.5 text-zinc-600 truncate max-w-44" title={o.customerAddress}>
                          {o.customerAddress}
                        </td>
                        <td className="p-3.5 font-mono font-bold text-zinc-900">{o.finalPrice.toLocaleString()} ر.ي</td>
                        <td className="p-3.5">
                          <span className="bg-zinc-100 text-zinc-800 px-2 py-0.5 rounded text-[10px] font-bold">
                            {o.paymentMethod === 'cod' && 'عند الاستلام'}
                            {o.paymentMethod === 'kuraimi' && 'الكريمي'}
                            {o.paymentMethod === 'jeeb' && 'محفظة جيب'}
                            {o.paymentMethod === 'bank_transfer' && 'تحويل مباشر'}
                          </span>
                        </td>
                        <td className="p-3.5">
                          <select
                            value={o.status}
                            onChange={(e) => {
                              const newStatus = e.target.value as OrderStatus;
                              let cancelReason = undefined;
                              if (newStatus === 'cancelled') {
                                cancelReason = window.prompt('الرجاء كتابة سبب إلغاء هذا الطلب (اختياري):') || undefined;
                              }
                              onUpdateOrderStatus(o.id, newStatus, cancelReason);
                              triggerToast('تم تعديل حالة شحن الطلب 🚚');
                            }}
                            className={`text-[10.5px] font-bold p-1 rounded-md cursor-pointer focus:outline-none ${
                              o.status === 'delivered'
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                : o.status === 'cancelled'
                                ? 'bg-red-50 text-red-700 border border-red-200'
                                : 'bg-yellow-50 text-yellow-700 border border-yellow-200'
                            }`}
                          >
                            <option value="pending">معلق (جديد)</option>
                            <option value="processing">جاري التجهيز</option>
                            <option value="shipped">تم الشحن</option>
                            <option value="delivered">تم التسليم</option>
                            <option value="cancelled">ملغي</option>
                          </select>
                        </td>
                        <td className="p-3.5 text-center flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => {
                              setPrintingOrder(o);
                              setPrintType('invoice');
                            }}
                            className="bg-zinc-100 hover:bg-zinc-200 text-zinc-800 text-[10px] font-bold py-1 px-2.5 rounded-lg flex items-center gap-1 transition-all cursor-pointer"
                          >
                            <Printer className="w-3 h-3" />
                            <span>فاتورة</span>
                          </button>
                          <button
                            onClick={() => {
                              setPrintingOrder(o);
                              setPrintType('shipping_label');
                            }}
                            className="bg-amber-500 hover:bg-amber-600 text-zinc-950 text-[10px] font-bold py-1 px-2.5 rounded-lg flex items-center gap-1 transition-all cursor-pointer"
                          >
                            <Truck className="w-3 h-3" />
                            <span>بوليصة شحن</span>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        );
      })()}

      {/* 4. CUSTOMERS TAB */}
      {activeTab === 'customers' && (
        <div className="space-y-6">
          <div className="border-b border-zinc-150 pb-3">
            <h3 className="font-extrabold text-sm text-zinc-950 flex items-center gap-1.5">
              <Users className="w-4.5 h-4.5 text-amber-500" />
              <span>قاعدة بيانات العملاء المسجلين والصفقات الفردية</span>
            </h3>
          </div>

          <div className="bg-white rounded-2xl border border-zinc-150 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
              <thead>
                <tr className="bg-zinc-50 text-zinc-500 border-b border-zinc-150">
                  <th className="p-4 font-bold">اسم العميل</th>
                  <th className="p-4 font-bold">الهاتف المعتمد</th>
                  <th className="p-4 font-bold">المدينة / المحافظة</th>
                  <th className="p-4 font-bold">عدد الطلبات المسجلة</th>
                  <th className="p-4 font-bold">إجمالي المشتريات</th>
                  <th className="p-4 font-bold text-left">التواصل والدعم</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-100 text-zinc-700 font-medium">
                {/* Dynamically extract unique customers from existing orders */}
                {(() => {
                  const customerMap: Record<string, { name: string; phone: string; address: string; totalOrders: number; totalSpend: number; lastOrder: string }> = {};

                  orders.forEach(o => {
                    const key = o.customerPhone || 'unknown';
                    if (!customerMap[key]) {
                      customerMap[key] = {
                        name: o.customerName,
                        phone: o.customerPhone,
                        address: o.customerAddress,
                        totalOrders: 0,
                        totalSpend: 0,
                        lastOrder: o.createdAt
                      };
                    }
                    customerMap[key].totalOrders += 1;
                    if (o.status !== 'cancelled') {
                      customerMap[key].totalSpend += o.finalPrice;
                    }
                  });

                  const list = Object.values(customerMap);
                  if (list.length === 0) {
                    return (
                      <tr>
                        <td colSpan={6} className="text-center py-12 text-zinc-400">لا يوجد بيانات عملاء مسجلة حالياً.</td>
                      </tr>
                    );
                  }

                  return list.map((cust, idx) => (
                    <tr key={idx} className="hover:bg-zinc-50/50">
                      <td className="p-4 flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-zinc-100 text-zinc-600 flex items-center justify-center font-bold">
                          {cust.name.charAt(0)}
                        </div>
                        <span className="font-bold text-zinc-950">{cust.name}</span>
                      </td>
                      <td className="p-4 font-mono">{cust.phone}</td>
                      <td className="p-4 truncate max-w-44">{cust.address.split('-')[0] || 'اليمن'}</td>
                      <td className="p-4 font-mono font-bold text-zinc-600">{cust.totalOrders ?? 0} طلبيات</td>
                      <td className="p-4 font-mono font-black text-amber-600">{(cust.totalSpend ?? 0).toLocaleString()} ر.ي</td>
                      <td className="p-4 text-left">
                        <button
                          onClick={() => {
                            onOpenChat('customer_guest', 'المساعدة المباشرة للطلبيات', undefined);
                            triggerToast('تم فتح نافذة الدردشة المباشرة مع العميل 💬');
                          }}
                          className="text-zinc-950 hover:text-amber-600 font-black text-[11px] flex items-center gap-1 cursor-pointer"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>تواصل مباشر</span>
                        </button>
                      </td>
                    </tr>
                  ));
                })()}
              </tbody>
            </table>
          </div>
        </div>
        </div>
      )}

      {/* 5. SHIPPING & PAYMENTS TAB */}
      {activeTab === 'shipping_payment' && !isEmployee && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Shipping configurations */}
          <div className="space-y-6">
            <h3 className="font-extrabold text-sm text-zinc-950 flex items-center gap-1.5 border-b border-zinc-100 pb-3.5">
              <Truck className="w-4.5 h-4.5 text-amber-500" />
              <span>إدارة شركات الشحن وأسعار التوصيل الفردية</span>
            </h3>

            {/* Create shipping method form */}
            <form onSubmit={handleAddShippingSubmit} className="bg-white p-5 rounded-3xl border border-zinc-150 space-y-3">
              <h4 className="font-black text-xs text-zinc-900 border-b border-zinc-100 pb-2">🚚 إضافة شركة شحن جديدة</h4>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-zinc-400 font-bold block mb-1">اسم شركة الشحن *</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: يمن بوست للتوصيل"
                    value={newShipName}
                    onChange={(e) => setNewShipName(e.target.value)}
                    className="w-full text-xs p-2 rounded-xl border border-zinc-200 bg-zinc-50"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-zinc-400 font-bold block mb-1">سعر التوصيل (ر.ي) *</label>
                  <input
                    type="number"
                    required
                    placeholder="مثال: 3000"
                    value={newShipCost}
                    onChange={(e) => setNewShipCost(e.target.value)}
                    className="w-full text-xs p-2 rounded-xl border border-zinc-200 bg-zinc-50 font-mono text-left"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-zinc-400 font-bold block mb-1">مدة التوصيل التقريبية</label>
                  <input
                    type="text"
                    placeholder="مثال: 24-48 ساعة"
                    value={newShipTime}
                    onChange={(e) => setNewShipTime(e.target.value)}
                    className="w-full text-xs p-2 rounded-xl border border-zinc-200 bg-zinc-50"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-zinc-400 font-bold block mb-1">المناطق المغطاة (تفصل بفاصلة)</label>
                  <input
                    type="text"
                    placeholder="مثال: صنعاء, عدن, تعز"
                    value={newShipRegions}
                    onChange={(e) => setNewShipRegions(e.target.value)}
                    className="w-full text-xs p-2 rounded-xl border border-zinc-200 bg-zinc-50"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-zinc-950 text-white text-xs font-bold py-2 rounded-xl hover:bg-amber-500 hover:text-zinc-950 cursor-pointer"
              >
                ربط وتفعيل شركة الشحن
              </button>
            </form>

            {/* Active shipping companies */}
            <div className="space-y-3">
              {shippingMethods.map((sh) => (
                <div key={sh.id} className="bg-white p-4 rounded-2xl border border-zinc-150 flex justify-between items-center text-xs">
                  <div>
                    <span className="font-bold text-zinc-900 block">{sh.name}</span>
                    <span className="text-[10px] text-zinc-500 block mt-1">
                      المناطق: {sh.regions.join(', ')} • مدة الوصول: {sh.deliveryTime}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-bold font-mono text-zinc-950">{(sh.cost ?? 0).toLocaleString()} ر.ي</span>
                    <button
                      onClick={() => {
                        onUpdateShippingMethod(sh.id, { isActive: !sh.isActive });
                        triggerToast('تم تحديث حالة شركة الشحن 🚚');
                      }}
                      className={`font-bold px-2.5 py-1 rounded-lg text-[10px] cursor-pointer ${
                        sh.isActive
                          ? 'bg-emerald-50 text-emerald-600 border border-emerald-100'
                          : 'bg-red-50 text-red-600 border border-red-100'
                      }`}
                    >
                      {sh.isActive ? 'نشط' : 'معطل'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Payment Gateways */}
          <div className="space-y-6">
            <h3 className="font-extrabold text-sm text-zinc-950 flex items-center gap-1.5 border-b border-zinc-100 pb-3.5">
              <CreditCard className="w-4.5 h-4.5 text-amber-500" />
              <span>تفعيل وسائل وبوابات الدفع الإلكتروني والتحويلات</span>
            </h3>

            <div className="space-y-4">
              {paymentGateways.map((pay) => (
                <div key={pay.id} className="bg-white p-4.5 rounded-2xl border border-zinc-150 space-y-3">
                  <div className="flex justify-between items-center border-b border-zinc-100 pb-2.5">
                    <div className="flex items-center gap-3">
                      {pay.logo && pay.logo.startsWith('data:') ? (
                        <img src={pay.logo} alt={pay.name} className="w-10 h-10 object-contain rounded-xl border border-zinc-150" referrerPolicy="no-referrer" />
                      ) : (
                        <span className="text-xl bg-zinc-100 w-10 h-10 rounded-xl flex items-center justify-center border border-zinc-200">{pay.logo || '💳'}</span>
                      )}
                      <div>
                        <span className="font-bold text-zinc-900 text-xs">{pay.name}</span>
                        <p className="text-[10px] text-zinc-500 mt-0.5">{pay.instructions}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          onUpdatePaymentGateway(pay.id, { isActive: !pay.isActive });
                          triggerToast('تم تغيير حالة تفعيل بوابة الدفع 💳');
                        }}
                        className={`font-bold px-3 py-1.5 rounded-lg text-[10px] cursor-pointer ${
                          pay.isActive
                            ? 'bg-emerald-50 text-emerald-600 border border-emerald-100'
                            : 'bg-zinc-100 text-zinc-400 border border-zinc-200'
                        }`}
                      >
                        {pay.isActive ? 'مفعل وجاهز' : 'غير مفعل'}
                      </button>

                      {/* Delete button for custom gateways */}
                      {pay.id !== 'pay_cod' && (
                        <div className="flex items-center gap-1.5">
                          {gatewayToDelete === pay.id ? (
                            <span className="inline-flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => {
                                  onDeletePaymentGateway(pay.id);
                                  triggerToast('تم حذف وسيلة الدفع بنجاح 🗑️');
                                  setGatewayToDelete(null);
                                }}
                                className="bg-red-600 text-white hover:bg-red-700 px-2 py-1 rounded text-[10px] font-black cursor-pointer"
                              >
                                تأكيد الحذف
                              </button>
                              <button
                                type="button"
                                onClick={() => setGatewayToDelete(null)}
                                className="bg-zinc-200 text-zinc-700 hover:bg-zinc-300 px-2 py-1 rounded text-[10px] font-bold cursor-pointer"
                              >
                                إلغاء
                              </button>
                            </span>
                          ) : (
                            <button
                              type="button"
                              onClick={() => setGatewayToDelete(pay.id)}
                              className="bg-red-50 text-red-500 hover:bg-red-100 p-2 rounded-lg border border-red-100 transition-colors cursor-pointer"
                              title="حذف وسيلة الدفع"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  </div>

                  {pay.isActive && pay.id !== 'pay_cod' && (
                    <div className="flex gap-2 items-center text-xs">
                      <span className="text-zinc-500 font-bold">رقم الحساب أو المحفظة:</span>
                      <input
                        type="text"
                        defaultValue={pay.accountNumber || ''}
                        onBlur={(e) => {
                          onUpdatePaymentGateway(pay.id, { accountNumber: e.target.value });
                          triggerToast('تم حفظ رقم الحساب بنجاح 💾');
                        }}
                        className="p-1 px-2.5 rounded-lg border border-zinc-200 bg-zinc-50 focus:bg-white text-xs text-left font-mono focus:outline-none focus:border-amber-500 flex-grow"
                        placeholder="أدخل رقم الحساب هنا للحفظ التلقائي"
                      />
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Toggle form button */}
            <div className="flex justify-between items-center border-t border-zinc-100 pt-4 mt-2">
              <span className="text-[11px] text-zinc-500">هل ترغب في توفير وسيلة دفع محلية إضافية للعملاء؟</span>
              <button
                type="button"
                onClick={() => setIsAddingGateway(!isAddingGateway)}
                className="bg-amber-500 hover:bg-amber-600 text-zinc-950 font-extrabold text-xs py-2 px-3.5 rounded-xl transition-all cursor-pointer flex items-center gap-1 shadow-sm"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>إضافة وسيلة دفع جديدة</span>
              </button>
            </div>

            {/* New Gateway Form */}
            {isAddingGateway && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-amber-50/50 p-5 rounded-2xl border border-amber-500/20 space-y-4 text-right"
              >
                <h4 className="font-black text-xs text-zinc-950 border-b border-zinc-200/60 pb-2">إضافة وسيلة دفع مخصصة جديدة للمتجر</h4>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] text-zinc-500 font-bold block mb-1">اسم وسيلة الدفع *</label>
                    <input
                      type="text"
                      required
                      placeholder="مثال: محفظة الكريمي مميز، أو محفظة كاش..."
                      value={newPayName}
                      onChange={(e) => setNewPayName(e.target.value)}
                      className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-zinc-500 font-bold block mb-1">شعار وسيلة الدفع (إيموجي أو رفع صورة مباشرة)</label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="مثال: 📱، 🏦، 💳"
                        value={newPayLogo}
                        onChange={(e) => setNewPayLogo(e.target.value)}
                        className="w-20 text-xs p-2.5 rounded-xl border border-zinc-200 bg-white text-center font-mono"
                        maxLength={1}
                      />
                      <label className="flex-grow text-xs p-2 rounded-xl border border-dashed border-zinc-300 hover:border-amber-500 bg-white flex items-center justify-center text-center cursor-pointer select-none font-bold">
                        <span>📥 رفع شعار صورة</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => {
                            if (e.target.files && e.target.files[0]) {
                              const file = e.target.files[0];
                              if (file.size > 2.5 * 1024 * 1024) {
                                triggerToast('⚠️ حجم الصورة كبير جداً (أقصى حد 2.5 ميجا)');
                                return;
                              }
                              const reader = new FileReader();
                              reader.onload = (re) => {
                                if (re.target?.result && typeof re.target.result === 'string') {
                                  setNewPayLogo(re.target.result);
                                  triggerToast('تم رفع شعار وسيلة الدفع بنجاح ✅');
                                }
                              };
                              reader.readAsDataURL(file);
                            }
                          }}
                          className="hidden"
                        />
                      </label>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] text-zinc-500 font-bold block mb-1">رقم الحساب / المحفظة للتحويل</label>
                    <input
                      type="text"
                      placeholder="رقم المحفظة أو الحساب البنكي"
                      value={newPayAccount}
                      onChange={(e) => setNewPayAccount(e.target.value)}
                      className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-white font-mono text-left"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-zinc-500 font-bold block mb-1">تعليمات التحويل للعميل</label>
                    <input
                      type="text"
                      placeholder="مثال: يرجى إرسال لقطة شاشة لعملية التحويل لواتساب المتجر"
                      value={newPayInstructions}
                      onChange={(e) => setNewPayInstructions(e.target.value)}
                      className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-white"
                    />
                  </div>
                </div>

                {newPayLogo && newPayLogo.startsWith('data:') && (
                  <div className="flex items-center gap-2 bg-white p-2.5 rounded-xl border border-zinc-150 w-fit">
                    <span className="text-[10px] text-zinc-400 font-bold">معاينة الشعار:</span>
                    <img src={newPayLogo} alt="شعار جديد" className="w-8 h-8 object-contain rounded border border-zinc-100" referrerPolicy="no-referrer" />
                    <button type="button" onClick={() => setNewPayLogo('')} className="text-red-500 text-xs hover:underline font-bold">إزالة الشعار</button>
                  </div>
                )}

                <div className="flex justify-end gap-2 pt-2 border-t border-zinc-200/60">
                  <button
                    type="button"
                    onClick={() => {
                      if (!newPayName.trim()) {
                        triggerToast('⚠️ يرجى إدخال اسم وسيلة الدفع أولاً');
                        return;
                      }
                      onAddPaymentGateway({
                        id: 'pay_' + Date.now(),
                        name: newPayName.trim(),
                        logo: newPayLogo || '💳',
                        accountNumber: newPayAccount.trim() || undefined,
                        instructions: newPayInstructions.trim() || undefined,
                        isActive: true,
                      });
                      setNewPayName('');
                      setNewPayLogo('');
                      setNewPayAccount('');
                      setNewPayInstructions('');
                      setIsAddingGateway(false);
                      triggerToast('تمت إضافة وسيلة الدفع الجديدة بنجاح 🎉');
                    }}
                    className="bg-zinc-950 hover:bg-zinc-900 text-white font-bold text-xs py-2 px-5 rounded-xl cursor-pointer"
                  >
                    حفظ وسيلة الدفع
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsAddingGateway(false)}
                    className="bg-zinc-200/80 hover:bg-zinc-200 text-zinc-800 font-bold text-xs py-2 px-5 rounded-xl cursor-pointer"
                  >
                    إلغاء
                  </button>
                </div>
              </motion.div>
            )}
          </div>
        </div>
      )}

      {/* 6. MARKETING & ABANDONED CARTS TAB */}
      {activeTab === 'marketing' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Coupons Management (col-span-5) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="flex justify-between items-center border-b border-zinc-150 pb-3">
              <h3 className="font-extrabold text-sm text-zinc-950 flex items-center gap-1.5">
                <Tag className="w-4.5 h-4.5 text-amber-500" />
                <span>قسائم الخصم الترويجية ({coupons.length})</span>
              </h3>

              <button
                onClick={() => setIsCouponFormOpen(!isCouponFormOpen)}
                className="text-amber-600 font-bold text-xs flex items-center gap-0.5 hover:underline cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>كوبون جديد</span>
              </button>
            </div>

            {/* Create Coupon form */}
            {isCouponFormOpen && (
              <motion.form
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                onSubmit={handleCreateCoupon}
                className="bg-zinc-50 p-4 rounded-2xl border border-zinc-150 space-y-3 text-right"
              >
                <div>
                  <label className="text-[10px] font-bold text-zinc-500 block mb-1">رمز الكوبون (أحرف إنجليزية كبيرة) *</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: YEMEN50"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    className="w-full text-xs px-3 py-2 rounded-lg border border-zinc-200 uppercase font-mono text-left focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] font-bold text-zinc-500 block mb-1">طريقة الحسم *</label>
                    <select
                      value={discountType}
                      onChange={(e) => setDiscountType(e.target.value as 'percentage' | 'fixed')}
                      className="w-full text-xs px-2 py-2 rounded-lg border border-zinc-200"
                    >
                      <option value="percentage">نسبة مئوية (%)</option>
                      <option value="fixed">مبلغ ثابت (ر.ي)</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-zinc-500 block mb-1">قيمة الحسم *</label>
                    <input
                      type="number"
                      required
                      placeholder={discountType === 'percentage' ? 'مثال: 15' : 'مثال: 2000'}
                      value={couponValue}
                      onChange={(e) => setCouponValue(e.target.value)}
                      className="w-full text-xs px-3 py-2 rounded-lg border border-zinc-200 font-mono text-left focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-zinc-500 block mb-1">الحد الأدنى لقيمة السلة للشراء (ر.ي - اختياري)</label>
                  <input
                    type="number"
                    placeholder="مثال: 15000"
                    value={minSpend}
                    onChange={(e) => setMinSpend(e.target.value)}
                    className="w-full text-xs px-3 py-2 rounded-lg border border-zinc-200 font-mono text-left focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-zinc-950 hover:bg-amber-500 hover:text-zinc-950 text-white text-xs font-bold py-2 rounded-xl transition-all cursor-pointer"
                >
                  تفعيل قسيمة الخصم الجديدة
                </button>
              </motion.form>
            )}

            {/* Coupons list */}
            <div className="space-y-3">
              {coupons.map((coupon) => (
                <div
                  key={coupon.code}
                  className="bg-white p-3.5 rounded-2xl border border-zinc-150 flex justify-between items-center"
                >
                  <div>
                    <span className="font-bold font-mono text-zinc-950 text-xs bg-zinc-100 px-2 py-1 rounded">
                      {coupon.code}
                    </span>
                    <div className="text-[10px] text-zinc-500 mt-2">
                      الحسم:{' '}
                      <span className="font-bold text-zinc-800 font-mono">
                        {coupon.discountType === 'percentage'
                          ? `${coupon.value}%`
                          : `${(coupon.value ?? 0).toLocaleString()} ر.ي`}
                      </span>
                      {coupon.minSpend && (
                        <span className="block text-zinc-400 mt-0.5">
                          الحد الأدنى للشراء: {(coupon.minSpend ?? 0).toLocaleString()} ر.ي
                        </span>
                      )}
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      onDeleteCoupon(coupon.code);
                      triggerToast('تم إيقاف وحذف قسيمة الخصم 🗑');
                    }}
                    className="text-zinc-400 hover:text-red-500 p-2 rounded-lg hover:bg-zinc-50 transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Abandoned Carts (col-span-7) */}
          <div className="lg:col-span-7 space-y-6">
            <h3 className="font-extrabold text-sm text-zinc-950 border-b border-zinc-150 pb-3">
              <span>🛒 السلات المتروكة وتنبيهات تذكير العملاء ({abandonedCarts.length})</span>
            </h3>

            <div className="space-y-3">
              {abandonedCarts.map((cart) => {
                const totalVal = cart.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
                return (
                  <div key={cart.id} className="bg-white p-4.5 rounded-2xl border border-zinc-150 space-y-3 text-xs">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="font-bold text-zinc-900 block">{cart.customerName}</span>
                        <span className="text-[10px] text-zinc-400 font-mono mt-0.5">رقم الهاتف: {cart.customerPhone}</span>
                      </div>
                      <span className="text-[10px] text-zinc-400 font-mono">
                        آخر تعديل: {new Date(cart.updatedAt).toLocaleTimeString('ar-YE', { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>

                    <div className="bg-zinc-50 p-2.5 rounded-xl space-y-1.5 border border-zinc-100">
                      {cart.items.map((item, idx) => (
                        <div key={idx} className="flex justify-between text-[11px] text-zinc-600 font-medium">
                          <span>{item.productTitle} x {item.quantity}</span>
                          <span className="font-mono">{(item.price ?? 0).toLocaleString()} ر.ي</span>
                        </div>
                      ))}
                      <div className="border-t border-zinc-200 pt-1.5 flex justify-between font-bold text-zinc-800 text-[11.5px]">
                        <span>القيمة التقديرية للسلة:</span>
                        <span className="font-mono text-amber-600">{(totalVal ?? 0).toLocaleString()} ر.ي</span>
                      </div>
                    </div>

                    <div className="flex justify-end">
                      <button
                        onClick={() => {
                          onSendCartReminder(cart.id);
                          triggerToast('تم إرسال تذكير سلة متروكة مخصص ومغري بالخصم للعميل 💬');
                        }}
                        className="bg-amber-500 hover:bg-amber-600 text-zinc-950 font-black px-4 py-2 rounded-xl text-[10.5px] transition-all cursor-pointer shadow-xs"
                      >
                        ⚡ إرسال تذكير مغري مع كود خصم
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* 7. STAFF & PERMISSIONS TAB */}
      {activeTab === 'staff' && !isEmployee && (
        <div className="space-y-6" dir="rtl">
          {/* Simulation Employees Row */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Add Local Employee Form */}
            <div className="lg:col-span-5 bg-white p-6 rounded-3xl border border-zinc-150 space-y-4">
              <div className="border-b border-zinc-100 pb-2.5">
                <h3 className="font-black text-sm text-zinc-900 flex items-center gap-2">
                  <Plus className="w-4 h-4 text-amber-500" />
                  <span>إضافة موظف جديد للمحاكاة</span>
                </h3>
                <p className="text-zinc-500 text-[10.5px] mt-1 leading-relaxed">
                  سجل حساب موظف جديد وخصص صلاحياته لتمكين محاكاة شاشة التحكم المخصصة له من الشريط العلوي.
                </p>
              </div>

              <form onSubmit={handleAddEmployeeSubmit} className="space-y-4 text-right">
                <div>
                  <label className="block text-zinc-700 font-bold text-[11px] mb-1">اسم الموظف الكامل</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: صالح أحمد اليماني"
                    value={newEmpName}
                    onChange={(e) => setNewEmpName(e.target.value)}
                    className="w-full text-xs p-3 rounded-xl border border-zinc-200 bg-white focus:outline-none focus:border-amber-500 font-sans"
                  />
                </div>

                <div>
                  <label className="block text-zinc-700 font-bold text-[11px] mb-1">البريد الإلكتروني</label>
                  <input
                    type="email"
                    required
                    placeholder="name@maha-store.com"
                    value={newEmpEmail}
                    onChange={(e) => setNewEmpEmail(e.target.value)}
                    className="w-full text-xs p-3 rounded-xl border border-zinc-200 bg-white focus:outline-none focus:border-amber-500 font-sans font-mono text-left"
                    dir="ltr"
                  />
                </div>

                <div>
                  <label className="block text-zinc-700 font-bold text-[11px] mb-1">قسم العمل / صلاحية الوصول</label>
                  <select
                    value={newEmpPerm}
                    onChange={(e) => setNewEmpPerm(e.target.value as any)}
                    className="w-full text-xs p-3 rounded-xl border border-zinc-200 bg-white cursor-pointer focus:outline-none focus:border-amber-500 font-bold"
                  >
                    <option value="products">📦 إدارة المنتجات والتصنيفات</option>
                    <option value="orders">📝 إدارة الطلبات والصفقات</option>
                    <option value="customers">👥 خدمة العملاء واستفسارات الاتصال</option>
                    <option value="marketing">📣 التسويق والسلات المتروكة</option>
                  </select>
                </div>

                <button
                  type="submit"
                  className="w-full bg-amber-500 hover:bg-amber-600 text-zinc-950 font-black text-xs py-3 rounded-xl transition-all cursor-pointer shadow-xs flex items-center justify-center gap-1.5 min-h-[44px]"
                >
                  <Plus className="w-4 h-4" />
                  <span>إضافة الموظف للمتجر 💼</span>
                </button>
              </form>
            </div>

            {/* Simulated Employees List */}
            <div className="lg:col-span-7 bg-white p-6 rounded-3xl border border-zinc-150 space-y-4">
              <div className="border-b border-zinc-100 pb-2.5">
                <h3 className="font-black text-sm text-zinc-900 flex items-center gap-2">
                  <Briefcase className="w-4 h-4 text-amber-500" />
                  <span>موظفي المحاكاة المسجلين بالمتجر ({employees.length})</span>
                </h3>
                <p className="text-zinc-500 text-[10.5px] mt-1 leading-relaxed">
                  يمكنك النقر على زر "لوحة الموظف" في شريط الأدوات العلوي واختيار أي من الموظفين أدناه لتجربة صلاحياته بدقة.
                </p>
              </div>

              <div className="space-y-3 max-h-[350px] overflow-y-auto pr-1">
                {employees.length === 0 ? (
                  <div className="text-center py-12 text-zinc-400 text-xs font-bold border border-dashed border-zinc-200 rounded-2xl bg-zinc-50/50">
                    ⚠️ لا يوجد موظفين مسجلين حالياً. أضف موظفاً جديداً من النموذج الجانبي!
                  </div>
                ) : (
                  employees.map((emp) => {
                    const getPermLabel = (p: string) => {
                      if (p === 'products') return 'إدارة المنتجات';
                      if (p === 'orders') return 'إدارة الطلبات';
                      if (p === 'customers') return 'خدمة العملاء';
                      return 'التسويق والكوبونات';
                    };
                    const getPermColor = (p: string) => {
                      if (p === 'products') return 'bg-blue-50 text-blue-700 border-blue-100';
                      if (p === 'orders') return 'bg-emerald-50 text-emerald-700 border-emerald-100';
                      if (p === 'customers') return 'bg-purple-50 text-purple-700 border-purple-100';
                      return 'bg-pink-50 text-pink-700 border-pink-100';
                    };

                    return (
                      <div
                        key={emp.id}
                        className="p-4 rounded-2xl border border-zinc-150 bg-zinc-50/50 hover:bg-zinc-50 transition-all flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3"
                      >
                        <div className="flex gap-3 items-center">
                          <div className="w-10 h-10 rounded-full bg-amber-500/10 text-amber-600 border border-amber-500/20 flex items-center justify-center font-bold text-base flex-shrink-0">
                            👤
                          </div>
                          <div className="min-w-0">
                            <h4 className="font-extrabold text-zinc-900 text-xs truncate max-w-[180px]">{emp.name}</h4>
                            <p className="text-[10px] text-zinc-400 font-mono mt-0.5 truncate max-w-[180px]" dir="ltr">{emp.email}</p>
                            <span className="text-[9px] text-zinc-400 block mt-1">تاريخ الانضمام: {emp.joinedDate}</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-end border-t sm:border-t-0 pt-2 sm:pt-0 border-zinc-100">
                          <span className={`px-2.5 py-1 rounded-lg text-[9.5px] font-black border uppercase ${getPermColor(emp.permission)}`}>
                            {getPermLabel(emp.permission)}
                          </span>

                          {employeeToDelete === emp.id ? (
                            <span className="inline-flex items-center gap-1">
                              <button
                                onClick={() => {
                                  onDeleteEmployee(emp.id);
                                  triggerToast(`تم سحب صلاحيات الموظف ${emp.name} 🗑️`);
                                  setEmployeeToDelete(null);
                                }}
                                className="bg-red-600 text-white hover:bg-red-700 px-1.5 py-1 rounded text-[9.5px] font-black cursor-pointer"
                              >
                                تأكيد السحب
                              </button>
                              <button
                                onClick={() => setEmployeeToDelete(null)}
                                className="bg-zinc-200 text-zinc-700 hover:bg-zinc-300 px-1.5 py-1 rounded text-[9.5px] font-bold cursor-pointer"
                              >
                                إلغاء
                              </button>
                            </span>
                          ) : (
                            <button
                              onClick={() => setEmployeeToDelete(emp.id)}
                              className="p-2 text-zinc-400 hover:text-red-600 bg-white hover:bg-red-50 border border-zinc-200 hover:border-red-100 rounded-xl transition-all cursor-pointer min-w-[36px] min-h-[36px] flex items-center justify-center"
                              title="سحب الصلاحيات والحذف"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>

          {/* Firestore Active Users Section */}
          <div className="bg-white p-6 rounded-3xl border border-zinc-150 space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-zinc-100 pb-4" dir="rtl">
              <div>
                <h3 className="font-black text-sm text-zinc-900 flex items-center gap-2">
                  <Shield className="w-5 h-5 text-amber-500 animate-pulse" />
                  <span>إدارة مستخدمي وصلاحيات متجر مها في Firestore</span>
                </h3>
                <p className="text-zinc-500 text-[11px] mt-1">تعديل أدوار الحسابات بشكل آمن وتخصيص صلاحيات الوصول في الوقت الفعلي</p>
              </div>
              
              <button
                onClick={fetchFirestoreUsers}
                disabled={loadingUsers}
                className="bg-zinc-100 hover:bg-zinc-200 text-zinc-850 font-extrabold text-[11px] py-2 px-4 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 shadow-xs disabled:opacity-50 min-h-[40px]"
              >
                <span>{loadingUsers ? 'جاري التحديث...' : '🔄 تحديث القائمة من Firestore'}</span>
              </button>
            </div>

            {/* Filters & Search */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-3 bg-zinc-50 p-4 rounded-2xl border border-zinc-100" dir="rtl">
              <div className="md:col-span-8 relative">
                <input
                  type="text"
                  placeholder="البحث بالاسم، البريد الإلكتروني أو رقم الهاتف..."
                  value={userSearchQuery}
                  onChange={(e) => setUserSearchQuery(e.target.value)}
                  className="w-full text-xs p-3 pl-10 pr-4 rounded-xl border border-zinc-200 bg-white focus:outline-none focus:border-amber-500 font-sans"
                />
              </div>
              <div className="md:col-span-4">
                <select
                  value={userRoleFilter}
                  onChange={(e) => setUserRoleFilter(e.target.value as any)}
                  className="w-full text-xs p-3 rounded-xl border border-zinc-200 bg-white cursor-pointer focus:outline-none focus:border-amber-500 font-bold"
                >
                  <option value="all">كل الحسابات</option>
                  <option value="admin">المدراء (admin)</option>
                  <option value="employee">الموظفين (employee)</option>
                  <option value="customer">العملاء (customer)</option>
                </select>
              </div>
            </div>

            {/* User Cards Grid */}
            {loadingUsers ? (
              <div className="text-center py-12 space-y-3">
                <div className="w-10 h-10 border-4 border-amber-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
                <p className="text-xs text-zinc-500 font-bold">جاري جلب قاعدة بيانات مستخدمي Firestore الحية...</p>
              </div>
            ) : (
              <div className="space-y-4" dir="rtl">
                {(() => {
                  const filtered = firestoreUsers.filter(u => {
                    const matchSearch = 
                      u.name.toLowerCase().includes(userSearchQuery.toLowerCase()) ||
                      u.email.toLowerCase().includes(userSearchQuery.toLowerCase()) ||
                      (u.phone && u.phone.includes(userSearchQuery));
                    
                    const matchRole = userRoleFilter === 'all' || u.role === userRoleFilter;
                    return matchSearch && matchRole;
                  });

                  if (filtered.length === 0) {
                    return (
                      <div className="text-center py-12 bg-zinc-50/50 rounded-2xl border border-dashed border-zinc-200">
                        <Users className="w-10 h-10 text-zinc-300 mx-auto mb-2" />
                        <p className="text-xs text-zinc-500 font-bold">لم نجد أي حسابات تطابق خيارات البحث الحالية.</p>
                      </div>
                    );
                  }

                  return (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {filtered.map((user) => (
                        <div key={user.id} className="bg-white p-5 rounded-2xl border border-zinc-150 flex flex-col justify-between gap-4 hover:shadow-md transition-all">
                          {/* User Header */}
                          <div className="flex justify-between items-start">
                            <div className="flex gap-3">
                              <div className="w-11 h-11 rounded-full bg-amber-500/10 flex items-center justify-center font-bold text-lg border border-amber-500/20 text-amber-600">
                                👤
                              </div>
                              <div>
                                <span className="font-extrabold text-zinc-900 block text-xs">{user.name}</span>
                                <span className="text-[10.5px] text-zinc-400 block font-mono mt-0.5">{user.email}</span>
                                {user.phone && <span className="text-[10px] text-zinc-500 block font-mono mt-0.5">هاتف: {user.phone}</span>}
                                <span className="text-[9.5px] text-zinc-400 block mt-1">انضم بتاريخ: {user.joinedDate}</span>
                              </div>
                            </div>

                            {/* Role Badge */}
                            <span className={`px-2.5 py-1 rounded-lg text-[10px] font-black border uppercase ${
                              user.role === 'admin' 
                                ? 'bg-red-500/10 text-red-700 border-red-500/20' 
                                : user.role === 'employee'
                                ? 'bg-amber-500/10 text-amber-700 border-amber-500/20'
                                : 'bg-zinc-100 text-zinc-600 border-zinc-200'
                            }`}>
                              {user.role === 'admin' && 'مدير (admin)'}
                              {user.role === 'employee' && 'موظف (employee)'}
                              {user.role === 'customer' && 'عميل (customer)'}
                            </span>
                          </div>

                          {/* Action Buttons */}
                          <div className="flex items-center gap-1.5 border-t border-zinc-100 pt-3 flex-wrap">
                            {user.role !== 'employee' && (
                              <button
                                onClick={async () => {
                                  try {
                                    await updateUserRoleInFirestore(user.id, 'employee');
                                    triggerToast(`تمت ترقية الحساب ${user.name} بنجاح إلى موظف (employee) 💼`);
                                    fetchFirestoreUsers();
                                  } catch (e) {
                                    triggerToast('⚠️ فشل التحديث في Firestore. يرجى التحقق من القواعد.');
                                  }
                                }}
                                className="bg-amber-50 hover:bg-amber-600 text-zinc-950 font-black text-[10px] px-3 py-1.5 rounded-xl transition-all cursor-pointer shadow-xs min-h-[32px]"
                              >
                                💼 ترقية إلى موظف
                              </button>
                            )}

                            {user.role !== 'customer' && (
                              <button
                                onClick={async () => {
                                  if (user.email === 'galeelahmeda@gmail.com') {
                                    triggerToast('⚠️ لا يمكن إلغاء صلاحيات المدير الرئيسي!');
                                    return;
                                  }
                                  try {
                                    await updateUserRoleInFirestore(user.id, 'customer');
                                    triggerToast(`تم إلغاء الصلاحيات وإعادة ${user.name} كعميل (customer) 👤`);
                                    fetchFirestoreUsers();
                                  } catch (e) {
                                    triggerToast('⚠️ فشل التحديث في Firestore.');
                                  }
                                }}
                                className="bg-zinc-100 hover:bg-zinc-200 text-zinc-800 font-extrabold text-[10px] px-3 py-1.5 rounded-xl transition-all cursor-pointer border border-zinc-200 min-h-[32px]"
                              >
                                👤 إلغاء وإعادة لعميل
                              </button>
                            )}

                            {user.role !== 'admin' && (
                              <button
                                onClick={async () => {
                                  if (userToPromote === user.id) {
                                    try {
                                      await updateUserRoleInFirestore(user.id, 'admin');
                                      triggerToast(`تم منح صلاحيات المدير للمستخدم ${user.name} 👑`);
                                      fetchFirestoreUsers();
                                      setUserToPromote(null);
                                    } catch (e) {
                                      triggerToast('⚠️ فشل التحديث في Firestore.');
                                    }
                                  } else {
                                    setUserToPromote(user.id);
                                  }
                                }}
                                className={`${userToPromote === user.id ? 'bg-red-600 hover:bg-red-700 text-white animate-pulse border-red-600' : 'bg-red-50 hover:bg-red-100 text-red-700 border-red-100'} font-black text-[10px] px-3 py-1.5 rounded-xl transition-all cursor-pointer border min-h-[32px]`}
                              >
                                {userToPromote === user.id ? '⚠️ انقر مجدداً لتأكيد ترقية المدير' : '👑 تعيين كمدير جديد'}
                              </button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  );
                })()}
              </div>
            )}
          </div>
        </div>
      )}

      {/* 8. BANNERS & OFFERS MANAGEMENT TAB */}
      {activeTab === 'banners_offers' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start text-right" dir="rtl">
          {/* Add Banner Form */}
          <div className="lg:col-span-5 bg-white p-6 rounded-3xl border border-zinc-150 space-y-4">
            <h3 className="font-black text-sm text-zinc-900 border-b border-zinc-100 pb-2.5 flex items-center gap-1.5">
              <Plus className="w-5 h-5 text-amber-500" />
              <span>أضف بنر إعلاني / عرض جديد</span>
            </h3>

            <form onSubmit={(e) => {
              e.preventDefault();
              const formData = new FormData(e.currentTarget);
              const title = formData.get('title') as string;
              const subtitle = formData.get('subtitle') as string;
              const imageUrl = formData.get('imageUrl') as string;
              const couponCode = formData.get('couponCode') as string;
              const categorySlug = formData.get('categorySlug') as string;
              const animationType = formData.get('animationType') as 'none' | 'fade' | 'slide' | 'zoom' | 'bounce';
              if (!title || !imageUrl) return;

              const newBanner = {
                id: `banner_${Date.now()}`,
                title,
                subtitle,
                imageUrl,
                couponCode: couponCode || undefined,
                categorySlug: categorySlug || undefined,
                animationType: animationType || 'none',
                isActive: true
              };

              onUpdateBanners([...banners, newBanner]);
              e.currentTarget.reset();
              setBannerImage('');
              setBannerImageSourceTab('upload');
              triggerToast('تمت إضافة البنر الإعلاني بنجاح 🖼️');
            }} className="space-y-4">
              <div>
                <label className="text-[10px] text-zinc-400 font-bold block mb-1">عنوان البنر الرئيسي *</label>
                <input
                  type="text"
                  name="title"
                  required
                  placeholder="مثال: فساتين العيد الفاخرة"
                  className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white"
                />
              </div>

              <div>
                <label className="text-[10px] text-zinc-400 font-bold block mb-1">العنوان الفرعي أو العرض *</label>
                <input
                  type="text"
                  name="subtitle"
                  required
                  placeholder="مثال: خصم حصري 20% لفترة محدودة"
                  className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white"
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] text-zinc-400 font-bold block mb-1">صورة البنر الإعلاني *</label>
                <div className="flex bg-zinc-100 p-1 rounded-xl w-fit gap-1 mb-2 text-[10px] font-bold">
                  <button
                    type="button"
                    onClick={() => setBannerImageSourceTab('upload')}
                    className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                      bannerImageSourceTab === 'upload' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-500 hover:text-zinc-700'
                    }`}
                  >
                    📁 رفع صورة من الجهاز
                  </button>
                  <button
                    type="button"
                    onClick={() => setBannerImageSourceTab('url')}
                    className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                      bannerImageSourceTab === 'url' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-500 hover:text-zinc-700'
                    }`}
                  >
                    🔗 رابط مباشر (URL)
                  </button>
                </div>

                {bannerImageSourceTab === 'upload' ? (
                  <>
                    <ImageUploader
                      value={bannerImage}
                      onChange={(val) => setBannerImage(val)}
                      placeholderUrl=""
                    />
                    <input type="hidden" name="imageUrl" value={bannerImage} />
                  </>
                ) : (
                  <input
                    type="url"
                    name="imageUrl"
                    required
                    placeholder="رابط الصورة المباشر"
                    className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white text-left font-mono"
                  />
                )}
              </div>

              <div>
                <label className="text-[10px] text-zinc-400 font-bold block mb-1">رمز القسيمة المرتبطة بالعرض (اختياري)</label>
                <input
                  type="text"
                  name="couponCode"
                  placeholder="مثال: MAHA20"
                  className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white text-left font-mono"
                />
              </div>

              <div>
                <label className="text-[10px] text-zinc-400 font-bold block mb-1">ربط البنر بقسم معين (اختياري)</label>
                <select
                  name="categorySlug"
                  className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white"
                >
                  <option value="">جميع الأقسام (الرئيسية والفرعية)</option>
                  {categories.map(c => (
                    <option key={c.slug} value={c.slug}>{c.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[10px] text-zinc-400 font-bold block mb-1">نوع الحركة (أنيميشن للبنر)</label>
                <select
                  name="animationType"
                  className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white"
                >
                  <option value="none">بدون حركة (ثابت)</option>
                  <option value="fade">تلاشي (Fade)</option>
                  <option value="slide">انزلاق (Slide)</option>
                  <option value="zoom">تكبير (Zoom)</option>
                  <option value="bounce">ارتداد (Bounce)</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full bg-zinc-950 text-white text-xs font-bold py-2.5 rounded-xl transition-all hover:bg-amber-500 hover:text-zinc-950 cursor-pointer"
              >
                تفعيل ونشر البنر الإعلاني الجديد
              </button>
            </form>
          </div>

          {/* Banner list */}
          <div className="lg:col-span-7 space-y-4">
            <h3 className="font-extrabold text-sm text-zinc-950 border-b border-zinc-150 pb-3 flex items-center gap-1.5">
              <span>🖼️ البنرات والعروض النشطة حالياً في الواجهة ({banners.length})</span>
            </h3>

            <div className="space-y-4">
              {banners.length === 0 ? (
                <div className="bg-zinc-50 text-center py-8 rounded-2xl border border-dashed border-zinc-200 text-xs text-zinc-400">
                  لا توجد بنرات مخصصة مضافة حالياً.
                </div>
              ) : (
                banners.map((banner) => (
                  <div key={banner.id} className="bg-white p-4 rounded-2xl border border-zinc-150 flex flex-col md:flex-row gap-4 items-start md:items-center justify-between text-xs">
                    <div className="flex gap-3 items-center min-w-0">
                      <img
                        src={banner.imageUrl}
                        alt=""
                        className="w-20 h-14 object-cover rounded-xl border border-zinc-150 flex-shrink-0"
                      />
                      <div className="min-w-0">
                        <h4 className="font-bold text-zinc-950 truncate">{banner.title}</h4>
                        <p className="text-[10.5px] text-zinc-500 mt-1">{banner.subtitle}</p>
                        {banner.couponCode && (
                          <span className="inline-block bg-amber-50 text-amber-800 text-[9px] font-bold px-1.5 py-0.5 rounded mt-1 ml-1">
                            كوبون مرتبط: {banner.couponCode}
                          </span>
                        )}
                        {banner.categorySlug && (
                          <span className="inline-block bg-blue-50 text-blue-800 text-[9px] font-bold px-1.5 py-0.5 rounded mt-1 ml-1 font-mono">
                            القسم: {categories.find(c => c.slug === banner.categorySlug)?.name || banner.categorySlug}
                          </span>
                        )}
                        {banner.animationType && banner.animationType !== 'none' && (
                          <span className="inline-block bg-purple-50 text-purple-800 text-[9px] font-bold px-1.5 py-0.5 rounded mt-1 font-mono">
                            حركة: {banner.animationType}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 flex-shrink-0 w-full md:w-auto justify-end">
                      <button
                        onClick={() => {
                          const updated = banners.map(b => b.id === banner.id ? { ...b, isActive: !b.isActive } : b);
                          onUpdateBanners(updated);
                          triggerToast('تم تحديث حالة تفعيل البنر الإعلاني 🔄');
                        }}
                        className={`px-3 py-1.5 rounded-lg font-bold text-[10px] border ${
                          banner.isActive
                            ? 'bg-emerald-50 text-emerald-600 border-emerald-200'
                            : 'bg-zinc-50 text-zinc-400 border-zinc-200'
                        }`}
                      >
                        {banner.isActive ? 'مفعّل في المتجر' : 'معطّل مؤقتاً'}
                      </button>

                      <button
                        onClick={() => {
                          const updated = banners.filter(b => b.id !== banner.id);
                          onUpdateBanners(updated);
                          triggerToast('تم حذف البنر الإعلاني نهائياً 🗑️');
                        }}
                        className="text-zinc-400 hover:text-red-500 p-2 rounded-lg hover:bg-zinc-50 transition-all cursor-pointer"
                      >
                        <Trash2 className="w-4.5 h-4.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* 9. NOTIFICATIONS MANAGEMENT TAB */}
      {activeTab === 'notifications' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start text-right" dir="rtl">
          {/* Send Notification Form */}
          <div className="lg:col-span-5 bg-white p-6 rounded-3xl border border-zinc-150 space-y-4">
            <h3 className="font-black text-sm text-zinc-900 border-b border-zinc-100 pb-2.5 flex items-center gap-1.5">
              <Megaphone className="w-5 h-5 text-amber-500" />
              <span>إرسال إشعار ترويجي / نظامي للعملاء</span>
            </h3>

            <form onSubmit={(e) => {
              e.preventDefault();
              const formData = new FormData(e.currentTarget);
              const title = formData.get('title') as string;
              const message = formData.get('message') as string;
              const type = formData.get('type') as 'order' | 'offer' | 'system' | 'chat';
              if (!title || !message) return;

              onAddNotification(title, message, type);
              e.currentTarget.reset();
              triggerToast('تم بث الإشعار بنجاح لجميع عملاء تطبيق متجر مها 📢');
            }} className="space-y-4">
              <div>
                <label className="text-[10px] text-zinc-400 font-bold block mb-1">عنوان التنبيه أو الإشعار *</label>
                <input
                  type="text"
                  name="title"
                  required
                  placeholder="مثال: خصومات كبرى بمناسبة حلول الشهر الفضيل"
                  className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white"
                />
              </div>

              <div>
                <label className="text-[10px] text-zinc-400 font-bold block mb-1">نص ومحتوى الإشعار *</label>
                <textarea
                  name="message"
                  required
                  rows={4}
                  placeholder="اكتب هنا التفاصيل المشوقة لعرضك أو التحديث نظامي..."
                  className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white resize-none"
                />
              </div>

              <div>
                <label className="text-[10px] text-zinc-400 font-bold block mb-1">نوع وتصنيف الإشعار *</label>
                <select
                  name="type"
                  className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 cursor-pointer"
                >
                  <option value="offer">⚡ عرض خاص وترويج عروض</option>
                  <option value="system">📢 نظامي وعام من متجر مها</option>
                  <option value="order">📦 تنبيه يخص حالات الشحن والتوصيل</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full bg-zinc-950 text-white text-xs font-bold py-2.5 rounded-xl transition-all hover:bg-amber-500 hover:text-zinc-950 cursor-pointer"
              >
                إرسال وبث الإشعار الفوري للعملاء
              </button>
            </form>
          </div>

          {/* Notification tips / info */}
          <div className="lg:col-span-7 bg-zinc-50 p-6 rounded-3xl border border-zinc-150 space-y-4">
            <h3 className="font-extrabold text-sm text-zinc-950 border-b border-zinc-150 pb-3 flex items-center gap-1.5">
              <span>🚀 آلية بث الإشعارات والتأثير الفوري</span>
            </h3>
            <p className="text-zinc-600 text-xs leading-relaxed">
              عند بث إشعار جديد من خلال لوحة تحكم متجر مها الفردية، سيتم نشره فوراً لجميع الزوار والعملاء على المنصة ليظهر في صندوق الوارد الخاص بهم. يمكنك استخدام هذه الميزة في:
            </p>
            <ul className="space-y-2 text-xs text-zinc-600 list-disc list-inside mr-2">
              <li>الإعلان عن قسائم شرائية جديدة مثل <span className="font-mono font-bold text-amber-600">MAHA15</span> خصم 15%.</li>
              <li>التنبيه بتوفر منتج متميز جداً نفذ مخزونه مسبقاً في قسم العطور أو الملابس الفاخرة.</li>
              <li>مواكبة وتنبيه العملاء بحسابات الدفع وتحديث خدمات التوصيل في المحافظات اليمنية.</li>
            </ul>
            <div className="bg-amber-50 border border-amber-200/50 p-4 rounded-2xl flex gap-3 items-center">
              <span className="text-xl">💡</span>
              <p className="text-[11px] text-amber-800 leading-relaxed font-bold">
                تذكر أن صياغة العناوين باللغة العربية الواضحة والمشجعة تساهم بنسبة 40% في رفع معدلات المبيعات وعودة العملاء للتسوق من متجر مها.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* 10. INQUIRIES MANAGEMENT TAB */}
      {activeTab === 'inquiries' && (
        <div className="space-y-6 text-right font-sans" dir="rtl">
          <div className="border-b border-zinc-150 pb-3 flex items-center justify-between">
            <h3 className="font-extrabold text-sm text-zinc-950 flex items-center gap-1.5">
              <HelpCircle className="w-4.5 h-4.5 text-amber-500" />
              <span>استفسارات العملاء والرسائل الواردة من نموذج الاتصال ({inquiries.length})</span>
            </h3>
            <span className="text-[10px] bg-zinc-100 text-zinc-500 px-2.5 py-1 rounded-full font-bold">
              تحديث فوري
            </span>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {inquiries.length === 0 ? (
              <div className="bg-white text-center py-12 rounded-3xl border border-zinc-150 text-xs text-zinc-400 space-y-2">
                <div className="text-3xl">📥</div>
                <p className="font-bold text-zinc-700">لا توجد رسائل أو استفسارات واردة حالياً</p>
                <p className="text-[10px] text-zinc-400">أي رسالة يرسلها العملاء من نموذج الاتصال في تذييل الصفحة ستظهر هنا فوراً.</p>
              </div>
            ) : (
              inquiries.map((inq) => {
                const trimmedContact = inq.contact.trim();
                const isPhone = /^[0-9+]+$/.test(trimmedContact.replace(/[\s-]/g, ''));
                // Pre-fill a whatsapp link if it looks like a phone number, otherwise use standard mailto
                const replyLink = isPhone 
                  ? `https://wa.me/${trimmedContact.replace(/[^0-9+]/g, '')}?text=${encodeURIComponent(`مرحباً يا فندم ${inq.name}، معك خدمة عملاء متجر مها للأناقة. بخصوص استفسارك الكريم: `)}`
                  : `mailto:${trimmedContact}?subject=${encodeURIComponent('بخصوص استفسارك في متجر مها')}`;

                return (
                  <div
                    key={inq.id}
                    className={`bg-white p-5 rounded-2xl border transition-all ${
                      inq.isRead ? 'border-zinc-150 bg-zinc-50/30' : 'border-amber-200 bg-amber-50/10 shadow-xs'
                    } flex flex-col md:flex-row md:items-start justify-between gap-4`}
                  >
                    <div className="space-y-2.5 min-w-0 flex-grow">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-extrabold text-zinc-900 text-xs">{inq.name}</span>
                        <span className="text-zinc-300">•</span>
                        <span className="text-zinc-500 font-mono text-[11px] bg-zinc-100 px-2 py-0.5 rounded-md">{inq.contact}</span>
                        <span className="text-zinc-300">•</span>
                        <span className="text-[10px] text-zinc-400 flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-zinc-400" />
                          <span>
                            {new Date(inq.createdAt).toLocaleString('ar-YE', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' })}
                          </span>
                        </span>
                        {!inq.isRead && (
                          <span className="bg-amber-100 text-amber-800 text-[9px] font-bold px-2 py-0.5 rounded-full animate-pulse border border-amber-200">
                            جديد
                          </span>
                        )}
                      </div>

                      <p className="text-zinc-700 text-xs leading-relaxed font-medium bg-zinc-50/50 p-3 rounded-xl border border-zinc-100">
                        {inq.message}
                      </p>
                    </div>

                    <div className="flex items-center gap-2 flex-shrink-0 self-end md:self-start">
                      {!inq.isRead && (
                        <button
                          onClick={() => {
                            onMarkInquiryRead(inq.id);
                            triggerToast('تم تحديد الاستفسار كمقروء ✔️');
                          }}
                          className="bg-emerald-50 hover:bg-emerald-100 text-emerald-700 hover:text-emerald-800 border border-emerald-200/50 text-[10.5px] font-bold px-3 py-1.5 rounded-xl transition-all flex items-center gap-1 cursor-pointer"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>تحديد كمقروء</span>
                        </button>
                      )}

                      <a
                        href={replyLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bg-zinc-950 hover:bg-amber-500 hover:text-zinc-950 text-white border border-zinc-800 text-[10.5px] font-bold px-3 py-1.5 rounded-xl transition-all flex items-center gap-1 cursor-pointer"
                      >
                        {isPhone ? '💬 رد عبر واتساب' : '✉️ رد بالإيميل'}
                      </a>

                      <button
                        onClick={() => {
                          onDeleteInquiry(inq.id);
                          triggerToast('تم حذف الاستفسار نهائياً 🗑️');
                        }}
                        className="text-zinc-400 hover:text-red-500 hover:bg-red-50 p-2 rounded-xl transition-all cursor-pointer border border-transparent hover:border-red-100"
                        title="حذف الرسالة"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* 11. GENERAL STORE SETTINGS & CUSTOM CSS TAB */}
      {activeTab === 'store_settings' && !isEmployee && (
        <div className="space-y-6 text-right font-sans" dir="rtl">
          <div className="border-b border-zinc-150 pb-3 flex items-center justify-between">
            <h3 className="font-extrabold text-sm text-zinc-950 flex items-center gap-1.5">
              <Settings className="w-4.5 h-4.5 text-amber-500" />
              <span>إعدادات المتجر العامة وتخصيص المظهر بأكواد CSS</span>
            </h3>
            <span className="text-[10px] bg-amber-50 text-amber-700 px-2.5 py-1 rounded-full font-bold border border-amber-200">
              لوحة التحكم الاحترافية 👑
            </span>
          </div>

          <form onSubmit={(e) => {
            e.preventDefault();
            const formData = new FormData(e.currentTarget);
            
            const updatedSettings = {
              name: formData.get('name') as string,
              logo: storeLogoUrl,
              description: formData.get('description') as string,
              phone: formData.get('phone') as string,
              whatsapp: formData.get('whatsapp') as string,
              email: formData.get('email') as string,
              address: formData.get('address') as string,
              socialLinks: {
                facebook: formData.get('facebook') as string,
                instagram: formData.get('instagram') as string,
                twitter: formData.get('twitter') as string,
                whatsapp: `https://wa.me/${(formData.get('whatsapp') as string).replace(/[^0-9]/g, '')}`
              },
              shippingCostDefault: Number(formData.get('shippingCost') || 0),
              customCss: formData.get('customCss') as string,
              themeColor: storeThemeColor,
              androidAppLink: formData.get('androidAppLink') as string,
              iphoneAppLink: formData.get('iphoneAppLink') as string,
              gscVerificationCode: formData.get('gscVerificationCode') as string,
              ga4MeasurementId: formData.get('ga4MeasurementId') as string,
              gtmId: formData.get('gtmId') as string,
              privacyPolicy: formData.get('privacyPolicy') as string,
              termsConditions: formData.get('termsConditions') as string,
            };

            onUpdateStoreSettings(updatedSettings);
            triggerToast('تم حفظ جميع إعدادات المتجر العامة والمظهر المخصص بنجاح! 💾✨');
          }} className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* General Info & Contact */}
            <div className="lg:col-span-7 bg-white p-6 rounded-3xl border border-zinc-150 space-y-5">
              <h4 className="font-bold text-xs text-zinc-900 border-b border-zinc-100 pb-2 flex items-center gap-1.5">
                <span>📍 البيانات التعريفية والاتصال</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] text-zinc-400 font-bold block mb-1">اسم المتجر الالكتروني *</label>
                  <input
                    type="text"
                    name="name"
                    required
                    defaultValue={storeSettings.name}
                    className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-zinc-400 font-bold block mb-1">شعار المتجر (رفع صورة مباشرة أو إيموجي)</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="👑"
                      value={storeLogoUrl && !storeLogoUrl.startsWith('data:') ? storeLogoUrl : ''}
                      onChange={(e) => setStoreLogoUrl(e.target.value || '👑')}
                      className="w-16 text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 text-center font-mono focus:bg-white"
                      maxLength={4}
                      title="أدخل إيموجي أو ارفع صورة بالجانب"
                    />
                    <label className="flex-grow text-xs p-2 rounded-xl border border-dashed border-zinc-300 hover:border-amber-500 bg-zinc-50 hover:bg-zinc-100 flex items-center justify-center text-center cursor-pointer select-none font-bold">
                      <span>📤 رفع صورة شعار</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => {
                          if (e.target.files && e.target.files[0]) {
                            const file = e.target.files[0];
                            if (file.size > 2.5 * 1024 * 1024) {
                              triggerToast('⚠️ حجم الشعار كبير جداً (أقصى حد 2.5 ميجابايت)');
                              return;
                            }
                            const reader = new FileReader();
                            reader.onload = (re) => {
                              if (re.target?.result && typeof re.target.result === 'string') {
                                setStoreLogoUrl(re.target.result);
                                triggerToast('تم رفع شعار المتجر بنجاح! 👑✨');
                              }
                            };
                            reader.readAsDataURL(file);
                          }
                        }}
                        className="hidden"
                      />
                    </label>
                  </div>
                  
                  {storeLogoUrl && storeLogoUrl.startsWith('data:') && (
                    <div className="flex items-center gap-2 mt-2 bg-zinc-50 p-2 rounded-xl border border-zinc-150 w-fit">
                      <span className="text-[10px] text-zinc-400 font-bold">معاينة الشعار المرفوع:</span>
                      <img src={storeLogoUrl} alt="شعار المتجر" className="w-10 h-10 object-contain rounded border border-zinc-200" referrerPolicy="no-referrer" />
                      <button type="button" onClick={() => setStoreLogoUrl('👑')} className="text-red-500 text-[10px] hover:underline font-bold">إزالة الشعار</button>
                    </div>
                  )}
                </div>
              </div>

              {/* Brand Theme Color Selector */}
              <div className="bg-zinc-50/50 p-4 rounded-2xl border border-zinc-150 space-y-3">
                <label className="text-[10.5px] text-zinc-600 font-extrabold block">🎨 لون الشعار والهوية البصرية للمتجر (Theme Color)</label>
                <p className="text-[9.5px] text-zinc-400">سيتم استخدام هذا اللون تلقائياً لتمييز عناصر فاتورة المبيعات الإلكترونية وبوليصة الشحن (الحدود، النصوص، العناوين، والختم المعتمد).</p>
                <div className="flex flex-wrap items-center gap-2">
                  {[
                    { hex: '#f59e0b', name: 'ذهبي / خردلي' },
                    { hex: '#e11d48', name: 'أحمر روز / ياقوتي' },
                    { hex: '#10b981', name: 'أخضر زمردي' },
                    { hex: '#1d4ed8', name: 'أزرق ملكي' },
                    { hex: '#7c3aed', name: 'بنفسجي ملكي' },
                    { hex: '#0f172a', name: 'أسود فحمي' },
                  ].map((clr) => (
                    <button
                      key={clr.hex}
                      type="button"
                      onClick={() => {
                        setStoreThemeColor(clr.hex);
                        triggerToast(`تم اختيار لون الهوية: ${clr.name} 🎨`);
                      }}
                      className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl border text-[10px] font-bold transition-all cursor-pointer hover:scale-105"
                      style={{
                        borderColor: storeThemeColor === clr.hex ? clr.hex : '#e4e4e7',
                        backgroundColor: storeThemeColor === clr.hex ? `${clr.hex}15` : '#ffffff',
                        color: storeThemeColor === clr.hex ? clr.hex : '#3f3f46'
                      }}
                    >
                      <span className="w-3 h-3 rounded-full inline-block border border-black/10" style={{ backgroundColor: clr.hex }} />
                      <span>{clr.name}</span>
                    </button>
                  ))}

                  <div className="flex items-center gap-2 border-r border-zinc-200 pr-2.5 mr-1">
                    <span className="text-[10px] text-zinc-400 font-bold">مخصص:</span>
                    <input
                      type="color"
                      value={storeThemeColor}
                      onChange={(e) => setStoreThemeColor(e.target.value)}
                      className="w-7 h-7 rounded-lg border border-zinc-200 cursor-pointer p-0 overflow-hidden"
                      title="اختر لوناً مخصصاً"
                    />
                    <input
                      type="text"
                      value={storeThemeColor}
                      onChange={(e) => setStoreThemeColor(e.target.value)}
                      className="w-20 text-center font-mono text-[10.5px] p-1 border border-zinc-200 rounded-lg bg-white"
                      placeholder="#f59e0b"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="text-[10px] text-zinc-400 font-bold block mb-1">وصف المتجر التعريفي (يظهر في أسفل الصفحة) *</label>
                <textarea
                  name="description"
                  required
                  rows={3}
                  defaultValue={storeSettings.description}
                  className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white resize-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-[10px] text-zinc-400 font-bold block mb-1">رقم الهاتف للدعم *</label>
                  <input
                    type="text"
                    name="phone"
                    required
                    defaultValue={storeSettings.phone}
                    className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white text-left font-mono"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-zinc-400 font-bold block mb-1">رقم واتساب المباشر *</label>
                  <input
                    type="text"
                    name="whatsapp"
                    required
                    defaultValue={storeSettings.whatsapp}
                    className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white text-left font-mono"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-zinc-400 font-bold block mb-1">البريد الإلكتروني الرسمي *</label>
                  <input
                    type="email"
                    name="email"
                    required
                    defaultValue={storeSettings.email}
                    className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white text-left font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] text-zinc-400 font-bold block mb-1">عنوان المتجر والمقر الرئيسي *</label>
                <input
                  type="text"
                  name="address"
                  required
                  defaultValue={storeSettings.address}
                  className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 border-t border-zinc-100 pt-4">
                <div>
                  <label className="text-[10px] text-zinc-400 font-bold block mb-1">حساب فيسبوك (رابط)</label>
                  <input
                    type="url"
                    name="facebook"
                    defaultValue={storeSettings.socialLinks?.facebook}
                    placeholder="https://facebook.com/..."
                    className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white text-left font-mono"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-zinc-400 font-bold block mb-1">حساب إنستغرام (رابط)</label>
                  <input
                    type="url"
                    name="instagram"
                    defaultValue={storeSettings.socialLinks?.instagram}
                    placeholder="https://instagram.com/..."
                    className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white text-left font-mono"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-zinc-400 font-bold block mb-1">حساب تويتر/إكس (رابط)</label>
                  <input
                    type="url"
                    name="twitter"
                    defaultValue={storeSettings.socialLinks?.twitter}
                    placeholder="https://twitter.com/..."
                    className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white text-left font-mono"
                  />
                </div>
              </div>

              <div className="border-t border-zinc-100 pt-4">
                <div>
                  <label className="text-[10px] text-zinc-400 font-bold block mb-1">تكلفة الشحن الافتراضية للطلب (ر.ي) *</label>
                  <input
                    type="number"
                    name="shippingCost"
                    required
                    defaultValue={storeSettings.shippingCostDefault}
                    className="w-48 text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white font-mono text-left"
                  />
                </div>
              </div>

              {/* Mobile App Download Links */}
              <div className="border-t border-zinc-100 pt-4 space-y-3">
                <h5 className="text-[11px] font-extrabold text-zinc-800 flex items-center gap-1.5">
                  <span>📱 روابط تحميل تطبيقات الهواتف الذكية (Android & iOS)</span>
                </h5>
                <p className="text-[9.5px] text-zinc-400">اترك الحقول فارغة ليظهر للعميل تنويه "التطبيق قريباً"، أو أدخل روابط حقيقية لتفعيل أزرار التحميل المباشر.</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] text-zinc-400 font-bold block mb-1">رابط تطبيق Android (Google Play)</label>
                    <input
                      type="url"
                      name="androidAppLink"
                      defaultValue={storeSettings.androidAppLink || ''}
                      placeholder="https://play.google.com/store/apps/details?id=..."
                      className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white text-left font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-zinc-400 font-bold block mb-1">رابط تطبيق iPhone (App Store)</label>
                    <input
                      type="url"
                      name="iphoneAppLink"
                      defaultValue={storeSettings.iphoneAppLink || ''}
                      placeholder="https://apps.apple.com/app/id..."
                      className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white text-left font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Google SEO Integration */}
              <div className="border-t border-zinc-100 pt-4 space-y-3">
                <h5 className="text-[11px] font-extrabold text-zinc-800 flex items-center gap-1.5">
                  <span>🔍 ربط Google وتحسين محركات البحث (SEO & GSC)</span>
                </h5>
                <p className="text-[9.5px] text-zinc-400">سيتم دمج وتفعيل هذه المعرفات تلقائياً في شفرة المتجر دون الحاجة لتعديل الكود البرمجي مستقبلاً.</p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="text-[10px] text-zinc-400 font-bold block mb-1">رمز تحقق Google Search Console</label>
                    <input
                      type="text"
                      name="gscVerificationCode"
                      defaultValue={storeSettings.gscVerificationCode || ''}
                      placeholder="google-site-verification-..."
                      className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white text-left font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-zinc-400 font-bold block mb-1">معرف قياس Google Analytics 4</label>
                    <input
                      type="text"
                      name="ga4MeasurementId"
                      defaultValue={storeSettings.ga4MeasurementId || ''}
                      placeholder="G-XXXXXXXXXX"
                      className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white text-left font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-zinc-400 font-bold block mb-1">معرف حاوية Google Tag Manager</label>
                    <input
                      type="text"
                      name="gtmId"
                      defaultValue={storeSettings.gtmId || ''}
                      placeholder="GTM-XXXXXXX"
                      className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white text-left font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Legal Policies */}
              <div className="border-t border-zinc-100 pt-4 space-y-3">
                <h5 className="text-[11px] font-extrabold text-zinc-800 flex items-center gap-1.5">
                  <span>📜 الصفحات القانونية وسياسات المتجر</span>
                </h5>
                <p className="text-[9.5px] text-zinc-400">تعديل نصوص صفحات الخصوصية والأحكام والاتصال التي تظهر في تذييل المتجر للعملاء.</p>
                <div className="space-y-3">
                  <div>
                    <label className="text-[10px] text-zinc-400 block mb-1 font-bold">سياسة الخصوصية (Privacy Policy) *</label>
                    <textarea
                      name="privacyPolicy"
                      required
                      rows={3}
                      defaultValue={storeSettings.privacyPolicy}
                      className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white leading-relaxed"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-zinc-400 block mb-1 font-bold">الشروط والأحكام (Terms & Conditions) *</label>
                    <textarea
                      name="termsConditions"
                      required
                      rows={3}
                      defaultValue={storeSettings.termsConditions}
                      className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white leading-relaxed"
                    />
                  </div>
                </div>
              </div>

              {/* Sitemap.xml Viewer & Downloader */}
              <div className="border-t border-zinc-100 pt-4 space-y-3">
                <h5 className="text-[11px] font-extrabold text-zinc-800 flex items-center gap-1.5">
                  <span>🌐 خريطة الموقع والروابط المباشرة (Sitemap.xml)</span>
                </h5>
                <p className="text-[9.5px] text-zinc-400">توليد خريطة الموقع Sitemap.xml تلقائياً لتضمين روابط الفئات، الأقسام، وجميع المنتجات المضافة لربطها بـ Google Search Console لضمان أرشفة فورية وسريعة.</p>
                <div className="bg-zinc-950 p-4 rounded-2xl border border-zinc-800 text-left font-mono text-[9px] text-amber-400 select-all max-h-40 overflow-auto" dir="ltr">
                  {`<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url><loc>${window.location.origin}/</loc><priority>1.0</priority></url>
  <url><loc>${window.location.origin}/#/tracker</loc><priority>0.8</priority></url>
  <url><loc>${window.location.origin}/#/privacy</loc><priority>0.5</priority></url>
  <url><loc>${window.location.origin}/#/terms</loc><priority>0.5</priority></url>
  <url><loc>${window.location.origin}/#/contact</loc><priority>0.6</priority></url>
${products.map(p => `  <url><loc>${window.location.origin}/#/product/${p.id}</loc><priority>0.7</priority></url>`).join('\n')}
${categories.map(c => `  <url><loc>${window.location.origin}/#/category/${c.slug}</loc><priority>0.6</priority></url>`).join('\n')}
</urlset>`}
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const xmlText = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n  <url><loc>${window.location.origin}/</loc><priority>1.0</priority></url>\n  <url><loc>${window.location.origin}/#/tracker</loc><priority>0.8</priority></url>\n  <url><loc>${window.location.origin}/#/privacy</loc><priority>0.5</priority></url>\n  <url><loc>${window.location.origin}/#/terms</loc><priority>0.5</priority></url>\n  <url><loc>${window.location.origin}/#/contact</loc><priority>0.6</priority></url>\n${products.map(p => `  <url><loc>${window.location.origin}/#/product/${p.id}</loc><priority>0.7</priority></url>`).join('\n')}\n${categories.map(c => `  <url><loc>${window.location.origin}/#/category/${c.slug}</loc><priority>0.6</priority></url>`).join('\n')}\n</urlset>`;
                    const blob = new Blob([xmlText], { type: 'application/xml' });
                    const url = URL.createObjectURL(blob);
                    const link = document.createElement('a');
                    link.href = url;
                    link.download = 'sitemap.xml';
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                    URL.revokeObjectURL(url);
                    triggerToast('تم توليد وتنزيل ملف sitemap.xml المحدث بنجاح! 🌐📂');
                  }}
                  className="bg-zinc-100 hover:bg-zinc-200 text-zinc-800 text-[10px] font-extrabold px-3 py-1.5 rounded-xl border border-zinc-200 transition-colors flex items-center gap-1 justify-center cursor-pointer w-full"
                >
                  📥 تحميل ملف Sitemap.xml المحدث للتقديم في Google Search Console
                </button>
              </div>
            </div>

            {/* Custom CSS Code Editor */}
            <div className="lg:col-span-5 bg-white p-6 rounded-3xl border border-zinc-150 flex flex-col h-full space-y-4">
              <div className="border-b border-zinc-100 pb-2">
                <h4 className="font-bold text-xs text-zinc-900 flex items-center gap-1.5">
                  <span>🎨 تخصيص المظهر بأكواد CSS مخصصة</span>
                </h4>
                <p className="text-[10px] text-zinc-400 mt-1">اكتب أكواد CSS مخصصة لتغيير ألوان أو خطوط أو تنسيق المتجر بالكامل فوراً وبشكل حيّ ومباشر!</p>
              </div>

              <div className="flex-grow">
                <div className="bg-zinc-950 rounded-2xl p-4 border border-zinc-800 font-mono text-xs text-emerald-400 overflow-hidden shadow-inner relative">
                  <div className="absolute top-2 left-4 text-[9px] text-zinc-600 select-none">CSS STYLESHEET EDITOR</div>
                  <textarea
                    name="customCss"
                    rows={15}
                    defaultValue={storeSettings.customCss}
                    placeholder={`/* اكتب هنا أكواد الـ CSS */\\n\\nbody {\\n  background-color: #fafafa;\\n}\\n\\n#store-visual-banner {\\n  border-bottom: 2px solid #f59e0b;\\n}`}
                    className="w-full bg-transparent text-emerald-400 font-mono text-xs focus:outline-none resize-y mt-4 leading-relaxed"
                    dir="ltr"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-amber-500 hover:bg-amber-600 text-zinc-950 text-xs font-black py-3 rounded-2xl transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md"
              >
                <span>💾 حفظ جميع التغييرات وإعدادات المظهر</span>
              </button>
            </div>

          </form>
        </div>
      )}

      {/* OVERLAY PRINTABLE DIALOG (INVOICES AND SHIPPING LABELS) */}
      {printingOrder && printType && (
        <div id="print-overlay-modal" className="fixed inset-0 bg-zinc-950/80 backdrop-blur-xs flex items-center justify-center z-50 p-4 overflow-y-auto">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white text-zinc-900 rounded-2xl max-w-2xl w-full p-8 shadow-2xl border border-zinc-300 print:shadow-none print:border-none print:p-0 font-sans relative"
          >
            {/* Action buttons (hidden in real print) */}
            <div className="absolute top-4 left-4 flex gap-2 print:hidden z-10 flex-wrap">
              <button
                onClick={handleDownloadPDF}
                className="text-white font-black text-xs py-2 px-4 rounded-xl flex items-center gap-1.5 transition-all cursor-pointer hover:brightness-95 shadow-md"
                style={{ backgroundColor: storeSettings.themeColor || '#f59e0b' }}
                title="تصدير وتحميل الفاتورة مباشرة بصيغة PDF فاخرة بألوان الهوية"
              >
                <Download className="w-4 h-4 animate-bounce" />
                <span>تحميل PDF الفاخر</span>
              </button>
              <button
                onClick={handlePrint}
                className="bg-zinc-950 hover:bg-zinc-900 text-white font-extrabold text-xs py-2 px-4 rounded-xl flex items-center gap-1.5 transition-all cursor-pointer"
                title="طباعة مباشرة أو حفظ عبر المتصفح"
              >
                <Printer className="w-4 h-4" />
                <span>طباعة سريعة</span>
              </button>
              <button
                onClick={() => {
                  const currencySymbol = storeSettings.currencySymbol || 'ر.ي';
                  const shippingCost = Math.max(0, printingOrder.finalPrice - printingOrder.totalPrice + (printingOrder.discountAmount || 0));
                  
                  const text = `مرحباً ${printingOrder.customerName}، يسعدنا تسوقك من *${storeSettings.name}* 🌸\n\nإليك تفاصيل فاتورة طلبك رقم *INV-${printingOrder.id}*:\n` +
                    `----------------------------------------\n` +
                    printingOrder.items.map(it => `• ${it.productTitle} (العدد: ${it.quantity}) - بسعر: ${it.price.toLocaleString()} ${currencySymbol}`).join('\n') +
                    `\n----------------------------------------\n` +
                    `• المجموع الفرعي: ${printingOrder.totalPrice.toLocaleString()} ${currencySymbol}\n` +
                    (printingOrder.discountAmount > 0 ? `• خصم الكوبون: -${printingOrder.discountAmount.toLocaleString()} ${currencySymbol}\n` : '') +
                    `• رسوم الشحن: ${shippingCost.toLocaleString()} ${currencySymbol}\n` +
                    `• الإجمالي النهائي: *${printingOrder.finalPrice.toLocaleString()} ${currencySymbol}*\n\n` +
                    `• طريقة الدفع: ${
                      printingOrder.paymentMethod === 'cod' ? 'الدفع نقداً عند الاستلام' :
                      printingOrder.paymentMethod === 'kuraimi' ? 'بنك الكريمي' :
                      printingOrder.paymentMethod === 'jeeb' ? 'محفظة جيب' : 'تحويل مصرفي مباشر'
                    }\n` +
                    `• حالة الطلب: *${
                      printingOrder.status === 'pending' ? 'قيد الانتظار والمراجعة' :
                      printingOrder.status === 'processing' ? 'قيد التجهيز' :
                      printingOrder.status === 'shipped' ? 'تم الشحن' :
                      printingOrder.status === 'delivered' ? 'تم التسليم' : 'ملغي'
                    }*\n\n` +
                    `متجر: ${storeSettings.name}\n` +
                    `للتواصل والدعم: ${storeSettings.phone}\n` +
                    `العنوان: ${storeSettings.address}\n` +
                    `شكراً لك على ثقتك بمتجرنا وبانتظار زيارتك القادمة! 👑`;
                    
                  const encodedText = encodeURIComponent(text);
                  let cleanPhone = printingOrder.customerPhone.replace(/[^0-9]/g, '');
                  if (cleanPhone.startsWith('7') && cleanPhone.length === 9) {
                    cleanPhone = '967' + cleanPhone;
                  }
                  window.open(`https://wa.me/${cleanPhone}?text=${encodedText}`, '_blank');
                }}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-2 px-4 rounded-xl flex items-center gap-1.5 transition-all cursor-pointer"
                title="إرسال تفاصيل الفاتورة مباشرة للزبون عبر واتساب"
              >
                <MessageSquare className="w-4 h-4" />
                <span>إرسال الفاتورة للعميل</span>
              </button>
              <button
                onClick={() => {
                  setPrintingOrder(null);
                  setPrintType(null);
                }}
                className="bg-zinc-100 hover:bg-zinc-200 text-zinc-800 font-bold text-xs py-2 px-4 rounded-xl cursor-pointer"
              >
                إغلاق النافذة
              </button>
            </div>

            {/* Screen-Only instructions for PDF printing */}
            <div className="print:hidden bg-zinc-50/80 border border-zinc-200/80 p-4 rounded-2xl text-right mt-12 mb-4 space-y-1.5 shadow-sm">
              <h4 className="font-extrabold text-xs text-zinc-900 flex items-center gap-1.5">
                <span className="text-base">💡</span>
                <span>طريقة حفظ الفاتورة بتنسيق PDF وألوان شعار متجرك:</span>
              </h4>
              <p className="text-[10.5px] text-zinc-600 leading-relaxed">
                عند الضغط على زر <strong className="text-zinc-950 font-black">"طباعة / تنزيل PDF"</strong> بالأعلى، تفتح لك نافذة الطباعة:
              </p>
              <ul className="text-[10.5px] text-zinc-500 list-disc list-inside space-y-1 pr-1 font-medium">
                <li>قم بتغيير الوجهة <strong className="text-zinc-800">(Destination)</strong> إلى <strong className="text-zinc-950">"حفظ بتنسيق PDF" (Save as PDF)</strong> لحفظها مباشرة على جهازك.</li>
                <li><strong className="text-zinc-950">مهم جداً:</strong> احرص على تفعيل خيار <strong className="text-zinc-950">"رسومات الخلفية" (Background graphics)</strong> من الإعدادات لتصدير ألوان الشعار والتصميم الفاخر بدقة ممتازة!</li>
              </ul>
            </div>

            {/* Direct style injection for exact print quality & color rendering */}
            <style dangerouslySetInnerHTML={{ __html: `
              @media print {
                body {
                  -webkit-print-color-adjust: exact !important;
                  print-color-adjust: exact !important;
                  background: white !important;
                }
                #print-overlay-modal {
                  background: white !important;
                  position: absolute !important;
                  inset: 0 !important;
                  width: 100% !important;
                  height: auto !important;
                  overflow: visible !important;
                  z-index: 9999 !important;
                  padding: 0 !important;
                }
                .print\\:hidden {
                  display: none !important;
                }
                /* Hide everything in root except modal printable section */
                #root > *:not(#print-overlay-modal) {
                  display: none !important;
                }
              }
            ` }} />

            {/* PRINT MATERIAL */}
            <div id="printable-area" className="printable-area space-y-6 pt-10 print:pt-0 font-sans text-right" dir="rtl">
              {/* Type 1: Invoice (فاتورة ضريبية مبسطة) */}
              {printType === 'invoice' && (
                <div className="space-y-6 text-right" dir="rtl">
                  {/* Header */}
                  <div className="flex justify-between items-start border-b-2 pb-5" style={{ borderColor: storeSettings.themeColor || '#f59e0b' }}>
                    <div className="flex items-center gap-4">
                      {storeSettings.logo && storeSettings.logo.startsWith('data:') ? (
                        <img src={storeSettings.logo} alt={storeSettings.name} className="w-16 h-16 object-contain rounded-2xl border" style={{ borderColor: `${storeSettings.themeColor || '#f59e0b'}30` }} referrerPolicy="no-referrer" />
                      ) : (
                        <span className="text-4xl bg-zinc-100 w-16 h-16 rounded-2xl flex items-center justify-center border" style={{ backgroundColor: `${storeSettings.themeColor || '#f59e0b'}10`, borderColor: `${storeSettings.themeColor || '#f59e0b'}25` }}>{storeSettings.logo || '👑'}</span>
                      )}
                      <div>
                        <h1 className="text-2xl font-black text-zinc-900" style={{ color: storeSettings.themeColor || '#f59e0b' }}>{storeSettings.name}</h1>
                        <p className="text-[11px] text-zinc-500 max-w-sm leading-relaxed mt-1">{storeSettings.description}</p>
                      </div>
                    </div>
                    <div className="text-left font-sans text-xs text-zinc-500 space-y-1">
                      <h2 className="text-base font-black text-zinc-900 mb-1" style={{ color: storeSettings.themeColor || '#f59e0b' }}>فاتورة مبيعات إلكترونية</h2>
                      <p className="font-mono">الرقم المرجعي: <span className="font-bold text-zinc-800">INV-{printingOrder.id}</span></p>
                      <p className="font-mono">تاريخ الإصدار: {new Date(printingOrder.createdAt).toLocaleDateString('ar-YE')}</p>
                    </div>
                  </div>

                  {/* Customer & Seller info */}
                  <div className="grid grid-cols-2 gap-4 text-xs bg-zinc-50/50 p-4 rounded-2xl border" style={{ borderColor: `${storeSettings.themeColor || '#f59e0b'}15` }}>
                    <div className="space-y-1.5">
                      <span className="font-extrabold block border-b pb-1.5 mb-1.5 text-[11px]" style={{ color: storeSettings.themeColor || '#f59e0b', borderColor: `${storeSettings.themeColor || '#f59e0b'}20` }}>👤 بيانات العميل (المستلم):</span>
                      <p className="font-extrabold text-zinc-900 text-sm">{printingOrder.customerName}</p>
                      <p className="font-mono text-zinc-700">📱 {printingOrder.customerPhone}</p>
                      <p className="text-zinc-600">📍 {printingOrder.customerAddress}</p>
                    </div>
                    <div className="space-y-1.5 text-right sm:text-left sm:border-r sm:pr-4" style={{ borderColor: `${storeSettings.themeColor || '#f59e0b'}20` }}>
                      <span className="font-extrabold block border-b pb-1.5 mb-1.5 sm:text-left text-[11px]" style={{ color: storeSettings.themeColor || '#f59e0b', borderColor: `${storeSettings.themeColor || '#f59e0b'}20` }}>🏢 بيانات المتجر والاتصال:</span>
                      <p className="font-extrabold text-zinc-900">{storeSettings.name}</p>
                      <p className="font-mono text-zinc-700">📞 {storeSettings.phone}</p>
                      <p className="font-mono text-zinc-700">💬 واتساب: {storeSettings.whatsapp}</p>
                      <p className="text-zinc-600">📧 {storeSettings.email}</p>
                      <p className="text-zinc-600">📍 {storeSettings.address}</p>
                    </div>
                  </div>

                  {/* Payment Info */}
                  <div className="border p-4 rounded-2xl text-xs flex justify-between items-center" style={{ backgroundColor: `${storeSettings.themeColor || '#f59e0b'}05`, borderColor: `${storeSettings.themeColor || '#f59e0b'}20` }}>
                    <div>
                      <span className="text-zinc-500 block text-[10px] mb-0.5">طريقة السداد المعتمدة:</span>
                      <span className="font-extrabold text-zinc-900 text-sm flex items-center gap-1">
                        {printingOrder.paymentMethod === 'cod' && '💵 الدفع نقداً عند الاستلام (COD)'}
                        {printingOrder.paymentMethod === 'kuraimi' && '📱 حوالة بنك الكريمي'}
                        {printingOrder.paymentMethod === 'jeeb' && '📱 محفظة جيب الإلكترونية'}
                        {printingOrder.paymentMethod === 'bank_transfer' && '🏦 تحويل مصرفي مباشر'}
                      </span>
                    </div>
                    {printingOrder.paymentDetails ? (
                      <div className="text-left">
                        <span className="text-zinc-500 block text-[10px]">الرقم المرجعي للتحويل:</span>
                        <span className="font-mono bg-white px-2.5 py-1 rounded-lg border font-bold inline-block mt-1 shadow-sm" style={{ borderColor: `${storeSettings.themeColor || '#f59e0b'}30` }}>
                          {printingOrder.paymentDetails}
                        </span>
                      </div>
                    ) : (
                      <div className="text-left">
                        <span className="text-zinc-500 block text-[10px] mb-1">حالة الدفع:</span>
                        <span className="font-bold px-3 py-1 rounded-full text-[11px]" style={{
                          backgroundColor: printingOrder.paymentMethod === 'cod' ? '#fef3c7' : '#d1fae5',
                          color: printingOrder.paymentMethod === 'cod' ? '#d97706' : '#059669'
                        }}>
                          {printingOrder.paymentMethod === 'cod' ? 'معلق عند الاستلام' : 'مكتمل (دفع مسبق)'}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Items list */}
                  <div className="border rounded-2xl overflow-hidden" style={{ borderColor: `${storeSettings.themeColor || '#f59e0b'}20` }}>
                    <div className="overflow-x-auto">
                      <table className="w-full text-xs text-right">
                      <thead className="border-b" style={{ backgroundColor: `${storeSettings.themeColor || '#f59e0b'}0a`, borderColor: `${storeSettings.themeColor || '#f59e0b'}20` }}>
                        <tr>
                          <th className="p-3.5 font-bold" style={{ color: storeSettings.themeColor || '#f59e0b' }}>المنتج والسلعة المشتراة</th>
                          <th className="p-3.5 font-bold text-center" style={{ color: storeSettings.themeColor || '#f59e0b' }}>الكمية</th>
                          <th className="p-3.5 font-bold text-left" style={{ color: storeSettings.themeColor || '#f59e0b' }}>سعر الوحدة</th>
                          <th className="p-3.5 font-bold text-left" style={{ color: storeSettings.themeColor || '#f59e0b' }}>الإجمالي الفرعي</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-zinc-100">
                        {printingOrder.items.map((it, idx) => (
                          <tr key={idx} className="hover:bg-zinc-50/50">
                            <td className="p-3.5 font-bold text-zinc-900">
                              {it.productTitle}
                              {it.selectedOptions && Object.keys(it.selectedOptions).length > 0 && (
                                <span className="block text-[10px] text-zinc-400 font-normal mt-1">
                                  {Object.entries(it.selectedOptions).map(([k, v]) => `${k}: ${v}`).join(' | ')}
                                </span>
                              )}
                            </td>
                            <td className="p-3.5 text-center font-bold font-mono text-zinc-700">{it.quantity}</td>
                            <td className="p-3.5 text-left font-mono text-zinc-600">{(it.price ?? 0).toLocaleString()} {storeSettings.currencySymbol}</td>
                            <td className="p-3.5 text-left font-mono font-bold text-zinc-950">{((it.price ?? 0) * it.quantity).toLocaleString()} {storeSettings.currencySymbol}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                  {/* Pricing summary */}
                  <div className="flex justify-between items-start pt-3 border-t border-zinc-100">
                    <div className="text-right text-[10px] text-zinc-400 max-w-sm">
                      <span className="font-bold text-zinc-700 block mb-1">حالة الطلب الحالية:</span>
                      <span className="font-bold text-xs inline-block px-3 py-1 rounded-full" style={{
                        backgroundColor: 
                          printingOrder.status === 'pending' ? '#fef3c7' :
                          printingOrder.status === 'processing' ? '#dbeafe' :
                          printingOrder.status === 'shipped' ? '#f3e8ff' :
                          printingOrder.status === 'delivered' ? '#d1fae5' : '#fee2e2',
                        color:
                          printingOrder.status === 'pending' ? '#b45309' :
                          printingOrder.status === 'processing' ? '#1d4ed8' :
                          printingOrder.status === 'shipped' ? '#6b21a8' :
                          printingOrder.status === 'delivered' ? '#065f46' : '#991b1b'
                      }}>
                        {printingOrder.status === 'pending' ? 'جديد (قيد المراجعة)' :
                         printingOrder.status === 'processing' ? 'قيد التجهيز والتعبئة' :
                         printingOrder.status === 'shipped' ? 'تم الشحن مع المندوب' :
                         printingOrder.status === 'delivered' ? 'تم التسليم والتحصيل' : 'ملغي'}
                      </span>
                    </div>
                    <div className="w-80 space-y-2 text-xs font-bold text-zinc-800">
                      <div className="flex justify-between font-medium text-zinc-500">
                        <span>المجموع الفرعي للسلع:</span>
                        <span className="font-mono">{(printingOrder.totalPrice ?? 0).toLocaleString()} {storeSettings.currencySymbol}</span>
                      </div>
                      {(printingOrder.discountAmount ?? 0) > 0 && (
                        <div className="flex justify-between text-red-600 font-medium">
                          <span>خصم الكوبون الترويجي:</span>
                          <span className="font-mono">-{(printingOrder.discountAmount ?? 0).toLocaleString()} {storeSettings.currencySymbol}</span>
                        </div>
                      )}
                      <div className="flex justify-between font-medium text-zinc-500">
                        <span>رسوم شحن وتوصيل فوري:</span>
                        <span className="font-mono">
                          {Math.max(0, (printingOrder.finalPrice ?? 0) - (printingOrder.totalPrice ?? 0) + (printingOrder.discountAmount ?? 0)).toLocaleString()} {storeSettings.currencySymbol}
                        </span>
                      </div>
                      <div className="border-t pt-2.5 flex justify-between text-sm font-black text-zinc-950 p-2.5 rounded-xl" style={{ backgroundColor: `${storeSettings.themeColor || '#f59e0b'}08`, borderTop: `2px solid ${storeSettings.themeColor || '#f59e0b'}` }}>
                        <span>المبلغ الإجمالي المستحق:</span>
                        <span className="font-mono text-base font-black" style={{ color: storeSettings.themeColor || '#f59e0b' }}>{(printingOrder.finalPrice ?? 0).toLocaleString()} {storeSettings.currencySymbol}</span>
                      </div>
                    </div>
                  </div>

                  {/* Seal and footer signatures */}
                  <div className="pt-8 border-t border-zinc-150 flex justify-between items-end text-xs">
                    <div>
                      <p className="text-zinc-400 font-bold mb-1">ختم وتوقيع المدير</p>
                      <div className="w-24 h-24 rounded-full border-4 flex flex-col items-center justify-center font-black text-[10px] rotate-12 mt-1 select-none shadow-sm" style={{ borderColor: `${storeSettings.themeColor || '#f59e0b'}40`, color: storeSettings.themeColor || '#f59e0b', backgroundColor: `${storeSettings.themeColor || '#f59e0b'}05` }}>
                        <span>{storeSettings.name}</span>
                        <span className="text-[8px] tracking-wide mt-0.5">معتمد وموثق ✅</span>
                      </div>
                    </div>
                    <div className="text-left text-[9.5px] text-zinc-400 leading-relaxed max-w-sm">
                      شكراً لتسوقكم من *{storeSettings.name}*. هذه فاتورة مبيعات رقمية معتمدة تلقائياً ولا تتطلب توقيعاً يدوياً. يسري الاستبدال والاسترجاع خلال 3 أيام بوجود غلاف المنتج الأصلي دون فتح.
                    </div>
                  </div>
                </div>
              )}

              {/* Type 2: Shipping Label (بوليصة الشحن السريع) */}
              {printType === 'shipping_label' && (
                <div className="space-y-6 text-right" dir="rtl">
                  {/* Outer Frame with heavy border simulating physical thermal stickers */}
                  <div className="border-4 p-6 rounded-xl space-y-6" style={{ borderColor: storeSettings.themeColor || '#f59e0b' }}>
                    {/* Top Row with Barcode */}
                    <div className="flex justify-between items-center border-b-2 pb-4" style={{ borderColor: storeSettings.themeColor || '#f59e0b' }}>
                      <div>
                        <div className="font-black text-lg tracking-widest font-mono" style={{ color: storeSettings.themeColor || '#f59e0b' }}>SALLA-YE-{printingOrder.id}</div>
                        <p className="text-[10px] text-zinc-500 mt-1">بوليصة شحن جوي / بري مخصصة للتوصيل الفوري</p>
                      </div>
                      <div className="text-left font-black text-xl text-white px-3 py-1.5 rounded" style={{ backgroundColor: storeSettings.themeColor || '#f59e0b' }}>
                        توصيل فوري
                      </div>
                    </div>

                    {/* Barcode Mock */}
                    <div className="bg-zinc-100 p-4 rounded border border-zinc-300 flex flex-col items-center justify-center space-y-1">
                      <div className="flex gap-0.5 h-12 w-full justify-center">
                        {[
                          2, 1, 3, 1, 2, 4, 1, 2, 3, 1, 4, 1, 2, 2, 1, 3, 1, 4, 2, 1, 3, 1, 2, 1, 4, 1, 2, 2, 1, 3, 1, 2, 4, 1, 2
                        ].map((width, idx) => (
                          <div
                            key={idx}
                            className="h-full"
                            style={{ width: `${width}px`, backgroundColor: storeSettings.themeColor || '#000000' }}
                          ></div>
                        ))}
                      </div>
                      <span className="text-[10px] font-mono tracking-widest text-zinc-600">*{printingOrder.id}*</span>
                    </div>

                    {/* Addresses Grid */}
                    <div className="grid grid-cols-2 divide-x-2 divide-zinc-900 text-xs">
                      {/* Recipient Details */}
                      <div className="pr-4 space-y-2">
                        <span className="text-white font-bold px-2 py-0.5 text-[9px] rounded" style={{ backgroundColor: storeSettings.themeColor || '#f59e0b' }}>المستلم (العميل)</span>
                        <p className="font-black text-sm text-zinc-950 mt-1">{printingOrder.customerName}</p>
                        <p className="font-bold text-zinc-800 font-mono">{printingOrder.customerPhone}</p>
                        <p className="text-zinc-600 text-[11px] leading-relaxed mt-0.5">{printingOrder.customerAddress}</p>
                      </div>

                      {/* Sender Details */}
                      <div className="pl-4 space-y-2 text-left">
                        <span className="text-white font-bold px-2 py-0.5 text-[9px] rounded" style={{ backgroundColor: storeSettings.themeColor || '#f59e0b' }}>المرسل (المتجر)</span>
                        <p className="font-black text-sm text-zinc-950 mt-1">{storeSettings.name}</p>
                        <p className="font-bold text-zinc-800 font-mono">{storeSettings.phone}</p>
                        <p className="text-zinc-600 text-[11px] leading-relaxed mt-0.5">{storeSettings.address}</p>
                      </div>
                    </div>

                    {/* Package details */}
                    <div className="border-t-2 pt-4 grid grid-cols-3 gap-2 text-center text-[10px] font-bold text-zinc-500" style={{ borderColor: storeSettings.themeColor || '#f59e0b' }}>
                      <div>
                        <span>طريقة الدفع:</span>
                        <p className="font-extrabold text-zinc-950 text-xs mt-1">
                          {printingOrder.paymentMethod === 'cod' ? `الدفع عند الاستلام: ${(printingOrder.finalPrice ?? 0).toLocaleString()} ${storeSettings.currencySymbol}` : 'خالص السداد (دفع مسبق)'}
                        </p>
                      </div>
                      <div>
                        <span>عدد القطع الإجمالي:</span>
                        <p className="font-extrabold text-zinc-950 text-xs mt-1">
                          {printingOrder.items.reduce((sum, item) => sum + item.quantity, 0)} قطع
                        </p>
                      </div>
                      <div>
                        <span>توجيهات المندوب:</span>
                        <p className="font-extrabold text-zinc-950 text-xs mt-1">يرجى الاتصال قبل الوصول بـ 30 دقيقة</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
