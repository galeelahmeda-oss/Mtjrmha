import { initializeApp } from 'firebase/app';
import { initializeFirestore, doc, getDocFromServer, setDoc, deleteDoc } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp({
  apiKey: firebaseConfig.apiKey,
  authDomain: firebaseConfig.authDomain,
  projectId: firebaseConfig.projectId,
  storageBucket: firebaseConfig.storageBucket,
  messagingSenderId: firebaseConfig.messagingSenderId,
  appId: firebaseConfig.appId,
});

export const db = firebaseConfig.firestoreDatabaseId 
  ? initializeFirestore(app, { 
      experimentalForceLongPolling: true,
      ignoreUndefinedProperties: true
    }, firebaseConfig.firestoreDatabaseId)
  : initializeFirestore(app, { 
      experimentalForceLongPolling: true,
      ignoreUndefinedProperties: true
    });

async function testConnection() {
  console.log('[Firestore Test] Starting Firestore read/write/delete diagnostic test...');
  try {
    const testDocRef = doc(db, 'products', 'test_connection_doc');
    
    console.log('[Firestore Test] Attempting setDoc (Write)...');
    await setDoc(testDocRef, { 
      id: 'test_connection_doc', 
      title: 'Test connection product', 
      createdAt: new Date().toISOString() 
    });
    console.log('[Firestore Test] setDoc (Write) succeeded!');

    console.log('[Firestore Test] Attempting getDocFromServer (Read)...');
    const fetchedSnap = await getDocFromServer(testDocRef);
    if (fetchedSnap.exists()) {
      console.log('[Firestore Test] getDocFromServer (Read) succeeded:', fetchedSnap.data());
    } else {
      console.warn('[Firestore Test] Document not found after write!');
    }

    console.log('[Firestore Test] Attempting deleteDoc (Delete)...');
    await deleteDoc(testDocRef);
    console.log('[Firestore Test] deleteDoc (Delete) succeeded!');
    console.log('[Firestore Test] Firestore diagnostic check completed perfectly! Full CRUD access is active.');
  } catch (error) {
    console.error('[Firestore Test] Firestore diagnostic check failed with error:', error);
  }
}
testConnection();

