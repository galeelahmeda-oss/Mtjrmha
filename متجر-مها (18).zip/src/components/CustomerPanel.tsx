import { useEffect } from 'react';
import { Star, Heart, MessageSquare, ShoppingBag, Truck, MapPin, Phone, RefreshCw } from 'lucide-react';
import { Product, Order, OrderStatus, User } from '../types';
import { motion } from 'motion/react';

interface CustomerPanelProps {
  orders: Order[];
  wishlist: string[];
  products: Product[];
  currentCustomer: User | null;
  onTriggerLogin: () => void;
  onLogout: () => void;
  onToggleWishlist: (productId: string) => void;
  onAddToCart: (product: Product) => void;
  onOpenChat: (vendorId: string, productTitle?: string, productId?: string) => void;
  onSelectProduct: (product: Product) => void;
  vendors?: User[];
}

export default function CustomerPanel({
  orders,
  wishlist,
  products,
  currentCustomer,
  onTriggerLogin,
  onLogout,
  onToggleWishlist,
  onAddToCart,
  onOpenChat,
  onSelectProduct,
  vendors = [],
}: CustomerPanelProps) {
  // Filter customer orders based on logged-in customer's ID or Phone
  const myOrders = currentCustomer
    ? orders.filter(
        (o) =>
          o.customerId === currentCustomer.id ||
          (currentCustomer.phone && o.customerPhone === currentCustomer.phone)
      )
    : [];
  const wishlistedProducts = products.filter((p) => wishlist.includes(p.id));

  useEffect(() => {
    const handleDeepLink = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (detail && detail.orderId) {
        // Find matching element
        setTimeout(() => {
          const orderEl = document.getElementById(`customer-order-${detail.orderId}`);
          if (orderEl) {
            orderEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
            orderEl.classList.add('border-amber-500', 'ring-4', 'ring-amber-500/20', 'shadow-amber-500/10');
            setTimeout(() => {
              orderEl.classList.remove('border-amber-500', 'ring-4', 'ring-amber-500/20', 'shadow-amber-500/10');
            }, 6000);
          }
        }, 300);
      }
    };
    window.addEventListener('open_order_deep_link', handleDeepLink);
    return () => window.removeEventListener('open_order_deep_link', handleDeepLink);
  }, []);

  const getStatusColor = (status: OrderStatus) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-50 text-yellow-700 border-yellow-200';
      case 'processing':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'shipped':
        return 'bg-indigo-50 text-indigo-700 border-indigo-200';
      case 'delivered':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'cancelled':
        return 'bg-rose-50 text-rose-700 border-rose-200';
      default:
        return 'bg-zinc-50 text-zinc-700 border-zinc-200';
    }
  };

  const getStatusLabel = (status: OrderStatus) => {
    switch (status) {
      case 'pending':
        return 'بانتظار التأكيد';
      case 'processing':
        return 'قيد التجهيز';
      case 'shipped':
        return 'تم الشحن مع المندوب';
      case 'delivered':
        return 'تم التوصيل بنجاح ✓';
      case 'cancelled':
        return 'ملغي';
    }
  };

  const getPaymentLabel = (method: string) => {
    switch (method) {
      case 'cod':
        return 'الدفع عند الاستلام';
      case 'kuraimi':
        return 'بنك الكريمي';
      case 'jeeb':
        return 'محفظة جيب';
      case 'bank_transfer':
        return 'تحويل بنكي';
      default:
        return method;
    }
  };

  if (!currentCustomer) {
    return (
      <div id="customer-panel-guest" className="max-w-7xl mx-auto px-4 py-12 text-right space-y-10" dir="rtl">
        {/* Guest Intro Hero */}
        <div className="bg-zinc-950 text-white rounded-3xl p-8 border border-amber-500/10 shadow-lg relative overflow-hidden flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/5 rounded-full blur-3xl"></div>
          <div className="space-y-3 relative z-10 text-right md:max-w-xl">
            <span className="bg-amber-500/10 text-amber-400 text-[10px] font-bold px-3 py-1 rounded-full border border-amber-500/20 uppercase">تتبع مشترياتك وطلباتك</span>
            <h2 className="text-xl md:text-3xl font-black">أهلاً بك يا زائرنا الكريم! ✨</h2>
            <p className="text-zinc-400 text-xs leading-relaxed">
              تصفحك كزائر يتيح لك رؤية المنتجات وإضافتها للسلة، ولكن لتتبع مشترياتك السابقة، معرفة حالة الشحن مع المناديب، وإدارة فواتير الدفع، يجب عليك تسجيل الدخول بحسابك عبر رقم الهاتف أو البريد الإلكتروني.
            </p>
          </div>
          <button
            onClick={onTriggerLogin}
            className="relative z-10 bg-amber-500 hover:bg-amber-600 text-zinc-950 font-black px-8 py-3.5 rounded-2xl text-xs shadow-xl cursor-pointer hover:scale-[1.02] transition-all"
          >
            تسجيل الدخول / إنشاء حساب سريع
          </button>
        </div>

        {/* Demo instructions */}
        <div className="bg-white rounded-2xl border border-zinc-200 p-6 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-right">
            <h4 className="font-bold text-zinc-800 text-sm">💡 هل تريد تجربة حساب زبون مسجل مسبقاً؟</h4>
            <p className="text-zinc-500 text-xs mt-1">انقر على زر تسجيل الدخول واستخدم أحد أرقام الهواتف التجريبية الموفرة لمعاينة سجل طلبات حقيقي على الفور!</p>
          </div>
          <button
            onClick={onTriggerLogin}
            className="text-amber-600 hover:text-amber-700 font-bold text-xs underline flex items-center gap-1 cursor-pointer"
          >
            <span>أظهر أرقام التجربة وافتح نافذة الدخول</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div id="customer-panel" className="max-w-7xl mx-auto px-4 py-8 space-y-10">
      {/* Overview stats banner */}
      <div className="bg-zinc-950 text-white rounded-3xl p-6 md:p-8 border border-amber-500/10 shadow-lg flex flex-col md:flex-row justify-between items-center gap-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/5 rounded-full blur-3xl"></div>
        <div className="space-y-2 relative z-10 text-center md:text-right">
          <div className="flex items-center gap-2.5 justify-center md:justify-start">
            <h2 className="text-xl md:text-2xl font-black">أهلاً بك، {currentCustomer.name} 👋</h2>
            <span className="text-[10px] bg-amber-500/20 text-amber-400 font-bold px-2 py-0.5 rounded border border-amber-500/30">حساب مشتري موثق</span>
          </div>
          <div className="text-zinc-400 text-xs space-y-1">
            <p>سجل الدخول عبر: <span className="font-mono text-zinc-300 font-bold">{currentCustomer.phone || currentCustomer.email}</span></p>
            <p>تاريخ التسجيل: <span className="font-mono text-zinc-300">{currentCustomer.joinedDate || '2026-06-26'}</span></p>
          </div>
          <button
            onClick={onLogout}
            className="mt-3 text-[10.5px] bg-red-500/10 hover:bg-red-500 hover:text-white text-red-400 font-bold px-3 py-1.5 rounded-xl transition-all cursor-pointer border border-red-500/20"
          >
            تسجيل الخروج من الحساب
          </button>
        </div>

        <div className="flex gap-4 relative z-10">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 text-center min-w-[100px]">
            <span className="text-2xl font-black font-mono text-amber-400">{myOrders.length}</span>
            <span className="text-[10px] text-zinc-400 block mt-1">طلباتي السابقة</span>
          </div>

          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 text-center min-w-[100px]">
            <span className="text-2xl font-black font-mono text-amber-400">{wishlist.length}</span>
            <span className="text-[10px] text-zinc-400 block mt-1">المفضلة</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Side: Order Trackers */}
        <div className="lg:col-span-2 space-y-6">
          <h3 className="font-extrabold text-md text-zinc-900 flex items-center gap-2">
            <Truck className="w-5 h-5 text-amber-500" />
            <span>تتبع الطلبيات وحالة الشحن ({myOrders.length})</span>
          </h3>

          {myOrders.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-3xl border border-dashed border-zinc-200">
              <ShoppingBag className="w-10 h-10 text-zinc-300 mx-auto mb-3" />
              <p className="text-zinc-500 text-xs">لم تقم بإجراء أي عمليات شراء حتى الآن.</p>
            </div>
          ) : (
            <div className="space-y-5">
              {myOrders.map((order) => (
                <div
                  key={order.id}
                  id={`customer-order-${order.id}`}
                  className="bg-white rounded-2xl border border-zinc-150 p-5 shadow-xs space-y-4 transition-all duration-500"
                >
                  {/* Order Top Bar */}
                  <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 border-b border-zinc-100 pb-3">
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-zinc-400">رقم الطلب:</span>
                      <span className="font-bold text-zinc-900 font-mono text-xs">{order.id}</span>
                      <span className="text-zinc-300">•</span>
                      <span className="text-[10px] text-zinc-400">
                        {new Date(order.createdAt).toLocaleDateString('ar-YE', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 self-start sm:self-auto">
                      <span className="text-[11px] text-zinc-500 font-medium">حالة الطلب:</span>
                      <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full border ${getStatusColor(order.status)}`}>
                        {getStatusLabel(order.status)}
                      </span>
                    </div>
                  </div>

                  {/* Items list inside order */}
                  <div className="space-y-3">
                    {order.items.map((item, idx) => (
                      <div key={idx} className="flex gap-3 items-center">
                        <img
                          src={item.image}
                          alt={item.productTitle}
                          referrerPolicy="no-referrer"
                          className="w-10 h-10 object-cover rounded-lg border border-zinc-150"
                        />
                        <div className="min-w-0 flex-grow">
                          <h5 className="text-xs font-bold text-zinc-800 truncate">{item.productTitle}</h5>
                          <div className="flex flex-col sm:flex-row sm:items-center gap-x-3 gap-y-0.5">
                            <span className="text-[10px] text-zinc-400 font-mono">
                              {item.quantity} قطعة × {(item.price ?? 0).toLocaleString()} ر.ي
                            </span>
                            {(() => {
                              const vName = 'متجر مها للأناقة';
                              const vLogo = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150';
                              return (
                                <span className="inline-flex items-center gap-1 text-[9.5px] text-amber-700 bg-amber-500/5 px-1.5 py-0.2 rounded font-bold">
                                  <img
                                    src={vLogo}
                                    alt=""
                                    className="w-3 h-3 rounded-full object-cover"
                                    referrerPolicy="no-referrer"
                                  />
                                  <span>{vName}</span>
                                </span>
                              );
                            })()}
                          </div>
                        </div>
                        <button
                          onClick={() => onOpenChat(item.vendorId, item.productTitle, item.productId)}
                          className="text-[10px] text-amber-600 hover:bg-amber-50 px-2 py-1 rounded border border-amber-200 flex items-center gap-1 cursor-pointer"
                        >
                          <MessageSquare className="w-3 h-3" />
                          <span>سؤال الدعم</span>
                        </button>
                      </div>
                    ))}
                  </div>

                  {/* Tracker progress bar step visual */}
                  {order.status !== 'cancelled' && (
                    <div className="bg-zinc-50 p-4 rounded-xl border border-zinc-100/60 mt-2">
                      <div className="grid grid-cols-4 text-center text-[10px] text-zinc-400 font-medium relative">
                        {/* Connecting Line */}
                        <div className="absolute top-2.5 left-[12.5%] right-[12.5%] h-0.5 bg-zinc-200 -z-0"></div>
                        {/* Active line filler */}
                        <div
                          className="absolute top-2.5 right-[12.5%] h-0.5 bg-amber-500 -z-0 transition-all duration-500"
                          style={{
                            width:
                              order.status === 'pending'
                                ? '0%'
                                : order.status === 'processing'
                                ? '33.33%'
                                : order.status === 'shipped'
                                ? '66.66%'
                                : '75%'
                          }}
                        ></div>

                        {/* Step 1: Pending */}
                        <div className="relative z-10 flex flex-col items-center">
                          <div className={`w-5.5 h-5.5 rounded-full flex items-center justify-center text-[9px] font-bold ${
                            ['pending', 'processing', 'shipped', 'delivered'].includes(order.status)
                              ? 'bg-amber-500 text-zinc-950 font-bold'
                              : 'bg-zinc-200 text-zinc-600'
                          }`}>1</div>
                          <span className={`mt-1.5 ${['pending', 'processing', 'shipped', 'delivered'].includes(order.status) ? 'text-amber-600 font-bold' : ''}`}>التأكيد</span>
                        </div>

                        {/* Step 2: Processing */}
                        <div className="relative z-10 flex flex-col items-center">
                          <div className={`w-5.5 h-5.5 rounded-full flex items-center justify-center text-[9px] font-bold ${
                            ['processing', 'shipped', 'delivered'].includes(order.status)
                              ? 'bg-amber-500 text-zinc-950 font-bold'
                              : 'bg-zinc-200 text-zinc-600'
                          }`}>2</div>
                          <span className={`mt-1.5 ${['processing', 'shipped', 'delivered'].includes(order.status) ? 'text-amber-600 font-bold' : ''}`}>التجهيز</span>
                        </div>

                        {/* Step 3: Shipped */}
                        <div className="relative z-10 flex flex-col items-center">
                          <div className={`w-5.5 h-5.5 rounded-full flex items-center justify-center text-[9px] font-bold ${
                            ['shipped', 'delivered'].includes(order.status)
                              ? 'bg-amber-500 text-zinc-950 font-bold'
                              : 'bg-zinc-200 text-zinc-600'
                          }`}>3</div>
                          <span className={`mt-1.5 ${['shipped', 'delivered'].includes(order.status) ? 'text-amber-600 font-bold' : ''}`}>الشحن</span>
                        </div>

                        {/* Step 4: Delivered */}
                        <div className="relative z-10 flex flex-col items-center">
                          <div className={`w-5.5 h-5.5 rounded-full flex items-center justify-center text-[9px] font-bold ${
                            order.status === 'delivered'
                              ? 'bg-amber-500 text-zinc-950 font-bold'
                              : 'bg-zinc-200 text-zinc-600'
                          }`}>4</div>
                          <span className={`mt-1.5 ${order.status === 'delivered' ? 'text-amber-600 font-bold' : ''}`}>التسليم</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Billing specifics and payment method */}
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pt-3 border-t border-zinc-100 text-xs gap-2">
                    <div className="text-zinc-500 space-y-1">
                      <div className="flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-zinc-400" />
                        <span>عنوان الشحن: <span className="text-zinc-800 font-medium">{order.customerAddress}</span></span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Phone className="w-3.5 h-3.5 text-zinc-400" />
                        <span>الهاتف: <span className="text-zinc-800 font-mono">{order.customerPhone}</span></span>
                      </div>
                      <div>
                        <span>طريقة الدفع: <span className="font-bold text-zinc-800">{getPaymentLabel(order.paymentMethod)}</span></span>
                        {order.paymentDetails && <span className="text-zinc-400 font-mono text-[10px] block mt-0.5">{order.paymentDetails}</span>}
                      </div>
                    </div>

                    <div className="text-left font-mono self-end sm:self-auto">
                      <span className="text-[10px] text-zinc-400 block">إجمالي القيمة المدفوعة</span>
                      <span className="font-black text-sm text-amber-600">{(order.finalPrice ?? 0).toLocaleString()} ر.ي</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right Side: Wishlist */}
        <div className="space-y-6">
          <h3 className="font-extrabold text-md text-zinc-900 flex items-center gap-2">
            <Heart className="w-5 h-5 text-red-500 fill-red-500/10" />
            <span>قائمة مفضلاتي ({wishlistedProducts.length})</span>
          </h3>

          {wishlistedProducts.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-3xl border border-zinc-150 p-6">
              <Heart className="w-10 h-10 text-zinc-300 mx-auto mb-3" />
              <p className="text-zinc-500 text-xs">لا توجد سلع مضافة في المفضلة حالياً.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {wishlistedProducts.map((p) => (
                <div
                  key={p.id}
                  className="bg-white p-3 rounded-2xl border border-zinc-150 flex gap-3 shadow-xs items-center relative group"
                >
                  <img
                    src={p.images?.[0] || 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=600'}
                    alt={p.title}
                    referrerPolicy="no-referrer"
                    className="w-16 h-16 object-cover rounded-xl border border-zinc-150 cursor-pointer flex-shrink-0"
                    onClick={() => onSelectProduct(p)}
                  />

                  <div className="min-w-0 flex-grow">
                    <h4
                      className="font-bold text-zinc-800 text-xs truncate cursor-pointer hover:text-amber-600"
                      onClick={() => onSelectProduct(p)}
                    >
                      {p.title}
                    </h4>
                    <span className="text-[10px] text-zinc-400 block mb-1">متجر: متجر مها</span>
                    <div className="font-extrabold text-xs font-mono text-zinc-950">
                      {(p.price ?? 0).toLocaleString()} ر.ي
                    </div>
                  </div>

                  <div className="flex flex-col gap-1.5 flex-shrink-0">
                    <button
                      onClick={() => onAddToCart(p)}
                      disabled={p.stock <= 0}
                      className="bg-zinc-900 hover:bg-amber-500 hover:text-zinc-950 text-white p-1.5 rounded-lg transition-all text-[10px] font-bold cursor-pointer disabled:bg-zinc-100 disabled:text-zinc-400"
                    >
                      شراء
                    </button>
                    <button
                      onClick={() => onToggleWishlist(p.id)}
                      className="text-[10px] text-red-500 hover:underline cursor-pointer font-bold"
                    >
                      إزالة
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
