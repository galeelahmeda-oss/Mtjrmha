import { 
  collection, 
  doc, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot, 
  query, 
  where, 
  orderBy, 
  writeBatch,
  getDocs
} from 'firebase/firestore';
import { db } from './firebase';

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  type: 'order' | 'offer' | 'system' | 'chat';
  createdAt: string;
  isRead: boolean; // For customers
  recipientId?: string; // specific customer uid, or 'admin_all' for admin/employees
  recipientRole?: 'admin' | 'employee' | 'customer';
  orderId?: string;
  customerName?: string;
  orderAmount?: number;
  readBy?: string[]; // Array of user UIDs of admins/employees who read it
}

/**
 * Ask the browser/phone for permission to show desktop/push notifications
 */
export async function requestNotificationPermission(): Promise<boolean> {
  if (!('Notification' in window)) {
    console.warn('This browser does not support desktop notifications');
    return false;
  }
  
  if (Notification.permission === 'granted') {
    return true;
  }
  
  if (Notification.permission !== 'denied') {
    const permission = await Notification.requestPermission();
    return permission === 'granted';
  }
  
  return false;
}

/**
 * Show a native browser desktop/mobile push notification
 */
export function showBrowserNotification(title: string, body: string, onClick?: () => void) {
  if (!('Notification' in window)) return;
  
  if (Notification.permission === 'granted') {
    try {
      const options = {
        body,
        icon: '/favicon.ico', // fallback to favicon
        badge: '/favicon.ico',
        dir: 'rtl' as NotificationDirection,
        tag: 'maha_store_notif'
      };
      const notification = new Notification(title, options);
      if (onClick) {
        notification.onclick = (e) => {
          e.preventDefault();
          window.focus();
          onClick();
          notification.close();
        };
      }
    } catch (e) {
      console.error('Error showing native notification:', e);
    }
  }
}

/**
 * Subscribe to real-time notifications in Firestore based on the user's role and UID.
 * Automatically triggers browser push notifications for newly added items in real-time.
 */
export function subscribeToNotifications(
  userId: string | undefined,
  role: 'admin' | 'employee' | 'customer',
  onUpdate: (notifications: AppNotification[]) => void
): () => void {
  const notificationsRef = collection(db, 'notifications');
  
  let q;
  if (role === 'admin' || role === 'employee') {
    // Admins and employees receive notifications designated for admins/employees
    q = query(
      notificationsRef,
      where('recipientId', '==', 'admin_all'),
      orderBy('createdAt', 'desc')
    );
  } else if (userId) {
    // Customers receive their specific notifications
    q = query(
      notificationsRef,
      where('recipientId', '==', userId),
      orderBy('createdAt', 'desc')
    );
  } else {
    // If guest, listen to nothing
    onUpdate([]);
    return () => {};
  }

  let isFirstLoad = true;

  const unsubscribe = onSnapshot(q, (snapshot) => {
    const list: AppNotification[] = [];
    
    snapshot.forEach((docSnap) => {
      const data = docSnap.data();
      list.push({
        id: docSnap.id,
        title: data.title || '',
        message: data.message || '',
        type: data.type || 'system',
        createdAt: data.createdAt || new Date().toISOString(),
        isRead: typeof data.isRead === 'boolean' ? data.isRead : false,
        recipientId: data.recipientId,
        recipientRole: data.recipientRole,
        orderId: data.orderId,
        customerName: data.customerName,
        orderAmount: data.orderAmount,
        readBy: Array.isArray(data.readBy) ? data.readBy : []
      });
    });

    // For new real-time additions (after initial load), trigger a system audio chime and browser push
    if (!isFirstLoad) {
      snapshot.docChanges().forEach((change) => {
        if (change.type === 'added') {
          const newNotif = change.doc.data();
          // Verify if this notification is relevant
          const isForMe = role === 'admin' || role === 'employee' || newNotif.recipientId === userId;
          
          if (isForMe) {
            // Play a gentle notification sound if possible
            try {
              const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2357/2357-84.wav');
              audio.volume = 0.5;
              audio.play().catch(() => {});
            } catch (soundErr) {
              // Ignore audio play block
            }

            // Show native notification
            showBrowserNotification(
              newNotif.title || 'تنبيه جديد 🔔',
              newNotif.message || '',
              () => {
                // Clicking the push notification will be handled via deep link in UI
                if (newNotif.orderId) {
                  const event = new CustomEvent('open_order_deep_link', { detail: { orderId: newNotif.orderId } });
                  window.dispatchEvent(event);
                }
              }
            );
          }
        }
      });
    }

    isFirstLoad = false;
    onUpdate(list);
  }, (err) => {
    console.error('Error fetching real-time notifications:', err);
  });

  return unsubscribe;
}

/**
 * Send a notification of a new order to all admins and employees.
 * Idempotent: doc ID is prefixed with order ID to prevent duplicates.
 */
export async function notifyNewOrder(orderId: string, customerName: string, finalPrice: number) {
  const docId = `new_order_${orderId}`;
  const notificationRef = doc(db, 'notifications', docId);

  const notifPayload: AppNotification = {
    id: docId,
    title: 'طلب جديد في متجر مها 🛍️',
    message: `قام العميل "${customerName}" بإنشاء طلب جديد رقم #${orderId} بقيمة ${finalPrice.toLocaleString()} ر.ي.`,
    type: 'order',
    createdAt: new Date().toISOString(),
    isRead: false,
    recipientId: 'admin_all',
    orderId,
    customerName,
    orderAmount: finalPrice,
    readBy: []
  };

  try {
    await setDoc(notificationRef, notifPayload);
  } catch (err) {
    console.error('Failed to write new order notification to Firestore:', err);
  }
}

/**
 * Send a notification of order status update to a specific customer.
 * Idempotent: doc ID is partitioned by status and order ID to prevent duplicates.
 */
export async function notifyOrderStatusUpdate(
  orderId: string,
  customerUid: string,
  customerName: string,
  newStatus: string,
  cancelReason?: string
) {
  // Translate status to Arabic for the customer
  let arabicStatus = '';
  let icon = '📦';
  switch (newStatus) {
    case 'pending':
      arabicStatus = 'قيد المراجعة والتدقيق';
      icon = '🔍';
      break;
    case 'processing':
      arabicStatus = 'قيد التجهيز والتحضير';
      icon = '⚙️';
      break;
    case 'shipping':
      arabicStatus = 'قيد الشحن والتوصيل مع المندوب';
      icon = '🚚';
      break;
    case 'delivered':
      arabicStatus = 'تم التسليم بنجاح! تتهنوا فيه يارب';
      icon = '🎉';
      break;
    case 'cancelled':
      arabicStatus = 'ملغي';
      icon = '❌';
      break;
    default:
      arabicStatus = newStatus;
  }

  const docId = `status_change_${orderId}_${newStatus}`;
  const notificationRef = doc(db, 'notifications', docId);

  let messageText = `تحديث لطلبك #${orderId}: حالة الطلب أصبحت الآن (${arabicStatus}).`;
  if (newStatus === 'cancelled' && cancelReason) {
    messageText += ` سبب الإلغاء: ${cancelReason}`;
  }

  const notifPayload: AppNotification = {
    id: docId,
    title: `${icon} تحديث حالة طلبك - متجر مها`,
    message: messageText,
    type: 'order',
    createdAt: new Date().toISOString(),
    isRead: false,
    recipientId: customerUid,
    orderId,
    customerName,
    readBy: []
  };

  try {
    await setDoc(notificationRef, notifPayload);
  } catch (err) {
    console.error('Failed to write order status notification to Firestore:', err);
  }
}

/**
 * Mark a single notification as read by a user.
 * If user is admin/employee, appends their UID to 'readBy'.
 * If user is customer, sets 'isRead' to true.
 */
export async function markNotificationAsRead(notificationId: string, userId: string, role: 'admin' | 'employee' | 'customer') {
  const notificationRef = doc(db, 'notifications', notificationId);
  try {
    if (role === 'admin' || role === 'employee') {
      // Append to readBy list
      await setDoc(notificationRef, {
        readBy: [userId] // using merge to avoid wiping other fields or updateDoc
      }, { merge: true });
      
      // Also we can fetch or append it to existing readBy array safely:
      // In firestore, we can use arrayUnion:
      const { arrayUnion } = await import('firebase/firestore');
      await updateDoc(notificationRef, {
        readBy: arrayUnion(userId)
      });
    } else {
      await updateDoc(notificationRef, {
        isRead: true
      });
    }
  } catch (err) {
    console.error('Failed to mark notification as read:', err);
  }
}

/**
 * Mark all visible notifications as read for the user
 */
export async function markAllNotificationsAsRead(notifications: AppNotification[], userId: string, role: 'admin' | 'employee' | 'customer') {
  const batch = writeBatch(db);
  let count = 0;
  
  for (const notif of notifications) {
    const isUnread = role === 'admin' || role === 'employee' 
      ? !notif.readBy?.includes(userId)
      : !notif.isRead;
      
    if (isUnread) {
      const ref = doc(db, 'notifications', notif.id);
      if (role === 'admin' || role === 'employee') {
        const readByArray = notif.readBy || [];
        if (!readByArray.includes(userId)) {
          batch.update(ref, {
            readBy: [...readByArray, userId]
          });
          count++;
        }
      } else {
        batch.update(ref, {
          isRead: true
        });
        count++;
      }
    }
  }
  
  if (count > 0) {
    await batch.commit();
  }
}

/**
 * Delete a notification from Firestore
 */
export async function deleteNotification(notificationId: string) {
  const notificationRef = doc(db, 'notifications', notificationId);
  try {
    await deleteDoc(notificationRef);
  } catch (err) {
    console.error('Failed to delete notification:', err);
  }
}
