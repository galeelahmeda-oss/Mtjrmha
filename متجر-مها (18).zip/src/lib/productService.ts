import { collection, getDocs, doc, setDoc, deleteDoc } from 'firebase/firestore';
import { db } from './firebase';
import { Product } from '../types';

const COLLECTION_NAME = 'products';

// Fetch all products from Firestore
export async function fetchProducts(): Promise<Product[]> {
  console.log('[Firestore] fetchProducts initiated.');
  try {
    const collRef = collection(db, COLLECTION_NAME);
    console.log(`[Firestore] getDocs from collection "${COLLECTION_NAME}"...`);
    const querySnapshot = await getDocs(collRef);
    
    // Check if the database has already been cleared of initial mock products
    let isAlreadyCleared = false;
    querySnapshot.forEach((docSnap) => {
      if (docSnap.id === '_is_cleared_v1') {
        isAlreadyCleared = true;
      }
    });

    if (!isAlreadyCleared) {
      console.log('[Firestore] One-time database clearing initiated: deleting all old mock products...');
      for (const docSnap of querySnapshot.docs) {
        console.log(`[Firestore] Deleting document: ${docSnap.id}`);
        await deleteDoc(doc(db, COLLECTION_NAME, docSnap.id));
      }
      // Create the _is_cleared_v1 marker document
      await setDoc(doc(db, COLLECTION_NAME, '_is_cleared_v1'), { cleared: true });
      console.log('[Firestore] One-time database clearing completed.');
      
      // Clear localStorage to force synchronized state on the client side
      localStorage.removeItem('maha_store_state_2026');
      return [];
    }

    const products: Product[] = [];
    querySnapshot.forEach((docSnap) => {
      if (docSnap.id !== '_is_cleared_v1' && docSnap.id !== '_is_seeded') {
        products.push(docSnap.data() as Product);
      }
    });

    console.log(`[Firestore] Successfully fetched ${products.length} products from Firestore.`);

    // Sort products by createdAt descending
    const sorted = products.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    console.log(`[Firestore] fetchProducts returning ${sorted.length} products (sorted).`);
    return sorted;
  } catch (error) {
    console.error('[Firestore] Error in fetchProducts from Firestore:', error);
    throw error;
  }
}

// Add a new product to Firestore
export async function addProduct(product: Product): Promise<void> {
  console.log(`[Firestore] addProduct initiated for ID: "${product.id}", Title: "${product.title}"`);
  try {
    const productRef = doc(db, COLLECTION_NAME, product.id);
    console.log(`[Firestore] setDoc for product: ${product.id}`);
    await setDoc(productRef, product);
    console.log(`[Firestore] Product "${product.id}" successfully added/written to Firestore.`);
  } catch (error) {
    console.error(`[Firestore] Error adding product "${product.id}" to Firestore:`, error);
    throw error;
  }
}

// Update an existing product in Firestore
export async function updateProduct(product: Product): Promise<void> {
  console.log(`[Firestore] updateProduct initiated for ID: "${product.id}", Title: "${product.title}"`);
  try {
    const productRef = doc(db, COLLECTION_NAME, product.id);
    console.log(`[Firestore] setDoc (update) for product: ${product.id}`);
    await setDoc(productRef, product);
    console.log(`[Firestore] Product "${product.id}" successfully updated in Firestore.`);
  } catch (error) {
    console.error(`[Firestore] Error updating product "${product.id}" in Firestore:`, error);
    throw error;
  }
}

// Delete a product from Firestore
export async function deleteProduct(productId: string): Promise<void> {
  console.log(`[Firestore] deleteProduct initiated for ID: "${productId}"`);
  try {
    const productRef = doc(db, COLLECTION_NAME, productId);
    console.log(`[Firestore] deleteDoc for product: ${productId}`);
    await deleteDoc(productRef);
    console.log(`[Firestore] Product "${productId}" successfully deleted from Firestore.`);
  } catch (error) {
    console.error(`[Firestore] Error deleting product "${productId}" from Firestore:`, error);
    throw error;
  }
}
