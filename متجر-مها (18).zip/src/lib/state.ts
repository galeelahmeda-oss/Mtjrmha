import { Product, Order, User, Coupon, Message, Review, Notification, Employee, ShippingMethod, PaymentGateway, AbandonedCart, StoreSettings } from '../types';
import { INITIAL_PRODUCTS, INITIAL_ORDERS, INITIAL_VENDORS, INITIAL_COUPONS, INITIAL_MESSAGES, INITIAL_REVIEWS } from '../data/mockData';

export interface MarketplaceState {
  products: Product[];
  orders: Order[];
  vendors: User[];
  coupons: Coupon[];
  messages: Message[];
  reviews: Review[];
  notifications: Notification[];
  employees: Employee[];
  shippingMethods: ShippingMethod[];
  paymentGateways: PaymentGateway[];
  abandonedCarts: AbandonedCart[];
  storeSettings: StoreSettings;
}

const STORAGE_KEY = 'maha_store_state_2026';

export const DEFAULT_STORE_SETTINGS: StoreSettings = {
  name: 'متجر مها للأناقة والموضة',
  logo: '👑', // We can also allow the user to load a base64 logo or custom text emoji
  description: 'الوجهة اليمنية الأولى والوحيدة لشراء أرقى الملابس والفساتين الفاخرة، العطور الشرقية الساحرة، والإكسسوارات المصممة يدوياً.',
  phone: '+967 777 000 111',
  whatsapp: '+967 777 000 111',
  email: 'info@mahastore.ye',
  address: 'الجمهورية اليمنية - صنعاء - شارع حدة التجاري',
  socialLinks: {
    facebook: 'https://facebook.com/mahastore',
    instagram: 'https://instagram.com/mahastore',
    twitter: 'https://twitter.com/mahastore',
    whatsapp: 'https://wa.me/967777000111'
  },
  currencyCode: 'YER',
  currencySymbol: 'ر.ي',
  shippingCostDefault: 2000,
  customCss: '',
  themeColor: '#f59e0b',
  androidAppLink: '',
  iphoneAppLink: '',
  gscVerificationCode: '',
  ga4MeasurementId: '',
  gtmId: '',
  privacyPolicy: 'مرحباً بكم في متجر مها للأناقة والموضة. نحن نقدر ثقتكم ونهتم بخصوصية بياناتكم. نقوم بجمع معلومات الاتصال وعناوين الشحن فقط لإتمام الطلبيات وتحسين تجربة التسوق الخاصة بكم. نحن نلتزم بعدم بيع أو مشاركة أي من بياناتكم الشخصية مع أي طرف ثالث تحت أي ظرف من الظروف.',
  termsConditions: 'عند تصفحكم أو شرائكم من متجر مها، فإنكم توافقون على الشروط والأحكام التالية: جميع الأسعار معلنة بالريال اليمني، ويتم الدفع نقداً عند الاستلام أو عبر التحويل البنكي المعتمد. يحق للعميل استبدال أو استرجاع السلع التالفة أو غير المطابقة للمواصفات خلال فترة أقصاها 3 أيام من تاريخ الاستلام بشرط بقائها في غلافها الأصلي.'
};

export const sanitizeStoreSettings = (settings: any): StoreSettings => {
  if (!settings) return DEFAULT_STORE_SETTINGS;
  
  const clean = (val: any): any => {
    if (typeof val === 'string') {
      return val.replace(/AilgCliAliliAilgCliAliliAilgCliAliliID\/\/Z/gi, '')
                .replace(/AilgCliAlili/gi, '')
                .replace(/ID\/\/Z/gi, '')
                .trim();
    }
    if (val && typeof val === 'object') {
      const copy: any = Array.isArray(val) ? [] : {};
      for (const key of Object.keys(val)) {
        copy[key] = clean(val[key]);
      }
      return copy;
    }
    return val;
  };

  const sanitized = clean(settings);
  return {
    ...DEFAULT_STORE_SETTINGS,
    ...sanitized,
    socialLinks: {
      ...DEFAULT_STORE_SETTINGS.socialLinks,
      ...(sanitized.socialLinks || {})
    }
  };
};

export const deepSanitize = (val: any): any => {
  if (typeof val === 'string') {
    return val.replace(/AilgCliAliliAilgCliAliliAilgCliAliliID\/\/Z/gi, '')
              .replace(/AilgCliAlili/gi, '')
              .replace(/ID\/\/Z/gi, '')
              .trim();
  }
  if (val && typeof val === 'object') {
    const copy: any = Array.isArray(val) ? [] : {};
    for (const key of Object.keys(val)) {
      copy[key] = deepSanitize(val[key]);
    }
    return copy;
  }
  return val;
};


const DEFAULT_EMPLOYEES: Employee[] = [
  { id: 'emp_1', name: 'أحمد اليماني', email: 'ahmed@salla.ye', permission: 'products', joinedDate: '2026-02-01' },
  { id: 'emp_2', name: 'سارة حسن', email: 'sara@salla.ye', permission: 'customers', joinedDate: '2026-03-10' },
  { id: 'emp_3', name: 'خالد مسعود', email: 'khaled@salla.ye', permission: 'orders', joinedDate: '2026-04-15' },
  { id: 'emp_4', name: 'نورا الصنعاني', email: 'noora@salla.ye', permission: 'marketing', joinedDate: '2026-05-20' },
];

const DEFAULT_SHIPPING: ShippingMethod[] = [
  { id: 'ship_1', name: 'البرق السريع للتوصيل', cost: 2000, regions: ['صنعاء', 'عدن'], isActive: true, deliveryTime: '24-48 ساعة' },
  { id: 'ship_2', name: 'المندوب الشخصي لمتجر مها', cost: 1000, regions: ['صنعاء'], isActive: true, deliveryTime: 'خلال نفس اليوم' },
  { id: 'ship_3', name: 'يمن إكسبريس لشحن المحافظات', cost: 4000, regions: ['تعز', 'إب', 'حضرموت', 'الحديدة'], isActive: true, deliveryTime: '2-4 أيام' },
];

const DEFAULT_PAYMENTS: PaymentGateway[] = [
  { id: 'pay_cod', name: 'الدفع عند الاستلام', isActive: true, logo: '💵', instructions: 'تسليم المبلغ للمندوب فور معاينة واستلام السلع' },
  { id: 'pay_kuraimi', name: 'بنك الكريمي الإسلامي', isActive: true, logo: '🏦', accountNumber: '12345678', instructions: 'يرجى إرسال الحوالة بالريال اليمني وتدوين الرقم المرجعي' },
  { id: 'pay_jeeb', name: 'محفظة جيب الإلكترونية', isActive: true, logo: '📱', accountNumber: '777000111', instructions: 'الدفع المباشر من التطبيق فوراً' },
  { id: 'pay_transfer', name: 'تحويل بنكي مباشر', isActive: false, logo: '💳', accountNumber: '99988822', instructions: 'حساب بنك التضامن أو بنك اليمن والكويت' },
];

const DEFAULT_ABANDONED_CARTS: AbandonedCart[] = [
  {
    id: 'cart_ab_1',
    customerName: 'رانيا الوصابي',
    customerPhone: '773123123',
    items: [
      { productTitle: 'فستان مخملي ملكي مطرز بالخيوط الذهبية', price: 35000, quantity: 1 }
    ],
    updatedAt: new Date(Date.now() - 7200000).toISOString() // 2 hours ago
  },
  {
    id: 'cart_ab_2',
    customerName: 'ماجد الريمي',
    customerPhone: '735999888',
    items: [
      { productTitle: 'عطر العود الملكي مع دهن الورد الطائفي وعنبر صخري', price: 45000, quantity: 1 },
      { productTitle: 'بخور عدني ملكي ممتاز بالمسك والظفور المعتق', price: 15000, quantity: 2 }
    ],
    updatedAt: new Date(Date.now() - 14400000).toISOString() // 4 hours ago
  }
];

export const getInitialState = (): MarketplaceState => {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved) {
    try {
      const parsed = deepSanitize(JSON.parse(saved));
      // Ensure backward compatibility with older saved state (backfill missing properties)
      const finalProducts = parsed.products || [];
      const finalVendors = parsed.vendors || INITIAL_VENDORS;

      return {
        products: finalProducts,
        orders: parsed.orders || INITIAL_ORDERS,
        vendors: finalVendors,
        coupons: parsed.coupons || INITIAL_COUPONS,
        messages: parsed.messages || INITIAL_MESSAGES,
        reviews: parsed.reviews || INITIAL_REVIEWS,
        notifications: parsed.notifications || [],
        employees: parsed.employees || DEFAULT_EMPLOYEES,
        shippingMethods: parsed.shippingMethods || DEFAULT_SHIPPING,
        paymentGateways: parsed.paymentGateways || DEFAULT_PAYMENTS,
        abandonedCarts: parsed.abandonedCarts || DEFAULT_ABANDONED_CARTS,
        storeSettings: sanitizeStoreSettings(parsed.storeSettings)
      };
    } catch (e) {
      console.error('Error parsing saved state', e);
    }
  }

  // Create some default notifications
  const initialNotifications: Notification[] = [
    {
      id: 'not_1',
      title: 'مرحباً بك في متجر مها',
      message: 'نسعد بزيارتك وتجربة منصتنا المتكاملة للتجارة الإلكترونية متعددة البائعين.',
      type: 'system',
      createdAt: new Date().toISOString(),
      isRead: false
    },
    {
      id: 'not_2',
      title: 'عرض يومي جديد! 🔥',
      message: 'خصم 15% على فستان المخمل الملكي المطرز بالخيوط الذهبية لفترة محدودة.',
      type: 'offer',
      createdAt: new Date(Date.now() - 3600000).toISOString(),
      isRead: false
    }
  ];

  return {
    products: [],
    orders: INITIAL_ORDERS,
    vendors: INITIAL_VENDORS,
    coupons: INITIAL_COUPONS,
    messages: INITIAL_MESSAGES,
    reviews: INITIAL_REVIEWS,
    notifications: initialNotifications,
    employees: DEFAULT_EMPLOYEES,
    shippingMethods: DEFAULT_SHIPPING,
    paymentGateways: DEFAULT_PAYMENTS,
    abandonedCarts: DEFAULT_ABANDONED_CARTS,
    storeSettings: DEFAULT_STORE_SETTINGS
  };
};

export const saveState = (state: MarketplaceState) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
};
