import React, { useState } from 'react';
import { X, Trash2, ShoppingBag, ArrowLeft, Tag } from 'lucide-react';
import { CartItem, Coupon } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface CartModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (productId: string, quantity: number, selectedOptions?: { [key: string]: string }, userNote?: string) => void;
  onRemoveItem: (productId: string, selectedOptions?: { [key: string]: string }, userNote?: string) => void;
  onCheckout: () => void;
  appliedCoupon: Coupon | null;
  onApplyCoupon: (code: string) => boolean;
  onRemoveCoupon: () => void;
}

export default function CartModal({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout,
  appliedCoupon,
  onApplyCoupon,
  onRemoveCoupon,
}: CartModalProps) {
  const [couponInput, setCouponInput] = useState('');
  const [couponError, setCouponError] = useState('');
  const [couponSuccess, setCouponSuccess] = useState(false);

  const subtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);

  // Calculate discount
  let discountAmount = 0;
  if (appliedCoupon && subtotal >= (appliedCoupon.minSpend || 0)) {
    if (appliedCoupon.discountType === 'percentage') {
      discountAmount = (subtotal * appliedCoupon.value) / 100;
    } else {
      discountAmount = appliedCoupon.value;
    }
  }

  const finalTotal = Math.max(0, subtotal - discountAmount);

  const handleCouponSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError('');
    setCouponSuccess(false);

    if (!couponInput.trim()) return;

    const success = onApplyCoupon(couponInput.trim().toUpperCase());
    if (success) {
      setCouponSuccess(true);
      setCouponInput('');
      setTimeout(() => setCouponSuccess(false), 3000);
    } else {
      setCouponError('الكوبون غير صحيح، أو لم يصل طلبك للحد الأدنى المسموح.');
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div id="cart-drawer-overlay" className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex justify-end">
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="w-full sm:w-[450px] bg-white h-full flex flex-col shadow-2xl"
          >
            {/* Header */}
            <div className="p-5 border-b border-zinc-100 flex justify-between items-center bg-zinc-950 text-white">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-amber-500" />
                <span className="font-extrabold text-sm">سلة التسوق ({cartItems.length} منتجات)</span>
              </div>
              <button
                id="btn-close-cart"
                onClick={onClose}
                className="p-1 rounded-full hover:bg-zinc-800 text-zinc-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Cart Items List */}
            <div className="flex-grow overflow-y-auto p-5 space-y-4">
              {cartItems.length === 0 ? (
                <div className="text-center py-20">
                  <div className="w-16 h-16 bg-zinc-100 rounded-full flex items-center justify-center text-zinc-400 mx-auto mb-4">
                    <ShoppingBag className="w-8 h-8" />
                  </div>
                  <h4 className="font-bold text-zinc-800 text-sm">سلة التسوق فارغة</h4>
                  <p className="text-zinc-500 text-[11px] mt-1.5 px-6 leading-relaxed">
                    تصفح منتجات متجر مها المميزة وأضف أفضل الملابس، العطور، والإكسسوارات الفاخرة لسلتك الآن!
                  </p>
                  <button
                    onClick={onClose}
                    className="mt-5 bg-zinc-900 hover:bg-amber-500 hover:text-zinc-950 text-white px-5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer"
                  >
                    بدء التسوق
                  </button>
                </div>
              ) : (
                cartItems.map((item) => (
                  <div
                    key={item.product.id}
                    className="flex gap-3 bg-zinc-50 p-3 rounded-2xl border border-zinc-100 relative group"
                  >
                    {/* Image */}
                    <div className="w-20 h-20 rounded-xl overflow-hidden bg-white border border-zinc-100 flex-shrink-0">
                      <img
                        src={item.product.images?.[0] || 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=600'}
                        alt={item.product.title}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    </div>

                    {/* Content */}
                    <div className="flex-grow min-w-0 pr-1">
                      <h4 className="font-bold text-zinc-900 text-xs truncate leading-snug">
                        {item.product.title}
                      </h4>
                      <span className="text-[10px] text-amber-600 block mb-1">
                        متجر: {item.product.vendorName}
                      </span>

                      {/* Selected Options */}
                      {item.selectedOptions && Object.keys(item.selectedOptions).length > 0 && (
                        <div className="flex flex-wrap gap-1 mb-1.5">
                          {Object.entries(item.selectedOptions).map(([key, val]) => (
                            <span key={key} className="text-[10px] bg-zinc-200 text-zinc-700 px-1.5 py-0.5 rounded">
                              {key}: {val}
                            </span>
                          ))}
                        </div>
                      )}

                      {/* User Custom Note */}
                      {item.userNote && (
                        <p className="text-[10px] text-zinc-600 bg-amber-50 border border-amber-100 rounded p-1.5 mb-2 leading-tight text-right">
                          📝 {item.userNote}
                        </p>
                      )}

                      {/* Price */}
                      <div className="text-xs font-black text-zinc-950 font-mono mb-2">
                        {(item.product.price ?? 0).toLocaleString()} ر.ي
                      </div>

                      {/* Quantity Selector */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1 bg-white rounded-lg p-0.5 border border-zinc-200">
                          <button
                            onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1, item.selectedOptions, item.userNote)}
                            disabled={item.quantity <= 1}
                            className="w-6 h-6 rounded text-zinc-600 font-bold hover:bg-zinc-50 flex items-center justify-center cursor-pointer disabled:opacity-50 text-xs"
                          >
                            -
                          </button>
                          <span className="w-8 text-center font-bold font-mono text-xs">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1, item.selectedOptions, item.userNote)}
                            disabled={item.quantity >= item.product.stock}
                            className="w-6 h-6 rounded text-zinc-600 font-bold hover:bg-zinc-50 flex items-center justify-center cursor-pointer disabled:opacity-50 text-xs"
                          >
                            +
                          </button>
                        </div>

                        {/* Delete Button */}
                        <button
                          id={`delete-cart-item-${item.product.id}`}
                          onClick={() => onRemoveItem(item.product.id, item.selectedOptions, item.userNote)}
                          className="text-zinc-400 hover:text-red-500 p-1 rounded transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Bottom calculation space */}
            {cartItems.length > 0 && (
              <div className="bg-zinc-50 border-t border-zinc-150 p-5 space-y-4">
                {/* Coupon Form */}
                <div className="bg-white p-3 rounded-xl border border-zinc-200">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-[11px] font-bold text-zinc-700 flex items-center gap-1">
                      <Tag className="w-3.5 h-3.5 text-amber-500" />
                      <span>هل لديك كود خصم؟</span>
                    </span>
                    {appliedCoupon && (
                      <button
                        onClick={onRemoveCoupon}
                        className="text-[10px] text-red-500 font-bold hover:underline cursor-pointer"
                      >
                        إلغاء الكود
                      </button>
                    )}
                  </div>

                  {appliedCoupon ? (
                    <div className="bg-amber-500/10 border border-amber-500/30 text-amber-800 text-[11px] font-bold py-1.5 px-3 rounded-lg flex justify-between items-center">
                      <span>✓ تم تطبيق الكوبون: {appliedCoupon.code}</span>
                      <span>
                        خصم -
                        {appliedCoupon.discountType === 'percentage'
                          ? `${appliedCoupon.value}%`
                          : `${(appliedCoupon.value ?? 0).toLocaleString()} ر.ي`}
                      </span>
                    </div>
                  ) : (
                    <form onSubmit={handleCouponSubmit} className="flex gap-2">
                      <input
                        type="text"
                        placeholder="أدخل الرمز (مثال: MAHA10)"
                        value={couponInput}
                        onChange={(e) => setCouponInput(e.target.value)}
                        className="flex-grow text-xs px-3 py-1.5 rounded-lg border border-zinc-200 focus:border-amber-500 focus:outline-none uppercase font-mono"
                      />
                      <button
                        type="submit"
                        className="bg-zinc-900 hover:bg-amber-500 hover:text-zinc-950 text-white text-xs font-bold px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
                      >
                        تطبيق
                      </button>
                    </form>
                  )}

                  {couponError && <p className="text-[10px] text-red-500 mt-1">{couponError}</p>}
                  {couponSuccess && (
                    <p className="text-[10px] text-emerald-600 mt-1 font-bold">✓ تم تفعيل كود الخصم!</p>
                  )}
                </div>

                {/* Calculations */}
                <div className="space-y-2.5 text-xs text-zinc-600">
                  <div className="flex justify-between">
                    <span>المجموع الفرعي:</span>
                    <span className="font-mono font-bold">{(subtotal ?? 0).toLocaleString()} ر.ي</span>
                  </div>

                  {(discountAmount ?? 0) > 0 && (
                    <div className="flex justify-between text-red-500 font-bold">
                      <span>قيمة الخصم الكلية:</span>
                      <span className="font-mono">- {(discountAmount ?? 0).toLocaleString()} ر.ي</span>
                    </div>
                  )}

                  <div className="border-t border-zinc-200 my-2"></div>

                  <div className="flex justify-between text-sm text-zinc-950 font-black">
                    <span>المجموع الإجمالي:</span>
                    <span className="text-md text-amber-600 font-mono">
                      {(finalTotal ?? 0).toLocaleString()} ر.ي
                    </span>
                  </div>
                </div>

                {/* Checkout CTA */}
                <button
                  id="btn-trigger-checkout"
                  onClick={onCheckout}
                  className="w-full bg-amber-500 hover:bg-amber-600 text-zinc-950 font-bold py-3.5 rounded-xl transition-all shadow-md shadow-amber-500/10 flex items-center justify-center gap-1.5 cursor-pointer text-sm"
                >
                  <span>متابعة إتمام الطلب</span>
                  <ArrowLeft className="w-4 h-4" />
                </button>
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
