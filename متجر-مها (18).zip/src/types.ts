export type UserRole = 'customer' | 'vendor' | 'admin' | 'employee';

export interface BankAccount {
  id: string;
  bankName: string;
  accountName: string;
  accountNumber: string;
  isActive: boolean;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
  phone?: string;
  shopName?: string;
  shopDescription?: string;
  shopLogo?: string;
  shopAnnouncements?: string[];
  bankAccounts?: BankAccount[];
  joinedDate: string;
  isVerified?: boolean;
  commissionRate?: number; // custom commission rate for vendor
}

export interface Category {
  id: string;
  name: string;
  icon: string; // Lucide icon name
  slug: string;
}

export interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  originalPrice?: number; // for discounts
  images: string[];
  category: string; // category slug
  vendorId: string;
  vendorName: string;
  stock: number;
  salesCount: number;
  rating: number;
  reviewsCount: number;
  isBestSeller?: boolean;
  isDailyOffer?: boolean;
  createdAt: string;
  features?: string[];
  weight?: number;
  youtubeUrl?: string;
  options?: { name: string; values: string[] }[]; // product custom options (e.g. Color, Size)
  notes?: string; // product custom notes
}

export interface Review {
  id: string;
  productId: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  rating: number;
  comment: string;
  createdAt: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedOptions?: { [key: string]: string };
  userNote?: string;
}

export interface Coupon {
  code: string;
  discountType: 'percentage' | 'fixed';
  value: number;
  minSpend?: number;
  isActive: boolean;
}

export type OrderStatus = 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';

export interface Order {
  id: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  items: {
    productId: string;
    productTitle: string;
    price: number;
    quantity: number;
    vendorId: string;
    image: string;
    selectedOptions?: { [key: string]: string };
    userNote?: string;
  }[];
  totalPrice: number;
  discountAmount: number;
  finalPrice: number;
  paymentMethod: 'kuraimi' | 'jeeb' | 'bank_transfer' | 'cod';
  paymentDetails?: string; // transaction ID or receipt details
  status: OrderStatus;
  createdAt: string;
  commissionEarned: number; // calculated commission for admin
}

export interface Message {
  id: string;
  senderId: string;
  senderRole: UserRole;
  receiverId: string;
  content: string;
  timestamp: string;
  productId?: string; // Optional: reference to product
  productTitle?: string;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'order' | 'offer' | 'system' | 'chat';
  createdAt: string;
  isRead: boolean;
}

export interface Employee {
  id: string;
  name: string;
  email: string;
  permission: 'products' | 'orders' | 'customers' | 'marketing';
  joinedDate: string;
}

export interface ShippingMethod {
  id: string;
  name: string;
  cost: number;
  regions: string[];
  isActive: boolean;
  deliveryTime: string;
}

export interface PaymentGateway {
  id: string;
  name: string;
  isActive: boolean;
  accountNumber?: string;
  instructions?: string;
  logo?: string; // emoji or image data URL
}

export interface AbandonedCart {
  id: string;
  customerName: string;
  customerPhone: string;
  items: {
    productTitle: string;
    price: number;
    quantity: number;
  }[];
  updatedAt: string;
}

export interface Banner {
  id: string;
  title: string;
  subtitle: string;
  imageUrl: string;
  isActive: boolean;
  couponCode?: string;
  categorySlug?: string; // category association ('all' or empty means general/home)
  animationType?: 'fade' | 'slide' | 'zoom' | 'bounce' | 'none';
}

export interface Inquiry {
  id: string;
  name: string;
  contact: string;
  message: string;
  createdAt: string;
  isRead: boolean;
}

export interface StoreSettings {
  name: string;
  logo: string;
  description: string;
  phone: string;
  whatsapp: string;
  email: string;
  address: string;
  socialLinks: {
    facebook: string;
    instagram: string;
    twitter: string;
    whatsapp: string;
  };
  currencyCode: string;
  currencySymbol: string;
  shippingCostDefault: number;
  customCss?: string; // Custom CSS styling code
  themeColor?: string; // Primary brand/logo color (e.g. Hex)
  androidAppLink?: string;
  iphoneAppLink?: string;
  gscVerificationCode?: string;
  ga4MeasurementId?: string;
  gtmId?: string;
  privacyPolicy?: string;
  termsConditions?: string;
}



