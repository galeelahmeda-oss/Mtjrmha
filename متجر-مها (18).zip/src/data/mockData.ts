import { Product, Category, User, Coupon, Order, Review, Message } from '../types';

export const INITIAL_CATEGORIES: Category[] = [
  { id: '1', name: 'ملابس وأزياء', icon: 'Shirt', slug: 'clothing' },
  { id: '2', name: 'إكسسوارات ومجوهرات', icon: 'Sparkles', slug: 'accessories' },
  { id: '3', name: 'عطور وبخور', icon: 'Droplet', slug: 'perfumes' },
  { id: '4', name: 'مستحضرات تجميل', icon: 'Flame', slug: 'cosmetics' },
  { id: '5', name: 'هدايا وتغليف', icon: 'Gift', slug: 'gifts' },
  { id: '6', name: 'إلكترونيات ذكية', icon: 'Smartphone', slug: 'electronics' },
];

export const INITIAL_VENDORS: User[] = [
  {
    id: 'vendor_maha',
    name: 'مها أحمد',
    email: 'vendor1@maha.store',
    role: 'vendor',
    phone: '777123456',
    shopName: 'بوتيك مها للأناقة',
    shopDescription: 'أرقى خطوط الموضة والأزياء النسائية العصرية والمصممة خصيصاً لذوقك الرفيع.',
    shopLogo: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    joinedDate: '2026-01-10',
    isVerified: true,
    commissionRate: 10, // 10% commission
  },
  {
    id: 'vendor_elite_perfumes',
    name: 'عبد الرحمن مسعود',
    email: 'vendor2@maha.store',
    role: 'vendor',
    phone: '775888999',
    shopName: 'عطور النخبة الفاخرة',
    shopDescription: 'بخور وعطورات يمنية وشرقية متميزة بتركيز وثبات يدوم طويلاً، مع أرقى الماركات العالمية.',
    shopLogo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    joinedDate: '2026-02-15',
    isVerified: true,
    commissionRate: 8, // 8% commission
  },
  {
    id: 'vendor_gold_sparkle',
    name: 'سارة الصنعاني',
    email: 'vendor3@maha.store',
    role: 'vendor',
    phone: '733444555',
    shopName: 'مجوهرات البريق الذهبي',
    shopDescription: 'إكسسوارات ومجوهرات مطلية بالذهب وقطع فنية مطلية بالفضة صُنعت بحب لتلائم كل المناسبات.',
    shopLogo: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    joinedDate: '2026-03-01',
    isVerified: true,
    commissionRate: 12, // 12% commission
  },
  {
    id: 'vendor_tech_world',
    name: 'خالد اليماني',
    email: 'vendor4@maha.store',
    role: 'vendor',
    phone: '711222333',
    shopName: 'عالم التقنية الذكية',
    shopDescription: 'نوفر لك أحدث الأجهزة الذكية والإلكترونيات ومستلزماتها بأفضل الأسعار وبضمانة حقيقية.',
    shopLogo: 'https://images.unsplash.com/photo-1628157582853-a796fa650a6a?w=150&auto=format&fit=crop&q=80',
    joinedDate: '2026-04-12',
    isVerified: false,
    commissionRate: 5,
  },
  {
    id: 'vendor_mlika',
    name: 'متجر ملكة',
    email: 'info@mlika-sa.com',
    role: 'vendor',
    phone: '0551234567',
    shopName: 'متجر ملكة - اختيارك الأنيق للهدايا',
    shopDescription: 'متجر ملكة هو خيارك الأنيق لتقديم أرقى الهدايا الفاخرة، بوكسات الهدايا المتكاملة، تنسيقات الورد الطبيعي، والمطليات والمباخر المخصصة بالاسم لتخليد أجمل اللحظات.',
    shopLogo: 'https://images.unsplash.com/photo-1513151233558-d860c5398176?w=150&auto=format&fit=crop&q=80',
    joinedDate: '2026-06-29',
    isVerified: true,
    commissionRate: 10,
  }
];

export const INITIAL_PRODUCTS: Product[] = [
  // Category: clothing (ملابس وأزياء) - Vendor: vendor_maha
  {
    id: 'prod_1',
    title: 'فستان مخملي ملكي مطرز بالخيوط الذهبية',
    description: 'فستان نسائي فاخر من المخمل الناعم بتصميم عصري وأكمام طويلة مطرزة يدوياً بخيوط ذهبية تمنحك إطلالة ملكية في الحفلات والمناسبات السعيدة.',
    price: 35000,
    originalPrice: 42000,
    images: [
      'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=600&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=600&auto=format&fit=crop&q=80'
    ],
    category: 'clothing',
    vendorId: 'vendor_maha',
    vendorName: 'بوتيك مها للأناقة',
    stock: 12,
    salesCount: 45,
    rating: 4.8,
    reviewsCount: 14,
    isBestSeller: true,
    isDailyOffer: true,
    createdAt: '2026-05-01',
    features: ['مخمل ناعم 100%', 'تطريز ذهبي فاخر ومقاوم للتلف', 'متوفر بمقاسات متعددة (S, M, L, XL)', 'صناعة محلية فاخرة']
  },
  {
    id: 'prod_2',
    title: 'عباية كلاسيكية سوداء بتطريز الحرير والأحجار الكريستالية',
    description: 'عباية نسائية سوداء أنيقة من قماش الكريب الياباني الفاخر، تتميز بتطريز ناعم على الأكمام بالحرير والخرز الكريستالي اللامع لتناسب الاستخدام اليومي والمناسبات الرسمية.',
    price: 28000,
    originalPrice: 32000,
    images: [
      'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=600&auto=format&fit=crop&q=80'
    ],
    category: 'clothing',
    vendorId: 'vendor_maha',
    vendorName: 'بوتيك مها للأناقة',
    stock: 8,
    salesCount: 32,
    rating: 4.9,
    reviewsCount: 9,
    isBestSeller: true,
    createdAt: '2026-05-10',
    features: ['قماش كريب ياباني بارد ومريح', 'قصة مريحة وعملية', 'تأتي مع شيلة مطابقة مجاناً', 'غسيل جاف وسهل الكي']
  },

  // Category: perfumes (عطور وبخور) - Vendor: vendor_elite_perfumes
  {
    id: 'prod_3',
    title: 'عطر العود الملكي مع دهن الورد الطائفي وعنبر صخري',
    description: 'مزيج ساحر صُمم بعناية لعشاق الفخامة العربية والشرقية، يجمع بين دهن العود الكمبودي المعتق وعذوبة الورد الطائفي النادر مع لمسة دافئة من العنبر والمسك.',
    price: 45000,
    originalPrice: 55000,
    images: [
      'https://images.unsplash.com/photo-1541643600914-78b084683601?w=600&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1523293182086-7651a899d37f?w=600&auto=format&fit=crop&q=80'
    ],
    category: 'perfumes',
    vendorId: 'vendor_elite_perfumes',
    vendorName: 'عطور النخبة الفاخرة',
    stock: 15,
    salesCount: 88,
    rating: 5.0,
    reviewsCount: 24,
    isBestSeller: true,
    isDailyOffer: true,
    createdAt: '2026-04-15',
    features: ['تركيز وثبات يدوم أكثر من 48 ساعة', 'زجاجة كرستال مذهبة بسعة 100 مل', 'مكونات طبيعية خالية من الكحول الصناعي', 'علبة فاخرة مبطنة بالمخمل الأسود مناسبة للإهداء']
  },
  {
    id: 'prod_4',
    title: 'بخور عدني ملكي ممتاز بالمسك والظفور المعتق',
    description: 'بخور عدني تقليدي مُحضر يدوياً بأيدي خبراء البخور اليمني. غني بزيوت الصندل، المسك والزعفران الفاخر، مع قطع الظفور المعطرة لتبخير المنازل والمساجد والمجالس بنكهة أصيلة تدوم لأيام.',
    price: 15000,
    images: [
      'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=600&auto=format&fit=crop&q=80'
    ],
    category: 'perfumes',
    vendorId: 'vendor_elite_perfumes',
    vendorName: 'عطور النخبة الفاخرة',
    stock: 25,
    salesCount: 120,
    rating: 4.7,
    reviewsCount: 42,
    isBestSeller: true,
    createdAt: '2026-03-20',
    features: ['مُحضر بخلطة عدنية سرية متوارثة', 'رائحة دافئة وهادئة ولا تسبب حساسية الصدر', 'وزن العبوة 250 جرام', 'ثبات مميز على الملابس والستائر والسجاد']
  },

  // Category: accessories (إكسسوارات ومجوهرات) - Vendor: vendor_gold_sparkle
  {
    id: 'prod_5',
    title: 'قلادة الياسمين المطلية بذهب عيار 21 مع حجر الفيروز',
    description: 'قلادة راقية تجمع بين الرقي والتراث، مصنوعة من الفضة الخالصة ومطلية بذهب عيار 21 اللامع ومزينة بحجر الفيروز الطبيعي الأزرق الأخاذ الذي يمنحك تألقاً فريداً.',
    price: 18000,
    originalPrice: 24000,
    images: [
      'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=600&auto=format&fit=crop&q=80'
    ],
    category: 'accessories',
    vendorId: 'vendor_gold_sparkle',
    vendorName: 'مجوهرات البريق الذهبي',
    stock: 6,
    salesCount: 15,
    rating: 4.6,
    reviewsCount: 5,
    isDailyOffer: true,
    createdAt: '2026-05-25',
    features: ['طلاء ذهب عيار 21 مضاد للتغير والحساسية', 'سلسلة قابلة لتعديل الطول', 'حجر فيروز طبيعي أصلي', 'تأتي بعلبة إهداء خشبية مميزة']
  },
  {
    id: 'prod_6',
    title: 'طقم أساور حريرية مذهبة بتصميم المرجان التقليدي',
    description: 'مجموعة من 3 أساور معدنية مطلية بالذهب ومرصعة بخرز بلون المرجان الأحمر الناري وخيوط حريرية منسوجة يدوياً بدقة فائقة لتلائم الأزياء العصرية والتقليدية.',
    price: 12000,
    images: [
      'https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=600&auto=format&fit=crop&q=80'
    ],
    category: 'accessories',
    vendorId: 'vendor_gold_sparkle',
    vendorName: 'مجوهرات البريق الذهبي',
    stock: 18,
    salesCount: 22,
    rating: 4.5,
    reviewsCount: 8,
    createdAt: '2026-04-30',
    features: ['مرونة في اللبس والخلع لتناسب كل أحجام المعصم', 'خرز مرجاني عالي الجودة', 'ألوان زاهية ومقاومة للماء والعطور', 'صنع يدوي بالكامل']
  },

  // Category: cosmetics (مستحضرات تجميل) - Vendor: vendor_maha / vendor_gold_sparkle
  {
    id: 'prod_7',
    title: 'لوحة ظلال العيون المات واللامع - 24 لوناً مخملياً دافئاً',
    description: 'باليت ظلال العيون الاحترافي الذي يضم 24 تدرجاً لونياً جذاباً ما بين المات المخملي والألوان الميتاليك البراقة. تميزي بمكياج عيون ناعم للنهار أو جريء وسموكي للمساء بفضل ثبات الألوان العالي وسهولة الدمج.',
    price: 14500,
    originalPrice: 19000,
    images: [
      'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=600&auto=format&fit=crop&q=80'
    ],
    category: 'cosmetics',
    vendorId: 'vendor_maha',
    vendorName: 'بوتيك مها للأناقة',
    stock: 20,
    salesCount: 40,
    rating: 4.8,
    reviewsCount: 17,
    isBestSeller: true,
    createdAt: '2026-05-15',
    features: ['مكونات آمنة ومصرحة طبياً للبشرة الحساسة', 'تدرج مذهل من النود والترابي إلى الذهبي والبرونزي', 'سهل الدمج بالفرشاة أو الأصابع ولا يتكتل', 'مرآة داخلية عريضة وواضحة']
  },

  // Category: gifts (هدايا وتغليف) - Vendor: vendor_maha
  {
    id: 'prod_8',
    title: 'صندوق الهدايا الفاخر - عطر، قلادة، وشوكولاتة بلجيكية بالزعفران',
    description: 'تنسيق متكامل وجاهز لإسعاد من تحب. يحتوي هذا الصندوق الراقي المكسو بجلد الشامواه الفخم على عطر صغير مركز، قلادة ناعمة مطلية بالفضة، وعبوة من الشوكولاتة البلجيكية المصنوعة يدوياً والمحشوة بالهيل والزعفران.',
    price: 32000,
    originalPrice: 38000,
    images: [
      'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=600&auto=format&fit=crop&q=80'
    ],
    category: 'gifts',
    vendorId: 'vendor_maha',
    vendorName: 'بوتيك مها للأناقة',
    stock: 5,
    salesCount: 19,
    rating: 4.9,
    reviewsCount: 11,
    isDailyOffer: true,
    createdAt: '2026-05-18',
    features: ['صندوق مخملي أنيق مزود بشريط ستان ذهبي', 'إمكانية طباعة بطاقة إهداء مخصصة مجاناً', 'شوكولاتة طازجة وتوصيل مبرد وسريع', 'هدية ممتازة للأعياد، التخرج ومناسبات الزواج']
  },

  // Category: electronics (إلكترونيات ذكية) - Vendor: vendor_tech_world
  {
    id: 'prod_9',
    title: 'ساعة يد ذكية مقاومة للماء مع شاشة AMOLED وقياس المؤشرات الصحية',
    description: 'أحدث الساعات الذكية بتصميم دائري كلاسيكي جذاب، تدعم الاتصال الصوتي عبر البلوتوث، وتتبع نبضات القلب، والأكسجين في الدم، وخطوات المشي وتتوفر ببطارية تدوم لـ 14 يوماً من الاستخدام المتواصل.',
    price: 25000,
    originalPrice: 29000,
    images: [
      'https://images.unsplash.com/photo-1542496658-e33a6d0d50f6?w=600&auto=format&fit=crop&q=80'
    ],
    category: 'electronics',
    vendorId: 'vendor_tech_world',
    vendorName: 'عالم التقنية الذكية',
    stock: 14,
    salesCount: 28,
    rating: 4.4,
    reviewsCount: 6,
    createdAt: '2026-05-05',
    features: ['شاشة AMOLED لمسية مقاس 1.43 بوصة فائقة الوضوح', 'مقاومة للماء والغبار بمعيار IP68', 'تدعم التنبيه باللغة العربية بالكامل', 'أكثر من 100 وضع رياضي مختلف']
  },
  // Products from "متجر ملكة - اختيارك الأنيق للهدايا والمنتجات" (mlika-sa.com)
  {
    id: 'prod_mlika_1',
    title: 'بوكس هدايا "ملكة الأناقة" المتكامل والفاخر',
    description: 'صندوق إهداء راقٍ جداً ومنسق بعناية فائقة يجمع بين الفخامة والنعومة. يحتوي على عطر فرنسي ميني ذو رائحة جذابة وثابتة، إسوارة ناعمة مطلية بالذهب عيار 18، تدرج أنيق من الورد الجوري الصناعي المجفف، وبطاقة إهداء فاخرة لكتابة مشاعركم بصدق.',
    price: 26000,
    originalPrice: 32000,
    images: [
      'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=600&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1513151233558-d860c5398176?w=600&auto=format&fit=crop&q=80'
    ],
    category: 'gifts',
    vendorId: 'vendor_mlika',
    vendorName: 'متجر ملكة - اختيارك الأنيق للهدايا',
    stock: 15,
    salesCount: 142,
    rating: 4.9,
    reviewsCount: 34,
    isBestSeller: true,
    isDailyOffer: true,
    createdAt: '2026-06-10',
    features: ['تغليف ملكي فخم بشريط ستان ذهبي عريض', 'عطر فرنسي ميني بتركيز فواح يدوم طويلاً', 'إسوارة كلاسيكية مطلية بالذهب عيار 18 مقاومة لتغير اللون', 'باقة ورد مدمجة بألوان متناسقة ومريحة للعين']
  },
  {
    id: 'prod_mlika_2',
    title: 'قلادة "ملكة القلوب" المصممة بالاسم مطلية بالذهب عيار 21',
    description: 'قلادة استثنائية تُصنع وتصاغ يدوياً خصيصاً لكِ أو لمن تحبين بالاسم الذي تختارينه باللغة العربية أو الإنجليزية. مطلية بذهب عيار 21 اللامع والفاخر وتأتي في علبة مخملية أنيقة جاهزة للإهداء المباشر.',
    price: 18000,
    originalPrice: 22000,
    images: [
      'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=600&auto=format&fit=crop&q=80'
    ],
    category: 'accessories',
    vendorId: 'vendor_mlika',
    vendorName: 'متجر ملكة - اختيارك الأنيق للهدايا',
    stock: 20,
    salesCount: 215,
    rating: 5.0,
    reviewsCount: 58,
    isBestSeller: true,
    createdAt: '2026-06-12',
    features: ['طلاء ذهب عيار 21 حقيقي ومكفول ضد الحساسية وتغير اللون', 'صنع يدوي بالكامل بأيدي خبراء صياغة المجوهرات', 'سلسلة رفيعة أنيقة وقابلة لتعديل مقاس الطول بسهولة', 'صندوق إهداء مخملي بلون المارون (الخمري) الملكي الفاخر']
  },
  {
    id: 'prod_mlika_3',
    title: 'استاند مبخرة ملكية مخصصة بالاسم مع درج داخلي للبخور',
    description: 'استاند مبخرة فاخر يتميز بتصميمه المودرن والراقي، منقوش ومحفور عليه الاسم بالليزر أو مطلي بالاكريليك الذهبي اللامع. يحتوي على مبخرة مدمجة، ودرج مغناطيسي مخفي لحفظ كسرات العود والمسك بأسلوب منظم وجميل.',
    price: 24000,
    originalPrice: 28000,
    images: [
      'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=600&auto=format&fit=crop&q=80'
    ],
    category: 'perfumes',
    vendorId: 'vendor_mlika',
    vendorName: 'متجر ملكة - اختيارك الأنيق للهدايا',
    stock: 8,
    salesCount: 89,
    rating: 4.8,
    reviewsCount: 22,
    isBestSeller: false,
    isDailyOffer: true,
    createdAt: '2026-06-15',
    features: ['خشب زان أصلي معالج بالكامل ومقاوم للحرارة المباشرة', 'كتابة وتخصيص الاسم بخطوط عربية ديوانية وتشكيلات ساحرة', 'درج مدمج وسلس مغطى بغطاء محكم لحماية العود من الرطوبة', 'يأتي مع ملقط فحم ذهبي كلاسيكي مجاني']
  },
  {
    id: 'prod_mlika_4',
    title: 'باقة ورد طبيعي "سيمفونية الحب" مع شوكولاتة باتشي الفاخرة',
    description: 'التعبير الأجمل عن مشاعرك النقية والمميزة، باقة من الورد الجوري الأحمر الطبيعي المنسق دائرياً باحترافية عالية، مدمجة وصانعة توازن بديع مع صندوق أنيق يحتوي على أرقى أنواع الشوكولاتة البلجيكية من باتشي (Patchi) لتقديم هدية تليق بالملوك.',
    price: 32000,
    images: [
      'https://images.unsplash.com/photo-1513151233558-d860c5398176?w=600&auto=format&fit=crop&q=80'
    ],
    category: 'gifts',
    vendorId: 'vendor_mlika',
    vendorName: 'متجر ملكة - اختيارك الأنيق للهدايا',
    stock: 10,
    salesCount: 64,
    rating: 4.9,
    reviewsCount: 19,
    createdAt: '2026-06-18',
    features: ['ورد جوري طبيعي مستورد طازج يدوم نضراً لعدة أيام', 'صندوق شوكولاتة باتشي فاخر ومحشو بنكهات منوعة', 'تنسيق وتغليف كوري فاخر بلون أسود داكن جذاب وشريط ملكي', 'توصيل مبرد وعناية فائقة أثناء النقل لضمان سلامة الورد والشوكولاتة']
  },
  {
    id: 'prod_mlika_5',
    title: 'طقم "الفخامة والوقار" عطر فرنسي ومحفظة جلد وساعة كلاسيكية',
    description: 'طقم هدايا رجالي متكامل ومميز جداً، منسق وموضوع داخل صندوق جلدي أسود مبطن بالمخمل. يحتوي الطقم على ساعة رجالية أنيقة ذات تصميم كلاسيكي جذاب ومقاومة للماء، محفظة للبطاقات والعملات من الجلد الطبيعي الفاخر، وعطر رجالي مركز وثابت برائحة الأخشاب والصندل الفواحة.',
    price: 35000,
    originalPrice: 40000,
    images: [
      'https://images.unsplash.com/photo-1542496658-e33a6d0d50f6?w=600&auto=format&fit=crop&q=80'
    ],
    category: 'gifts',
    vendorId: 'vendor_mlika',
    vendorName: 'متجر ملكة - اختيارك الأنيق للهدايا',
    stock: 12,
    salesCount: 95,
    rating: 4.7,
    reviewsCount: 16,
    isBestSeller: true,
    createdAt: '2026-06-20',
    features: ['ساعة رجالية كلاسيكية بضمان ذهبي لمدة سنة كاملة ضد العيوب والماء', 'محفظة جلدية طبيعية 100% متينة وتحمي بطاقاتك بفعالية', 'عطر رجالي فواح بسعة 60 مل بتركيز Eau de Parfum', 'صندوق جلدي فخم مبطن بالمخمل ومناسب جداً للمناسبات الرسمية والخاصة']
  },
  {
    id: 'prod_mlika_6',
    title: 'تعليقة سيارة ملكية بالاسم مطلية بالذهب مع كسرة عود طبيعي',
    description: 'أضيفوا لمسة من الأناقة والجاذبية لسيارتكم أو سيارة من تحبون مع تعليقة السيارة الملكية الفاخرة المخصصة بالاسم المطلي بالذهب أو الفضة اللامعة، والمزودة بكسرة من العود المروكي الطبيعي الفاخر لتعطير السيارة برائحة البخور الأصيل بمجرد تعرضها للحرارة أو أشعة الشمس الطبيعية.',
    price: 14000,
    images: [
      'https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=600&auto=format&fit=crop&q=80'
    ],
    category: 'accessories',
    vendorId: 'vendor_mlika',
    vendorName: 'متجر ملكة - اختيارك الأنيق للهدايا',
    stock: 30,
    salesCount: 310,
    rating: 4.9,
    reviewsCount: 74,
    isBestSeller: true,
    createdAt: '2026-06-22',
    features: ['تخصيص وكتابة الاسم بخط عربي جذاب بالذهب أو الفضة', 'كسرة عود مروكي طبيعي أصلي ذات رائحة بخورية فواحة تدوم طويلاً', 'حبل أو سلسلة ناعمة لسهولة تعليقها على مرآة السيارة دون حجب الرؤية', 'كرتون إهداء أنيق ومطبوع عليه عبارة قيادة آمنة']
  }
];

export const INITIAL_REVIEWS: Review[] = [
  {
    id: 'rev_1',
    productId: 'prod_1',
    userId: 'user_cust_1',
    userName: 'أم محمد الصنعاني',
    userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
    rating: 5,
    comment: 'الفستان يجنن يابنات! القماش مخملي ناعم والتطريز دقيق جداً والخيوط الذهبية واضحة وفخمة. التوصيل كان سريع والتعامل راقي جداً من مها.',
    createdAt: '2026-06-01'
  },
  {
    id: 'rev_2',
    productId: 'prod_3',
    userId: 'user_cust_2',
    userName: 'جمال العولقي',
    userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80',
    rating: 5,
    comment: 'أفضل عطر عود اشتريته في حياتي. ريحة الورد الطائفي بارزة ومنعشة مع دفيء العود. الثبات يجلس يومين بالثياب وكل حد يسألني عن العطر.',
    createdAt: '2026-06-10'
  },
  {
    id: 'rev_3',
    productId: 'prod_4',
    userId: 'user_cust_3',
    userName: 'نادية الحضرمي',
    rating: 4,
    comment: 'البخور العدني رائحته أصيلة جداً وممتازة، يثبت بالمنزل بشكل فظيع. العبوة راهية وتكفي لفترة طويلة. يستاهل التجربة.',
    createdAt: '2026-06-12'
  }
];

export const INITIAL_COUPONS: Coupon[] = [
  { code: 'MAHA10', discountType: 'percentage', value: 10, minSpend: 15000, isActive: true },
  { code: 'YEMEN2026', discountType: 'fixed', value: 3000, minSpend: 25000, isActive: true },
  { code: 'GOLDEN', discountType: 'percentage', value: 15, minSpend: 20000, isActive: true },
];

export const INITIAL_MESSAGES: Message[] = [
  {
    id: 'msg_1',
    senderId: 'customer_guest',
    senderRole: 'customer',
    receiverId: 'vendor_maha',
    content: 'السلام عليكم ورحمة الله، بخصوص الفستان المخملي، هل متوفر مقاس XL حالياً؟',
    timestamp: '2026-06-25T14:30:00Z',
    productId: 'prod_1',
    productTitle: 'فستان مخملي ملكي مطرز بالخيوط الذهبية'
  },
  {
    id: 'msg_2',
    senderId: 'vendor_maha',
    senderRole: 'vendor',
    receiverId: 'customer_guest',
    content: 'وعليكم السلام ورحمة الله وبركاته أهلاً بكِ أختي العزيزة. نعم متوفر مقاس XL ويوجد منه قطعة واحدة متبقية فقط، يسعدنا خدمتكِ في أي وقت.',
    timestamp: '2026-06-25T14:45:00Z',
    productId: 'prod_1',
    productTitle: 'فستان مخملي ملكي مطرز بالخيوط الذهبية'
  },
  {
    id: 'msg_3',
    senderId: 'customer_guest',
    senderRole: 'customer',
    receiverId: 'vendor_elite_perfumes',
    content: 'مرحباً، هل العطر العود الملكي مع دهن الورد يأتي بعلبة إهداء أم يجب علي طلب علبة منفصلة؟',
    timestamp: '2026-06-26T08:15:00Z',
    productId: 'prod_3',
    productTitle: 'عطر العود الملكي مع دهن الورد الطائفي وعنبر صخري'
  },
  {
    id: 'msg_4',
    senderId: 'vendor_elite_perfumes',
    senderRole: 'vendor',
    receiverId: 'customer_guest',
    content: 'أهلاً بك يا فندم، نعم العطر يأتي مغلفاً داخل علبة خشبية فاخرة جداً مبطنة بالمخمل الأسود، جاهزة تماماً كهدية فاخرة دون الحاجة لأي تغليف إضافي.',
    timestamp: '2026-06-26T08:20:00Z',
    productId: 'prod_3',
    productTitle: 'عطر العود الملكي مع دهن الورد الطائفي وعنبر صخري'
  }
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'ord_1001',
    customerId: 'customer_demo_id',
    customerName: 'فؤاد سالم الريمي',
    customerPhone: '771234567',
    customerAddress: 'صنعاء - شارع حدة - بجانب مركز جندول',
    items: [
      {
        productId: 'prod_3',
        productTitle: 'عطر العود الملكي مع دهن الورد الطائفي وعنبر صخري',
        price: 45000,
        quantity: 1,
        vendorId: 'vendor_elite_perfumes',
        image: 'https://images.unsplash.com/photo-1541643600914-78b084683601?w=600&auto=format&fit=crop&q=80'
      }
    ],
    totalPrice: 45000,
    discountAmount: 4500, // 10% discount from MAHA10
    finalPrice: 40500,
    paymentMethod: 'kuraimi',
    paymentDetails: 'حوالة باسم عبد الرحمن مسعود - رقم مرجعي: 82930219',
    status: 'processing',
    createdAt: '2026-06-24T18:30:00Z',
    commissionEarned: 3240 // 8% commission on final price (approx)
  },
  {
    id: 'ord_1002',
    customerId: 'customer_demo_id',
    customerName: 'فؤاد سالم الريمي',
    customerPhone: '771234567',
    customerAddress: 'عدن - المنصورة - حي كابوتا',
    items: [
      {
        productId: 'prod_5',
        productTitle: 'قلادة الياسمين المطلية بذهب عيار 21 مع حجر الفيروز',
        price: 18000,
        quantity: 1,
        vendorId: 'vendor_gold_sparkle',
        image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=600&auto=format&fit=crop&q=80'
      },
      {
        productId: 'prod_6',
        productTitle: 'طقم أساور حريرية مذهبة بتصميم المرجان التقليدي',
        price: 12000,
        quantity: 1,
        vendorId: 'vendor_gold_sparkle',
        image: 'https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=600&auto=format&fit=crop&q=80'
      }
    ],
    totalPrice: 30000,
    discountAmount: 3000, // discount code YEMEN2026
    finalPrice: 27000,
    paymentMethod: 'cod',
    status: 'pending',
    createdAt: '2026-06-25T11:20:00Z',
    commissionEarned: 3240 // 12% commission of 27000 is 3240
  },
  {
    id: 'ord_1003',
    customerId: 'customer_another_id',
    customerName: 'مريم الصنعاني',
    customerPhone: '734555666',
    customerAddress: 'تعز - المسبح - مقابل مدرسة جيل الغد',
    items: [
      {
        productId: 'prod_1',
        productTitle: 'فستان مخملي ملكي مطرز بالخيوط الذهبية',
        price: 35000,
        quantity: 1,
        vendorId: 'vendor_maha',
        image: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=600&auto=format&fit=crop&q=80'
      }
    ],
    totalPrice: 35000,
    discountAmount: 0,
    finalPrice: 35000,
    paymentMethod: 'jeeb',
    paymentDetails: 'دفع عبر محفظة جيب - حساب: 734555666',
    status: 'delivered',
    createdAt: '2026-06-20T09:40:00Z',
    commissionEarned: 3500 // 10% of 35000
  }
];
