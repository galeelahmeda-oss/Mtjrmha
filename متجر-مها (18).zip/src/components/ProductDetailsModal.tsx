import React, { useState } from 'react';
import { X, Star, ShoppingCart, MessageSquare, ShieldCheck, Check, Send, Sparkles } from 'lucide-react';
import { Product, Review } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface ProductDetailsModalProps {
  product: Product;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number, selectedOptions?: { [key: string]: string }, userNote?: string) => void;
  onStartChat: (vendorId: string, productTitle: string, productId: string) => void;
  reviews: Review[];
  onAddReview: (review: Omit<Review, 'id' | 'createdAt'>) => void;
  isWishlisted: boolean;
  onToggleWishlist: (productId: string) => void;
}

export default function ProductDetailsModal({
  product,
  onClose,
  onAddToCart,
  onStartChat,
  reviews,
  onAddReview,
  isWishlisted,
  onToggleWishlist,
}: ProductDetailsModalProps) {
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [newComment, setNewComment] = useState('');
  const [newRating, setNewRating] = useState(5);
  const [reviewerName, setReviewerName] = useState('');
  const [reviewSuccess, setReviewSuccess] = useState(false);

  const [selectedOptions, setSelectedOptions] = useState<{ [key: string]: string }>(() => {
    const initial: { [key: string]: string } = {};
    if (product.options) {
      product.options.forEach(opt => {
        if (opt.values && opt.values.length > 0) {
          initial[opt.name] = opt.values[0];
        }
      });
    }
    return initial;
  });
  const [customerNote, setCustomerNote] = useState('');

  const getYouTubeEmbedUrl = (url?: string) => {
    if (!url) return null;
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? `https://www.youtube.com/embed/${match[2]}` : null;
  };

  const productReviews = reviews.filter((r) => r.productId === product.id);

  const handleAddReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewerName.trim() || !newComment.trim()) return;

    onAddReview({
      productId: product.id,
      userId: 'customer_guest',
      userName: reviewerName,
      rating: newRating,
      comment: newComment,
    });

    setReviewerName('');
    setNewComment('');
    setNewRating(5);
    setReviewSuccess(true);
    setTimeout(() => setReviewSuccess(false), 3000);
  };

  const hasDiscount = product.originalPrice && product.originalPrice > product.price;

  return (
    <div id="product-details-modal" className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white rounded-3xl w-full max-w-4xl max-h-[90vh] overflow-y-auto shadow-2xl relative border border-zinc-100 flex flex-col"
      >
        {/* Close Button */}
        <button
          id="btn-close-details"
          onClick={onClose}
          className="absolute top-4 left-4 w-10 h-10 rounded-full bg-zinc-100 hover:bg-zinc-200 text-zinc-800 flex items-center justify-center transition-colors cursor-pointer z-25"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-6 md:p-8">
          {/* Column 1: Image Gallery */}
          <div className="space-y-4">
            <div className="aspect-square rounded-2xl overflow-hidden bg-zinc-50 border border-zinc-100 relative">
              <img
                src={(product.images && product.images[selectedImage]) || 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=600'}
                alt={product.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              {hasDiscount && (
                <span className="absolute top-4 right-4 bg-red-500 text-white text-xs font-bold px-3 py-1.5 rounded-full shadow-lg">
                  عرض خاص خصم
                </span>
              )}
            </div>

            {/* Thumbnails */}
            {product.images && product.images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto pb-1">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImage(idx)}
                    className={`w-20 h-20 rounded-xl overflow-hidden border-2 cursor-pointer flex-shrink-0 transition-all ${
                      selectedImage === idx ? 'border-amber-500 scale-95' : 'border-zinc-200 hover:border-zinc-300'
                    }`}
                  >
                    <img src={img} alt="" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}

            {/* Vendor card info */}
            <div className="bg-zinc-50 p-4 rounded-2xl border border-zinc-100 mt-6 flex justify-between items-center">
              <div>
                <span className="text-[10px] text-zinc-400 block">تفاصيل المتجر</span>
                <span className="font-bold text-zinc-800 text-sm flex items-center gap-1">
                  متجر مها للأناقة
                  <ShieldCheck className="w-4 h-4 text-emerald-500 fill-emerald-500/10" />
                </span>
                <p className="text-[11px] text-zinc-500 mt-1">الموقع الرسمي والموزع الحصري في اليمن</p>
              </div>

              <button
                id="btn-chat-vendor"
                onClick={() => onStartChat(product.vendorId, product.title, product.id)}
                className="bg-zinc-900 hover:bg-amber-500 hover:text-zinc-950 text-white px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm cursor-pointer"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>دردشة مع الدعم</span>
              </button>
            </div>
          </div>

          {/* Column 2: Product Content */}
          <div className="space-y-6 flex flex-col justify-between">
            <div>
              {/* Category Breadcrumb */}
              <span className="bg-amber-500/10 text-amber-700 text-xs font-bold px-3 py-1 rounded-full border border-amber-500/20">
                {product.category === 'clothing' && 'ملابس وأزياء'}
                {product.category === 'accessories' && 'إكسسوارات ومجوهرات'}
                {product.category === 'perfumes' && 'عطور وبخور'}
                {product.category === 'cosmetics' && 'مستحضرات تجميل'}
                {product.category === 'gifts' && 'هدايا وتغليف'}
                {product.category === 'electronics' && 'إلكترونيات ذكية'}
              </span>

              {/* Title */}
              <h2 className="text-xl md:text-2xl font-black text-zinc-900 mt-3 mb-2 leading-snug">
                {product.title}
              </h2>

              {/* Rating & Sales */}
              <div className="flex items-center gap-3 text-sm mb-4">
                <div className="flex items-center text-amber-400">
                  <Star className="w-4 h-4 fill-amber-400" />
                  <span className="font-bold text-zinc-700 mr-1">{(product.rating ?? 5).toFixed(1)}</span>
                </div>
                <span className="text-zinc-300">|</span>
                <span className="text-zinc-500">({productReviews.length} تقييم حقيقي)</span>
                <span className="text-zinc-300">|</span>
                <span className="text-zinc-600 font-medium">تم بيع {product.salesCount ?? 0} قطعة</span>
              </div>

              {/* Divider */}
              <div className="border-t border-zinc-100 my-4"></div>

              {/* Price */}
              <div className="bg-zinc-50/50 p-4 rounded-2xl flex items-center justify-between mb-4">
                <div>
                  <span className="text-xs text-zinc-400 block mb-1">سعر المنتج</span>
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-black font-mono text-zinc-950">
                      {(product.price ?? 0).toLocaleString()}
                    </span>
                    <span className="text-xs text-zinc-500 font-bold">ريال يمني</span>
                  </div>
                </div>
                {hasDiscount && (
                  <div className="text-right">
                    <span className="text-xs text-zinc-400 line-through block font-mono">
                      {product.originalPrice?.toLocaleString()} ر.ي
                    </span>
                    <span className="text-xs text-red-500 font-bold bg-red-50 px-2 py-1 rounded-md">
                      وفرت {Math.round(product.originalPrice! - product.price).toLocaleString()} ر.ي
                    </span>
                  </div>
                )}
              </div>

              {/* Description */}
              <div className="space-y-2">
                <h4 className="font-bold text-zinc-800 text-sm">وصف المنتج</h4>
                <p className="text-zinc-600 text-xs leading-relaxed">{product.description}</p>
                
                {product.weight && (
                  <div className="flex items-center gap-1.5 text-xs text-zinc-600 bg-zinc-100 px-3 py-1.5 rounded-xl w-fit mt-2 font-sans">
                    <span>⚖️ الوزن:</span>
                    <span className="font-bold text-zinc-900">{product.weight}</span>
                  </div>
                )}
              </div>

              {/* Features List */}
              {product.features && product.features.length > 0 && (
                <div className="mt-4 space-y-2">
                  <h4 className="font-bold text-zinc-800 text-sm">مميزات ومواصفات</h4>
                  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {product.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start gap-1.5 text-zinc-600">
                        <Check className="w-3.5 h-3.5 text-amber-500 mt-0.5 flex-shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Product Options Selection */}
              {product.options && product.options.length > 0 && (
                <div className="mt-5 p-4 bg-zinc-50 rounded-2xl border border-zinc-100/85 space-y-4 text-right" dir="rtl">
                  <h4 className="font-bold text-zinc-800 text-xs flex items-center gap-1.5">
                    <span>🎨</span>
                    <span>خيارات المنتج المتاحة:</span>
                  </h4>
                  <div className="space-y-3">
                    {product.options.map((opt) => (
                      <div key={opt.name} className="space-y-1">
                        <span className="text-[11px] font-bold text-zinc-500 block">{opt.name}:</span>
                        <div className="flex flex-wrap gap-1.5">
                          {opt.values.map((val) => (
                            <button
                              key={val}
                              type="button"
                              onClick={() => setSelectedOptions(prev => ({ ...prev, [opt.name]: val }))}
                              className={`text-[10.5px] px-2.5 py-1 rounded-lg border transition-all cursor-pointer ${
                                selectedOptions[opt.name] === val
                                  ? 'border-amber-500 bg-amber-50 text-amber-700 font-bold font-mono'
                                  : 'border-zinc-200 hover:border-zinc-300 text-zinc-600 bg-white font-mono'
                              }`}
                            >
                              {val}
                            </button>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Product custom warning/notes */}
              {product.notes && (
                <div className="mt-4 p-4 bg-amber-50/50 border border-amber-500/20 rounded-2xl text-[11px] text-zinc-700 space-y-1 text-right" dir="rtl">
                  <div className="flex items-center gap-1.5 text-amber-800 font-bold">
                    <span>📌</span>
                    <span>ملاحظة هامة من المتجر:</span>
                  </div>
                  <p className="leading-relaxed">{product.notes}</p>
                </div>
              )}

              {/* YouTube Video Embed */}
              {product.youtubeUrl && getYouTubeEmbedUrl(product.youtubeUrl) && (
                <div className="mt-4 space-y-2 text-right">
                  <h4 className="font-bold text-zinc-800 text-xs flex items-center gap-1.5">
                    <span>🎥</span>
                    <span>شاهد فيديو توضيحي للمنتج:</span>
                  </h4>
                  <div className="aspect-video w-full rounded-2xl overflow-hidden border border-zinc-100 shadow-sm bg-black">
                    <iframe
                      src={getYouTubeEmbedUrl(product.youtubeUrl)!}
                      title="YouTube video player"
                      frameBorder="0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                      allowFullScreen
                      className="w-full h-full"
                    ></iframe>
                  </div>
                </div>
              )}

              {/* Customer Custom Note Form */}
              <div className="mt-4 space-y-1 text-right">
                <label className="text-[11px] font-bold text-zinc-500 block">هل لديك أي طلب أو ملاحظة خاصة للمنتج؟ (اختياري)</label>
                <textarea
                  placeholder="مثال: يرجى توفير تغليف هدية فاخرة، أو مقاسات خاصة..."
                  value={customerNote}
                  onChange={(e) => setCustomerNote(e.target.value)}
                  rows={2}
                  className="w-full text-xs p-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white focus:outline-none focus:border-amber-500 resize-none transition-all"
                  dir="rtl"
                />
              </div>
            </div>

            {/* Add to Cart Actions */}
            <div className="space-y-3 pt-4 border-t border-zinc-100">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-zinc-700">الكمية المطلوبة:</span>
                <div className="flex items-center gap-1 bg-zinc-100 rounded-lg p-1">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    disabled={quantity <= 1}
                    className="w-8 h-8 rounded bg-white text-zinc-700 font-bold hover:bg-zinc-50 flex items-center justify-center cursor-pointer disabled:opacity-50"
                  >
                    -
                  </button>
                  <span className="w-10 text-center font-bold font-mono text-xs">{quantity}</span>
                  <button
                    onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                    disabled={quantity >= product.stock}
                    className="w-8 h-8 rounded bg-white text-zinc-700 font-bold hover:bg-zinc-50 flex items-center justify-center cursor-pointer disabled:opacity-50"
                  >
                    +
                  </button>
                </div>
                <span className="text-[11px] text-zinc-400">المتوفر في المخزن: {product.stock} قطع</span>
              </div>

              <div className="flex gap-3">
                <button
                  id="btn-add-to-cart-modal"
                  onClick={() => {
                    onAddToCart(product, quantity, selectedOptions, customerNote);
                    onClose();
                  }}
                  disabled={product.stock <= 0}
                  className="flex-grow bg-amber-500 hover:bg-amber-600 text-zinc-950 font-bold py-3 px-6 rounded-xl transition-all shadow-md shadow-amber-500/10 flex items-center justify-center gap-2 cursor-pointer disabled:bg-zinc-200 disabled:text-zinc-400"
                >
                  <ShoppingCart className="w-5 h-5" />
                  <span>{product.stock > 0 ? 'إضافة إلى سلة التسوق' : 'نفذت الكمية من المتجر'}</span>
                </button>

                <button
                  onClick={() => onToggleWishlist(product.id)}
                  className={`px-4 rounded-xl border flex items-center justify-center cursor-pointer transition-all ${
                    isWishlisted
                      ? 'border-red-500 bg-red-50 text-red-500'
                      : 'border-zinc-200 hover:border-zinc-300 text-zinc-500'
                  }`}
                  title="أضف للمفضلة"
                >
                  <span className="text-sm font-bold ml-1 hidden sm:inline">
                    {isWishlisted ? 'بالمفضلة' : 'المفضلة'}
                  </span>
                  ★
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Reviews Section */}
        <div className="bg-zinc-50 border-t border-zinc-100 p-6 md:p-8 rounded-b-3xl">
          <h3 className="text-lg font-bold text-zinc-900 mb-6 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-500" />
            <span>آراء وتقييمات العملاء ({productReviews.length})</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Reviews list */}
            <div className="md:col-span-2 space-y-4">
              {productReviews.length > 0 ? (
                productReviews.map((review) => (
                  <div key={review.id} className="bg-white p-4 rounded-2xl border border-zinc-100 shadow-xs">
                    <div className="flex justify-between items-center mb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-zinc-200 overflow-hidden flex items-center justify-center font-bold text-xs text-zinc-600">
                          {review.userAvatar ? (
                            <img src={review.userAvatar} alt={review.userName} className="w-full h-full object-cover" />
                          ) : (
                            review.userName.slice(0, 2)
                          )}
                        </div>
                        <div>
                          <h5 className="font-bold text-zinc-800 text-xs">{review.userName}</h5>
                          <span className="text-[10px] text-zinc-400">{review.createdAt}</span>
                        </div>
                      </div>

                      <div className="flex items-center text-amber-400">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star
                            key={i}
                            className={`w-3 h-3 ${
                              i < review.rating ? 'fill-amber-400' : 'text-zinc-200'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                    <p className="text-zinc-600 text-xs leading-relaxed">{review.comment}</p>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 bg-white rounded-2xl border border-dashed border-zinc-200">
                  <p className="text-zinc-400 text-xs">لا توجد مراجعات بعد لهذا المنتج. كن أول من يقيمه!</p>
                </div>
              )}
            </div>

            {/* Review form */}
            <div className="bg-white p-5 rounded-2xl border border-zinc-100 shadow-xs h-fit space-y-4">
              <h4 className="font-bold text-zinc-800 text-sm">أضف تقييمك الشخصي</h4>

              {reviewSuccess ? (
                <div className="bg-emerald-50 text-emerald-700 text-xs p-3.5 rounded-xl border border-emerald-100 text-center font-bold">
                  ✓ تم إرسال تقييمك بنجاح! شكراً لك.
                </div>
              ) : (
                <form onSubmit={handleAddReviewSubmit} className="space-y-3.5">
                  <div>
                    <label className="text-[11px] font-bold text-zinc-500 block mb-1">اسمك الكريم</label>
                    <input
                      type="text"
                      required
                      placeholder="مثال: ياسمين أحمد"
                      value={reviewerName}
                      onChange={(e) => setReviewerName(e.target.value)}
                      className="w-full text-xs px-3 py-2 rounded-lg border border-zinc-200 focus:border-amber-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-zinc-500 block mb-1">التقييم بالنجوم</label>
                    <div className="flex items-center gap-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <button
                          key={i}
                          type="button"
                          onClick={() => setNewRating(i + 1)}
                          className="text-amber-400 hover:scale-110 transition-transform cursor-pointer"
                        >
                          <Star
                            className={`w-5 h-5 ${
                              i < newRating ? 'fill-amber-400' : 'text-zinc-200'
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-zinc-500 block mb-1">رأيك بالمنتج</label>
                    <textarea
                      required
                      rows={3}
                      placeholder="اكتب تجربتك وملاحظاتك بصدق..."
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      className="w-full text-xs p-3 rounded-lg border border-zinc-200 focus:border-amber-500 focus:outline-none resize-none"
                    ></textarea>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-zinc-950 hover:bg-amber-500 hover:text-zinc-950 text-white font-bold py-2 px-4 rounded-lg text-xs transition-colors flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>إرسال التقييم</span>
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
