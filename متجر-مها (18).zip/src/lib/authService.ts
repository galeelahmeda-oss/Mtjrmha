import { 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  collection, 
  getDocs, 
  onSnapshot,
  query,
  where
} from 'firebase/firestore';
import { db } from './firebase';
import { User as UserType, UserRole } from '../types';

const ADMIN_EMAIL = 'galeelahmeda@gmail.com';

// Local storage backup key
const LOCAL_USER_KEY = 'maha_auth_user';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const stored = localStorage.getItem(LOCAL_USER_KEY);
  let userId = null;
  let email = null;
  if (stored) {
    try {
      const parsed = JSON.parse(stored);
      userId = parsed.id;
      email = parsed.email;
    } catch (_) {}
  }

  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId,
      email,
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Generate secure random custom ID
function generateUniqueId(): string {
  return 'u_' + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

// Custom Auth State Observers
type AuthListener = (user: { uid: string; email: string | null; displayName: string | null } | null) => void;
const listeners = new Set<AuthListener>();

export function onAuthStateChanged(dummyAuth: any, callback: AuthListener) {
  listeners.add(callback);
  
  // Call immediately with current active user
  const stored = localStorage.getItem(LOCAL_USER_KEY);
  if (stored) {
    try {
      const user = JSON.parse(stored) as UserType;
      callback({
        uid: user.id,
        email: user.email || null,
        displayName: user.name || null
      });
    } catch {
      callback(null);
    }
  } else {
    callback(null);
  }
  
  return () => {
    listeners.delete(callback);
  };
}

export function notifyListeners(user: UserType | null) {
  const simulatedUser = user ? {
    uid: user.id,
    email: user.email || null,
    displayName: user.name || null
  } : null;
  
  listeners.forEach(cb => cb(simulatedUser));
}

/**
 * Creates a new user record in Firestore (replaces Firebase Auth SignUp)
 */
export async function signUpWithEmail(email: string, password: string, name: string, phone: string): Promise<UserType> {
  const cleanEmail = email.toLowerCase().trim();
  const cleanPassword = password.trim();

  // Check if email already registered
  const usersRef = collection(db, 'users');
  const q = query(usersRef, where('email', '==', cleanEmail));
  const querySnapshot = await getDocs(q);

  if (!querySnapshot.empty) {
    throw new Error('هذا البريد الإلكتروني مسجل بالفعل. يرجى تسجيل الدخول بدلاً من ذلك.');
  }

  const uid = generateUniqueId();
  const role: UserRole = cleanEmail === ADMIN_EMAIL.toLowerCase() ? 'admin' : 'customer';

  const newUser: any = {
    id: uid,
    name: name.trim(),
    email: cleanEmail,
    phone: phone.trim() || undefined,
    role,
    password: cleanPassword, // Safe client-side password verification field
    joinedDate: new Date().toLocaleDateString('en-US', { year: 'numeric', month: '2-digit', day: '2-digit' }),
  };

  try {
    await setDoc(doc(db, 'users', uid), newUser);
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `users/${uid}`);
  }
  
  const returnedUser: UserType = {
    id: uid,
    name: newUser.name,
    email: newUser.email,
    phone: newUser.phone,
    role: newUser.role,
    joinedDate: newUser.joinedDate,
  };

  localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(returnedUser));
  notifyListeners(returnedUser);
  return returnedUser;
}

/**
 * Logs in a user with Email and Password from Firestore
 */
export async function loginWithEmail(email: string, password: string): Promise<UserType> {
  const cleanEmail = email.toLowerCase().trim();
  const cleanPassword = password.trim();

  const usersRef = collection(db, 'users');
  const q = query(usersRef, where('email', '==', cleanEmail));
  
  let querySnapshot;
  try {
    querySnapshot = await getDocs(q);
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'users');
    throw err;
  }

  if (querySnapshot.empty) {
    throw new Error('البريد الإلكتروني غير مسجل لدينا، يرجى التأكد من البريد أو إنشاء حساب جديد.');
  }

  const userDoc = querySnapshot.docs[0];
  const userData = userDoc.data() as any;

  if (userData.password && userData.password !== cleanPassword) {
    throw new Error('كلمة المرور المدخلة غير صحيحة، يرجى المحاولة مجدداً.');
  }

  const data: UserType = {
    id: userDoc.id,
    name: userData.name,
    email: userData.email,
    phone: userData.phone,
    role: userData.role || 'customer',
    joinedDate: userData.joinedDate || new Date().toLocaleDateString('en-US'),
    isVerified: userData.isVerified,
  };

  // Auto upgrade galeelahmeda@gmail.com to admin
  if (cleanEmail === ADMIN_EMAIL.toLowerCase() && data.role !== 'admin') {
    try {
      await updateDoc(doc(db, 'users', userDoc.id), { role: 'admin' });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${userDoc.id}`);
    }
    data.role = 'admin';
  }
  
  localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(data));
  notifyListeners(data);
  return data;
}

/**
 * Custom Google Sign-In and registration using direct email
 */
export async function loginWithGoogleCustom(email: string, name: string): Promise<UserType> {
  const cleanEmail = email.toLowerCase().trim();
  const usersRef = collection(db, 'users');
  const q = query(usersRef, where('email', '==', cleanEmail));
  
  let querySnapshot;
  try {
    querySnapshot = await getDocs(q);
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'users');
    throw err;
  }

  if (!querySnapshot.empty) {
    const userDoc = querySnapshot.docs[0];
    const userData = userDoc.data() as any;
    
    const data: UserType = {
      id: userDoc.id,
      name: userData.name,
      email: userData.email,
      phone: userData.phone,
      role: userData.role || 'customer',
      joinedDate: userData.joinedDate || new Date().toLocaleDateString('en-US'),
      isVerified: userData.isVerified,
    };

    if (cleanEmail === ADMIN_EMAIL.toLowerCase() && data.role !== 'admin') {
      try {
        await updateDoc(doc(db, 'users', userDoc.id), { role: 'admin' });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `users/${userDoc.id}`);
      }
      data.role = 'admin';
    }

    localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(data));
    notifyListeners(data);
    return data;
  } else {
    const uid = 'g_' + generateUniqueId();
    const role: UserRole = cleanEmail === ADMIN_EMAIL.toLowerCase() ? 'admin' : 'customer';
    
    const newUser: any = {
      id: uid,
      name: name.trim(),
      email: cleanEmail,
      role,
      joinedDate: new Date().toLocaleDateString('en-US', { year: 'numeric', month: '2-digit', day: '2-digit' }),
    };

    try {
      await setDoc(doc(db, 'users', uid), newUser);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${uid}`);
    }

    const returnedUser: UserType = {
      id: uid,
      name: newUser.name,
      email: newUser.email,
      role: newUser.role,
      joinedDate: newUser.joinedDate,
    };

    localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(returnedUser));
    notifyListeners(returnedUser);
    return returnedUser;
  }
}

/**
 * Legacy loginWithGoogle signature kept for compatibility (direct simulated bypass)
 */
export async function loginWithGoogle(): Promise<UserType> {
  // Legacy Firebase sign-in is replaced with direct UI modal account chooser
  throw new Error('USE_GOOGLE_CUSTOM');
}

/**
 * Logs out the current user.
 */
export async function logoutUser(): Promise<void> {
  localStorage.removeItem(LOCAL_USER_KEY);
  notifyListeners(null);
}

/**
 * Subscribes to the active user's document in Firestore.
 */
export function subscribeToUserDoc(uid: string, onUpdate: (user: UserType | null) => void) {
  return onSnapshot(doc(db, 'users', uid), (snap) => {
    if (snap.exists()) {
      const user = snap.data() as UserType;
      localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(user));
      onUpdate(user);
    } else {
      onUpdate(null);
    }
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, `users/${uid}`);
  });
}

/**
 * Fetches all registered users (for admin panel user management).
 */
export async function getAllUsers(): Promise<UserType[]> {
  try {
    const querySnapshot = await getDocs(collection(db, 'users'));
    const usersList: UserType[] = [];
    querySnapshot.forEach((doc) => {
      usersList.push({
        ...doc.data(),
        id: doc.id
      } as UserType);
    });
    return usersList;
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'users');
    throw err;
  }
}

/**
 * Updates a user's role (admin only can execute this securely).
 */
export async function updateUserRoleInFirestore(userId: string, newRole: UserRole): Promise<void> {
  const userDocRef = doc(db, 'users', userId);
  try {
    await updateDoc(userDocRef, { role: newRole });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `users/${userId}`);
  }
}
