import React, { useState } from 'react';
import { X, ArrowRight, ShieldCheck, AlertCircle } from 'lucide-react';
import { motion } from 'motion/react';
import { User as UserType } from '../types';
import { loginWithGoogleCustom } from '../lib/authService';

interface CustomerLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (customer: UserType) => void;
}

export default function CustomerLoginModal({
  isOpen,
  onClose,
  onLoginSuccess,
}: CustomerLoginModalProps) {
  // Fields for custom Google chooser/login
  const [customGoogleEmail, setCustomGoogleEmail] = useState('');
  const [customGoogleName, setCustomGoogleName] = useState('');

  // Status and Error states
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSelectGoogleAccount = async (email: string, name: string) => {
    setError('');
    setLoading(true);
    try {
      const loggedUser = await loginWithGoogleCustom(email, name);
      onLoginSuccess(loggedUser);
      resetForm();
      onClose();
    } catch (err: any) {
      console.error('Google login error:', err);
      setError(err?.message || 'حدث خطأ أثناء الاتصال بحساب Google.');
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setCustomGoogleEmail('');
    setCustomGoogleName('');
    setError('');
    setLoading(false);
  };

  return (
    <div id="customer-login-modal" className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl relative border border-zinc-150 flex flex-col"
      >
        {/* Header */}
        <div className="bg-zinc-950 text-white p-5 flex justify-between items-center border-b border-amber-500/20" dir="rtl">
          <h3 className="font-extrabold text-sm flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-amber-400" />
            <span>تسجيل دخول العميل الآمن</span>
          </h3>
          <button
            onClick={() => {
              resetForm();
              onClose();
            }}
            className="p-1.5 rounded-full hover:bg-zinc-800 text-zinc-400 hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 md:p-8 text-right" dir="rtl">
          <div className="space-y-6">
            {/* Google Header */}
            <div className="text-center space-y-2 pb-2">
              <div className="flex justify-center">
                <svg className="w-9 h-9 animate-bounce" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
                  <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                  <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22c-.22-.63-.35-1.3-.35-1.99z" fill="#FBBC05" />
                  <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" fill="#EA4335" />
                </svg>
              </div>
              <h4 className="font-extrabold text-base text-zinc-900">تسجيل الدخول الآمن بـ Google</h4>
              <p className="text-xs text-zinc-500">اختر حساب Google للمتابعة والدخول فوراً</p>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-100 p-3.5 rounded-xl text-xs text-red-600 font-medium flex items-center gap-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0 text-red-600" />
                <span>{error}</span>
              </div>
            )}

            {/* Account Selector Cards */}
            <div className="space-y-3">
              {/* Custom Google Account Section */}
              <div className="p-4 rounded-2xl border border-zinc-200 space-y-3 bg-zinc-50/55">
                <div className="text-xs font-black text-zinc-800">أدخل معلومات حساب Google للمتابعة</div>
                
                <div className="space-y-3.5">
                  <div>
                    <label className="text-[10px] font-bold text-zinc-500 block mb-1">الاسم الكامل لحساب Google *</label>
                    <input
                      type="text"
                      placeholder="مثال: صالح محمد اليافعي"
                      value={customGoogleName}
                      onChange={(e) => setCustomGoogleName(e.target.value)}
                      className="w-full text-xs px-3 py-2.5 rounded-xl border border-zinc-200 bg-white focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-zinc-500 block mb-1">بريد Gmail الإلكتروني *</label>
                    <input
                      type="email"
                      placeholder="username@gmail.com"
                      value={customGoogleEmail}
                      onChange={(e) => setCustomGoogleEmail(e.target.value)}
                      className="w-full text-xs px-3 py-2.5 rounded-xl border border-zinc-200 bg-white focus:border-amber-500 focus:outline-none font-mono text-left"
                    />
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      if (!customGoogleName.trim() || !customGoogleEmail.trim()) {
                        setError('يرجى كتابة الاسم والبريد الإلكتروني للمتابعة.');
                        return;
                      }
                      if (!customGoogleEmail.includes('@')) {
                        setError('يرجى إدخال بريد إلكتروني صحيح.');
                        return;
                      }
                      handleSelectGoogleAccount(customGoogleEmail, customGoogleName);
                    }}
                    disabled={loading}
                    className="w-full bg-zinc-950 hover:bg-amber-500 hover:text-zinc-950 text-white font-black py-2.5 rounded-xl text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-xs disabled:opacity-50"
                  >
                    {loading ? (
                      <span>جاري الدخول بحساب Google...</span>
                    ) : (
                      <>
                        <span>متابعة تسجيل الدخول بـ Google</span>
                        <ArrowRight className="w-4 h-4 rotate-180" />
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

