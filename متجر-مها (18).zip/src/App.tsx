import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, ShoppingBag, Heart, MessageSquare, Bell, ArrowRight, Sparkles, Filter, ChevronRight, ShieldAlert, Check, Trash2, ExternalLink, CheckCheck } from 'lucide-react';
import { Product, Order, User, Category, Coupon, Message, Notification, UserRole, OrderStatus, Review, Employee, ShippingMethod, PaymentGateway, Banner, Inquiry } from './types';
import { getInitialState, saveState, MarketplaceState, sanitizeStoreSettings } from './lib/state';
import { INITIAL_CATEGORIES } from './data/mockData';
import { subscribeToUserDoc, logoutUser, onAuthStateChanged } from './lib/authService';
import { fetchProducts, addProduct, updateProduct, deleteProduct } from './lib/productService';
import { 
  requestNotificationPermission, 
  subscribeToNotifications, 
  notifyNewOrder, 
  notifyOrderStatusUpdate, 
  markNotificationAsRead, 
  markAllNotificationsAsRead, 
  deleteNotification, 
  AppNotification 
} from './lib/notificationService';

// Import our custom modular components
import RoleSelector from './components/RoleSelector';
import ProductCard from './components/ProductCard';
import ProductDetailsModal from './components/ProductDetailsModal';
import ChatComponent from './components/ChatComponent';
import CartModal from './components/CartModal';
import CheckoutModal from './components/CheckoutModal';
import CustomerPanel from './components/CustomerPanel';
import AdminPanel from './components/AdminPanel';
import CustomerLoginModal from './components/CustomerLoginModal';

function AccessDenied({ onReturn }: { onReturn: () => void }) {
  return (
    <div className="flex-grow flex flex-col items-center justify-center p-8 bg-zinc-50 min-h-[70vh] text-center w-full" dir="rtl">
      <div className="bg-white p-8 rounded-3xl border border-zinc-150 max-w-md shadow-xl space-y-6">
        <div className="w-16 h-16 rounded-full bg-red-500/10 flex items-center justify-center text-red-600 text-3xl mx-auto">
          ⚠️
        </div>
        <div className="space-y-2">
          <h2 className="text-xl font-black text-zinc-900">عذراً، ليس لديك صلاحية وصول!</h2>
          <p className="text-xs text-zinc-500 leading-relaxed">
            هذه المنطقة مخصصة فقط لموظفي أو مدراء متجر مها المعتمدين. تم حظر محاولة الوصول غير المصرح بها لحماية بيانات العملاء والطلبات.
          </p>
        </div>
        <button
          onClick={onReturn}
          className="w-full bg-zinc-950 hover:bg-amber-500 hover:text-zinc-950 text-white font-black py-3 rounded-xl text-xs transition-colors cursor-pointer"
        >
          العودة للرئيسية والتبضع 🛍️
        </button>
      </div>
    </div>
  );
}

export default function App() {
  // Load initial persistent state
  const [state, setState] = useState<MarketplaceState>(() => getInitialState());
  const [categories, setCategories] = useState<Category[]>(() => {
    const saved = localStorage.getItem('maha_categories_2026');
    return saved ? JSON.parse(saved) : INITIAL_CATEGORIES;
  });

  useEffect(() => {
    localStorage.setItem('maha_categories_2026', JSON.stringify(categories));
  }, [categories]);

  // Active Role and Navigation Tab for Buyers
  const [currentRole, setCurrentRole] = useState<UserRole>('customer');
  const [buyerTab, setBuyerTab] = useState<'shop' | 'tracker' | 'privacy' | 'terms' | 'contact'>('shop');

  // Customer Account States
  const [currentCustomer, setCurrentCustomer] = useState<User | null>(null);

  // Synchronize Firebase Auth with React State & Firestore User Documents in Real-Time
  useEffect(() => {
    let unsubscribeDoc: (() => void) | null = null;
    
    const unsubscribeAuth = onAuthStateChanged(null, (fbUser) => {
      // Clean up previous Firestore doc listener if it exists
      if (unsubscribeDoc) {
        unsubscribeDoc();
        unsubscribeDoc = null;
      }
      
      if (fbUser) {
        // Subscribe to real-time updates for their Firestore user doc
        unsubscribeDoc = subscribeToUserDoc(fbUser.uid, (firestoreUser) => {
          if (firestoreUser) {
            setCurrentCustomer(firestoreUser);
            // Redirect user automatically to their correct role panel on login/update
            if (firestoreUser.role === 'admin') {
              setCurrentRole('admin');
            } else if (firestoreUser.role === 'employee') {
              setCurrentRole('employee');
            } else {
              setCurrentRole('customer');
            }
          } else {
            // Document doesn't exist yet, but they have a user record
            const determinedRole: UserRole = fbUser.email?.toLowerCase() === 'galeelahmeda@gmail.com' ? 'admin' : 'customer';
            const newCust: User = {
              id: fbUser.uid,
              name: fbUser.displayName || fbUser.email?.split('@')[0] || 'عميل جديد',
              email: fbUser.email || '',
              role: determinedRole,
              phone: '',
              isVerified: true,
              joinedDate: new Date().toLocaleDateString('ar-YE')
            };
            setCurrentCustomer(newCust);
            setCurrentRole(determinedRole);
          }
        });
      } else {
        setCurrentCustomer(null);
        setCurrentRole('customer');
      }
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeDoc) {
        unsubscribeDoc();
      }
    };
  }, []);
  const [isCustomerLoginOpen, setIsCustomerLoginOpen] = useState(false);
  const [footerFormSubmitted, setFooterFormSubmitted] = useState(false);

  // Banners & Offers State
  const [banners, setBanners] = useState<Banner[]>(() => {
    const saved = localStorage.getItem('maha_banners');
    return saved ? JSON.parse(saved) : [
      { id: 'b_1', title: 'تشكيلة الصيف الفاخرة', subtitle: 'خصم 15% على جميع الفساتين بمناسبة العيد', imageUrl: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=600', isActive: true, couponCode: 'EID15' },
      { id: 'b_2', title: 'عطور النخبة الفاخرة', subtitle: 'ثبات يدوم طويلاً وروائح شرقية ساحرة', imageUrl: 'https://images.unsplash.com/photo-1541643600914-78b084683601?w=600', isActive: true, couponCode: 'MAHA10' }
    ];
  });

  const handleUpdateBanners = (updatedBanners: Banner[]) => {
    setBanners(updatedBanners);
    localStorage.setItem('maha_banners', JSON.stringify(updatedBanners));
  };

  // Contact Inquiries State
  const [inquiries, setInquiries] = useState<Inquiry[]>(() => {
    const saved = localStorage.getItem('maha_inquiries');
    return saved ? JSON.parse(saved) : [
      { id: 'inq_1', name: 'أروى الصنعاني', contact: 'arwa@gmail.com', message: 'مرحباً، هل يتوفر فستان العيد باللون العنابي؟ وبكم الشحن لتعز؟', createdAt: new Date(Date.now() - 3600000).toISOString(), isRead: false },
      { id: 'inq_2', name: 'سليم باعبيد', contact: '777123456', message: 'السلام عليكم، أود الاستفسار عن كود الخصم الجديد، يظهر لي أنه منتهي.', createdAt: new Date(Date.now() - 7200000).toISOString(), isRead: true }
    ];
  });

  const handleAddInquiry = (name: string, contact: string, message: string) => {
    const newInq: Inquiry = {
      id: `inq_${Date.now()}`,
      name,
      contact,
      message,
      createdAt: new Date().toISOString(),
      isRead: false
    };
    const updated = [newInq, ...inquiries];
    setInquiries(updated);
    localStorage.setItem('maha_inquiries', JSON.stringify(updated));
  };

  const handleMarkInquiryRead = (id: string) => {
    const updated = inquiries.map(inq => inq.id === id ? { ...inq, isRead: true } : inq);
    setInquiries(updated);
    localStorage.setItem('maha_inquiries', JSON.stringify(updated));
  };

  const handleDeleteInquiry = (id: string) => {
    const updated = inquiries.filter(inq => inq.id !== id);
    setInquiries(updated);
    localStorage.setItem('maha_inquiries', JSON.stringify(updated));
  };

  // Customer Wishlist and Cart
  const [wishlist, setWishlist] = useState<string[]>(() => {
    const saved = localStorage.getItem('maha_wishlist');
    return saved ? JSON.parse(saved) : [];
  });
  const [cart, setCart] = useState<{ product: Product; quantity: number }[]>(() => {
    const saved = localStorage.getItem('maha_cart');
    return saved ? JSON.parse(saved) : [];
  });
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);

  // Search, Categories, and Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [activeFilter, setActiveFilter] = useState<'all' | 'bestSeller' | 'offers'>('all');
  const [activeBannerIndex, setActiveBannerIndex] = useState(0);

  useEffect(() => {
    setActiveBannerIndex(0);
  }, [selectedCategory]);

  // Interactive UI overlays toggles
  const [activeProduct, setActiveProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isWhatsAppOpen, setIsWhatsAppOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);

  // Real-time Firebase Notifications State
  const [firebaseNotifications, setFirebaseNotifications] = useState<AppNotification[]>([]);

  // Request browser notification permission on mount
  useEffect(() => {
    requestNotificationPermission();
  }, []);

  // Listen in real-time to Firebase Firestore notifications
  useEffect(() => {
    if (!currentCustomer) {
      setFirebaseNotifications([]);
      return;
    }
    const subRole = currentRole === 'admin' || currentRole === 'employee' ? currentRole : 'customer';
    const unsubscribe = subscribeToNotifications(
      currentCustomer.id,
      subRole,
      (notifs) => {
        setFirebaseNotifications(notifs);
      }
    );
    return () => {
      unsubscribe();
    };
  }, [currentCustomer, currentRole]);

  // Active Chat specifics
  const [chatVendorId, setChatVendorId] = useState('vendor_maha');
  const [chatProductId, setChatProductId] = useState<string | undefined>(undefined);
  const [chatProductTitle, setChatProductTitle] = useState<string | undefined>(undefined);

  // Synchronize overall state to localStorage when updated
  useEffect(() => {
    saveState(state);
  }, [state]);

  // Fetch products from Firestore on mount
  useEffect(() => {
    let active = true;
    const loadDbProducts = async () => {
      try {
        const dbProducts = await fetchProducts();
        if (active) {
          setState(prev => ({
            ...prev,
            products: dbProducts
          }));
        }
      } catch (error) {
        console.error("Error loading products on mount:", error);
      }
    };
    loadDbProducts();
    return () => {
      active = false;
    };
  }, []);

  // CENTRALIZED SEO, SCHEMA.ORG, GOOGLE SCRIPTS & DEEP LINKING CONTROLLER
  useEffect(() => {
    // 1. Google Verification meta tag (GSC)
    const gscCode = state.storeSettings?.gscVerificationCode;
    const gscMetaId = 'gsc-verification-meta';
    let gscMeta = document.getElementById(gscMetaId) as HTMLMetaElement;
    if (gscCode) {
      if (!gscMeta) {
        gscMeta = document.createElement('meta');
        gscMeta.id = gscMetaId;
        gscMeta.name = 'google-site-verification';
        document.head.appendChild(gscMeta);
      }
      gscMeta.content = gscCode;
    } else if (gscMeta) {
      gscMeta.remove();
    }

    // 2. Google Analytics (GA4) script integration
    const ga4Id = state.storeSettings?.ga4MeasurementId;
    const gaIdAttr = 'ga4-tracking-script';
    let gaScript = document.getElementById(gaIdAttr) as HTMLScriptElement | null;
    if (ga4Id) {
      if (!gaScript) {
        // Create the gtag main script tag
        const newGaScript = document.createElement('script');
        newGaScript.id = gaIdAttr;
        newGaScript.async = true;
        newGaScript.src = `https://www.googletagmanager.com/gtag/js?id=${ga4Id}`;
        document.head.appendChild(newGaScript);
        gaScript = newGaScript;

        // Create the configuration code
        const gaConfigScript = document.createElement('script');
        gaConfigScript.id = 'ga4-config-script';
        gaConfigScript.innerHTML = `
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
          gtag('config', '${ga4Id}');
        `;
        document.head.appendChild(gaConfigScript);
      }
    }

    // 3. Google Tag Manager (GTM) script integration
    const gtmId = state.storeSettings?.gtmId;
    const gtmIdAttr = 'gtm-tracking-script';
    let gtmScript = document.getElementById(gtmIdAttr);
    if (gtmId) {
      if (!gtmScript) {
        gtmScript = document.createElement('script');
        gtmScript.id = gtmIdAttr;
        gtmScript.innerHTML = `
          (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
          new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
          j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
          'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
          })(window,document,'script','dataLayer','${gtmId}');
        `;
        document.head.appendChild(gtmScript);
      }
    }

    // 4. Determine SEO Metadata based on navigation context
    let title = 'متجر مها للأناقة والموضة - فخر الصناعة اليمنية';
    let description = state.storeSettings?.description || 'الوجهة الأولى لشراء أرقى الملابس والفساتين الفاخرة والعطور الشرقية في اليمن.';
    let keywords = 'ملابس, فساتين فاخرة, عطور شرقية, إكسسوارات يدوية, الكريمي, محفظة جيب, صنعاء, اليمن';
    let ogImage = state.storeSettings?.logo && state.storeSettings.logo.startsWith('http') 
      ? state.storeSettings.logo 
      : 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=600';
    let canonicalUrl = window.location.origin + window.location.pathname;

    if (activeProduct) {
      title = `${activeProduct.title} | متجر مها للأناقة`;
      description = activeProduct.description;
      keywords = `${activeProduct.title}, ${activeProduct.category}, متجر مها, اليمن`;
      if (activeProduct.images?.[0]) {
        ogImage = activeProduct.images[0];
      }
      canonicalUrl = `${window.location.origin}${window.location.pathname}#/product/${activeProduct.id}`;
    } else if (selectedCategory !== 'all') {
      const catObj = categories.find(c => c.slug === selectedCategory);
      title = `أرقى أزياء فئة ${catObj?.name || selectedCategory} | متجر مها`;
      description = `تصفح أرقى ${catObj?.name || selectedCategory} في متجر مها للأناقة والموضة في اليمن.`;
      keywords = `${catObj?.name || selectedCategory}, فساتين يمنية, متجر مها`;
      canonicalUrl = `${window.location.origin}${window.location.pathname}#/category/${selectedCategory}`;
    } else if (buyerTab === 'privacy') {
      title = 'سياسة الخصوصية وسرية البيانات | متجر مها';
      description = 'نحن ملتزمون بحماية خصوصيتك وبياناتك الشخصية بأعلى درجات الأمان الموثوقة.';
      canonicalUrl = `${window.location.origin}${window.location.pathname}#/privacy`;
    } else if (buyerTab === 'terms') {
      title = 'الشروط والأحكام وسياسات البيع | متجر مها';
      description = 'بنود الخدمة، وسياسات الدفع، والشحن والاستبدال والاسترجاع المعتمدة لدينا.';
      canonicalUrl = `${window.location.origin}${window.location.pathname}#/terms`;
    } else if (buyerTab === 'contact') {
      title = 'اتصل بنا وخدمة العملاء | متجر مها';
      description = 'نحن هنا لخدمتك! تواصل معنا مباشرة عبر الواتساب أو الهاتف أو نموذج المراسلة الفورية.';
      canonicalUrl = `${window.location.origin}${window.location.pathname}#/contact`;
    } else if (buyerTab === 'tracker') {
      title = 'تتبع طلبيتك وسلة رغباتك | متجر مها';
      description = 'أدخل رقم هاتفك لتتبع حالة شحن وتوصيل طلبياتك ومعاينة تاريخ مشترياتك بالكامل.';
      canonicalUrl = `${window.location.origin}${window.location.pathname}#/tracker`;
    }

    // Update document head details
    document.title = title;

    // Meta Description
    let metaDesc = document.querySelector('meta[name="description"]') as HTMLMetaElement;
    if (!metaDesc) {
      metaDesc = document.createElement('meta');
      metaDesc.name = 'description';
      document.head.appendChild(metaDesc);
    }
    metaDesc.content = description;

    // Meta Keywords
    let metaKeys = document.querySelector('meta[name="keywords"]') as HTMLMetaElement;
    if (!metaKeys) {
      metaKeys = document.createElement('meta');
      metaKeys.name = 'keywords';
      document.head.appendChild(metaKeys);
    }
    metaKeys.content = keywords;

    // Canonical link tag
    let linkCanonical = document.querySelector('link[rel="canonical"]') as HTMLLinkElement;
    if (!linkCanonical) {
      linkCanonical = document.createElement('link');
      linkCanonical.rel = 'canonical';
      document.head.appendChild(linkCanonical);
    }
    linkCanonical.href = canonicalUrl;

    // Open Graph Tags
    const updateOgTag = (property: string, content: string) => {
      let tag = document.querySelector(`meta[property="${property}"]`) as HTMLMetaElement;
      if (!tag) {
        tag = document.createElement('meta');
        tag.setAttribute('property', property);
        document.head.appendChild(tag);
      }
      tag.content = content;
    };
    updateOgTag('og:title', title);
    updateOgTag('og:description', description);
    updateOgTag('og:image', ogImage);
    updateOgTag('og:url', canonicalUrl);
    updateOgTag('og:type', activeProduct ? 'product' : 'website');

    // Twitter Cards Tags
    const updateTwitterTag = (name: string, content: string) => {
      let tag = document.querySelector(`meta[name="${name}"]`) as HTMLMetaElement;
      if (!tag) {
        tag = document.createElement('meta');
        tag.name = name;
        document.head.appendChild(tag);
      }
      tag.content = content;
    };
    updateTwitterTag('twitter:card', 'summary_large_image');
    updateTwitterTag('twitter:title', title);
    updateTwitterTag('twitter:description', description);
    updateTwitterTag('twitter:image', ogImage);

    // 5. Schema.org (JSON-LD) structured rich snippets
    const schemaId = 'schema-jsonld-tag';
    let schemaScript = document.getElementById(schemaId) as HTMLScriptElement;
    if (!schemaScript) {
      schemaScript = document.createElement('script');
      schemaScript.id = schemaId;
      schemaScript.type = 'application/ld+json';
      document.head.appendChild(schemaScript);
    }

    if (activeProduct) {
      const productSchema = {
        "@context": "https://schema.org",
        "@type": "Product",
        "name": activeProduct.title,
        "description": activeProduct.description,
        "image": activeProduct.images?.[0] || ogImage,
        "sku": activeProduct.id,
        "offers": {
          "@type": "Offer",
          "priceCurrency": "YER",
          "price": activeProduct.price,
          "availability": "https://schema.org/InStock",
          "url": canonicalUrl
        },
        "aggregateRating": activeProduct.reviewsCount ? {
          "@type": "AggregateRating",
          "ratingValue": activeProduct.rating || 5,
          "reviewCount": activeProduct.reviewsCount
        } : undefined
      };
      schemaScript.textContent = JSON.stringify(productSchema, null, 2);
    } else {
      const storeSchema = {
        "@context": "https://schema.org",
        "@type": "OnlineStore",
        "name": state.storeSettings?.name,
        "description": state.storeSettings?.description,
        "url": window.location.origin,
        "telephone": state.storeSettings?.phone,
        "email": state.storeSettings?.email,
        "address": {
          "@type": "PostalAddress",
          "streetAddress": state.storeSettings?.address,
          "addressCountry": "YE"
        },
        "sameAs": [
          state.storeSettings?.socialLinks?.facebook,
          state.storeSettings?.socialLinks?.instagram,
          state.storeSettings?.socialLinks?.twitter
        ].filter(Boolean)
      };
      schemaScript.textContent = JSON.stringify(storeSchema, null, 2);
    }
  }, [buyerTab, selectedCategory, activeProduct, state.storeSettings]);

  // SEO FRIENDLY DEEP LINKING ROUTER EFFECT
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash;
      if (!hash) return;

      if (hash.startsWith('#/product/')) {
        const prodId = hash.replace('#/product/', '');
        const found = state.products.find(p => p.id === prodId);
        if (found) {
          setActiveProduct(found);
        }
      } else if (hash.startsWith('#/category/')) {
        const catSlug = hash.replace('#/category/', '');
        setSelectedCategory(catSlug);
        setActiveProduct(null);
        setBuyerTab('shop');
      } else if (hash === '#/privacy') {
        setBuyerTab('privacy');
        setActiveProduct(null);
      } else if (hash === '#/terms') {
        setBuyerTab('terms');
        setActiveProduct(null);
      } else if (hash === '#/contact') {
        setBuyerTab('contact');
        setActiveProduct(null);
      } else if (hash === '#/tracker') {
        setBuyerTab('tracker');
        setActiveProduct(null);
      } else if (hash === '#/shop') {
        setBuyerTab('shop');
        setActiveProduct(null);
      }
    };

    // Run on initial mount
    handleHashChange();

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, [state.products]);

  // Synchronize React Navigation states back to URL hash for full SEO deep-linking
  useEffect(() => {
    if (activeProduct) {
      window.location.hash = `#/product/${activeProduct.id}`;
    } else if (selectedCategory !== 'all') {
      window.location.hash = `#/category/${selectedCategory}`;
    } else if (buyerTab !== 'shop') {
      window.location.hash = `#/${buyerTab}`;
    } else {
      // Clear hash if at home shop
      if (window.location.hash && !window.location.hash.startsWith('#/product/')) {
        window.history.pushState('', document.title, window.location.pathname + window.location.search);
      }
    }
  }, [buyerTab, selectedCategory, activeProduct]);

  // Inject custom CSS & brand colors
  useEffect(() => {
    const customCssId = 'maha-custom-css';
    let styleElement = document.getElementById(customCssId);
    if (!styleElement) {
      styleElement = document.createElement('style');
      styleElement.id = customCssId;
      document.head.appendChild(styleElement);
    }
    
    const themeColor = state.storeSettings?.themeColor || '#f59e0b';
    const bgCreamy = '#fdfbf7'; // Creamy beige background
    
    // Create classes that use the theme color dynamically
    const brandStyles = `
      :root {
        --brand-color: ${themeColor};
        --brand-color-10: ${themeColor}10;
        --brand-color-20: ${themeColor}20;
        --brand-color-30: ${themeColor}30;
        --brand-color-light: ${themeColor}15;
      }
      
      /* Make store background creamy beige by default */
      #maha-applet-root {
        background-color: ${bgCreamy} !important;
      }
      
      /* Target buttons styled with bg-amber-500 or active states to follow the brand theme color */
      .bg-amber-500, .bg-amber-600 {
        background-color: ${themeColor} !important;
        color: #ffffff !important;
      }
      .bg-amber-500:hover, .bg-amber-600:hover {
        filter: brightness(0.9);
      }
      .text-amber-500, .text-amber-600, .text-amber-700 {
        color: ${themeColor} !important;
      }
      .border-amber-500, .border-amber-600 {
        border-color: ${themeColor} !important;
      }
      
      /* Focus states and dynamic highlights */
      .focus\\:ring-amber-500:focus {
        --tw-ring-color: ${themeColor} !important;
      }
      
      /* Floating navigation and titles */
      .text-amber-400 {
        color: ${themeColor} !important;
      }
      
      /* Custom badge and stamp */
      .border-amber-500\\/30 {
        border-color: ${themeColor}40 !important;
      }
      .text-amber-600\\/70 {
        color: ${themeColor}b0 !important;
      }
      
      /* Custom CSS written by the admin */
      ${state.storeSettings?.customCss || ''}
    `;
    
    styleElement.innerHTML = brandStyles;
  }, [state.storeSettings?.customCss, state.storeSettings?.themeColor]);

  // Synchronize current customer
  useEffect(() => {
    if (currentCustomer) {
      localStorage.setItem('maha_current_customer', JSON.stringify(currentCustomer));
    } else {
      localStorage.removeItem('maha_current_customer');
    }
  }, [currentCustomer]);

  // Synchronize buyer cart & wishlist
  useEffect(() => {
    localStorage.setItem('maha_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  useEffect(() => {
    localStorage.setItem('maha_cart', JSON.stringify(cart));
  }, [cart]);

  // Helper: Create a real-time notification
  const addNotification = (title: string, message: string, type: 'order' | 'offer' | 'system' | 'chat') => {
    const newNotif: Notification = {
      id: `not_${Date.now()}`,
      title,
      message,
      type,
      createdAt: new Date().toISOString(),
      isRead: false
    };
    setState((prev) => ({
      ...prev,
      notifications: [newNotif, ...prev.notifications]
    }));
  };

  // --- CART FUNCTIONS ---
  const handleAddToCart = (product: Product, quantity = 1, selectedOptions?: { [key: string]: string }, userNote?: string) => {
    setCart((prevCart) => {
      const existing = prevCart.find((item) => 
        item.product.id === product.id && 
        JSON.stringify(item.selectedOptions) === JSON.stringify(selectedOptions) && 
        item.userNote === userNote
      );
      if (existing) {
        return prevCart.map((item) =>
          item.product.id === product.id && 
          JSON.stringify(item.selectedOptions) === JSON.stringify(selectedOptions) && 
          item.userNote === userNote
            ? { ...item, quantity: Math.min(product.stock, item.quantity + quantity) }
            : item
        );
      }
      return [...prevCart, { product, quantity, selectedOptions, userNote }];
    });
    addNotification('أُضيف إلى السلة 🛍', `تم إضافة ${product.title} بنجاح إلى سلتك.`, 'system');
  };

  const handleUpdateQuantity = (productId: string, quantity: number, selectedOptions?: { [key: string]: string }, userNote?: string) => {
    setCart((prev) =>
      prev.map((item) =>
        item.product.id === productId &&
        JSON.stringify(item.selectedOptions) === JSON.stringify(selectedOptions) &&
        item.userNote === userNote
          ? { ...item, quantity }
          : item
      )
    );
  };

  const handleRemoveFromCart = (productId: string, selectedOptions?: { [key: string]: string }, userNote?: string) => {
    setCart((prev) =>
      prev.filter(
        (item) =>
          !(
            item.product.id === productId &&
            JSON.stringify(item.selectedOptions) === JSON.stringify(selectedOptions) &&
            item.userNote === userNote
          )
      )
    );
  };

  // --- WISHLIST FUNCTIONS ---
  const handleToggleWishlist = (productId: string) => {
    setWishlist((prev) => {
      const isFav = prev.includes(productId);
      if (isFav) {
        return prev.filter((id) => id !== productId);
      } else {
        const prod = state.products.find((p) => p.id === productId);
        if (prod) {
          addNotification('المفضلة ⭐️', `تم إضافة ${prod.title} إلى مفضلتك.`, 'system');
        }
        return [...prev, productId];
      }
    });
  };

  // --- COUPON FUNCTIONS ---
  const handleApplyCoupon = (code: string): boolean => {
    const coupon = state.coupons.find((c) => c.code === code && c.isActive);
    const subtotal = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);

    if (coupon && subtotal >= (coupon.minSpend || 0)) {
      setAppliedCoupon(coupon);
      return true;
    }
    return false;
  };

  const handleRemoveCoupon = () => {
    setAppliedCoupon(null);
  };

  // --- CHECKOUT & ORDER PLACEMENT ---
  const handlePlaceOrder = (orderData: {
    name: string;
    phone: string;
    address: string;
    paymentMethod: 'kuraimi' | 'jeeb' | 'bank_transfer' | 'cod';
    paymentDetails: string;
  }) => {
    const subtotal = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);

    let discountAmount = 0;
    if (appliedCoupon && subtotal >= (appliedCoupon.minSpend || 0)) {
      if (appliedCoupon.discountType === 'percentage') {
        discountAmount = (subtotal * appliedCoupon.value) / 100;
      } else {
        discountAmount = appliedCoupon.value;
      }
    }

    const finalPrice = Math.max(0, subtotal - discountAmount);
    const orderId = `ord_${Math.floor(1000 + Math.random() * 9000)}`;

    // Build order items
    const orderItems = cart.map((item) => ({
      productId: item.product.id,
      productTitle: item.product.title,
      price: item.product.price,
      quantity: item.quantity,
      vendorId: item.product.vendorId,
      image: item.product.images?.[0] || 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=600',
      selectedOptions: item.selectedOptions,
      userNote: item.userNote
    }));

    // Calculate admin commission based on vendors' unique rates
    const commissionEarned = orderItems.reduce((acc, item) => {
      const vendorObj = state.vendors.find((v) => v.id === item.vendorId);
      const rate = vendorObj?.commissionRate || 10;
      const itemTotal = item.price * item.quantity;
      return acc + (itemTotal * rate) / 100;
    }, 0);

    const newOrder: Order = {
      id: orderId,
      customerId: currentCustomer?.id || 'customer_guest',
      customerName: orderData.name,
      customerPhone: orderData.phone,
      customerAddress: orderData.address,
      items: orderItems,
      totalPrice: subtotal,
      discountAmount,
      finalPrice,
      paymentMethod: orderData.paymentMethod,
      paymentDetails: orderData.paymentDetails,
      status: 'pending',
      createdAt: new Date().toISOString(),
      commissionEarned
    };

    // Update state: Add order and deduct stock
    setState((prev) => {
      const updatedProducts = prev.products.map((prod) => {
        const orderItem = orderItems.find((item) => item.productId === prod.id);
        if (orderItem) {
          return {
            ...prod,
            stock: Math.max(0, prod.stock - orderItem.quantity),
            salesCount: prod.salesCount + orderItem.quantity
          };
        }
        return prod;
      });

      return {
        ...prev,
        orders: [newOrder, ...prev.orders],
        products: updatedProducts
      };
    });

    // Clear cart and coupons
    setCart([]);
    setAppliedCoupon(null);

    // Send real-time notifications to Firestore
    notifyNewOrder(orderId, orderData.name, finalPrice);
    notifyOrderStatusUpdate(orderId, currentCustomer?.id || 'customer_guest', orderData.name, 'pending');

    // Dynamic notification to buyers and sellers
    addNotification(
      'تم تسجيل طلبك بنجاح! 🎉',
      `تم استلام طلبك رقم ${orderId} بقيمة ${finalPrice.toLocaleString()} ر.ي وسيتم تجهيزه فوراً.`,
      'order'
    );
  };

  // --- VENDOR PRODUCT MANAGEMENT ---
  const handleAddProduct = async (newProductData: Omit<Product, 'id' | 'vendorId' | 'vendorName' | 'salesCount' | 'rating' | 'reviewsCount' | 'createdAt'>) => {
    const newProd: Product = {
      ...newProductData,
      id: `prod_${Date.now()}`,
      vendorId: 'vendor_maha', // demo vendor Role
      vendorName: 'بوتيك مها للأناقة',
      salesCount: 0,
      rating: 5.0,
      reviewsCount: 0,
      createdAt: new Date().toISOString()
    };

    try {
      // Add product to Firestore using setDoc/addProduct first
      await addProduct(newProd);

      // Re-fetch products from the database to ensure state accuracy
      const freshProducts = await fetchProducts();

      setState((prev) => ({
        ...prev,
        products: freshProducts
      }));

      addNotification(
        'تم إضافة سلعة جديدة 📦',
        `تم إضافة "${newProd.title}" بنجاح في تصنيف "${newProd.category}" وحفظها في قاعدة البيانات.`,
        'system'
      );
    } catch (error) {
      console.error('Error adding product to Firestore:', error);
      addNotification(
        'خطأ في إضافة السلعة ⚠️',
        `فشل حفظ المنتج "${newProd.title}" في قاعدة البيانات.`,
        'system'
      );
      throw error;
    }
  };

  const handleEditProduct = async (updatedProduct: Product) => {
    try {
      // Update in Firestore first
      await updateProduct(updatedProduct);

      // Re-fetch products from the database to ensure state accuracy
      const freshProducts = await fetchProducts();

      setState((prev) => ({
        ...prev,
        products: freshProducts
      }));

      addNotification(
        'تم تحديث السلعة ⚙️',
        `تم تحديث بيانات سلعتك "${updatedProduct.title}" بنجاح في قاعدة البيانات.`,
        'system'
      );
    } catch (error) {
      console.error('Error updating product in Firestore:', error);
      addNotification(
        'خطأ في تحديث السلعة ⚠️',
        `فشل تحديث المنتج "${updatedProduct.title}" في قاعدة البيانات.`,
        'system'
      );
      throw error;
    }
  };

  const handleDeleteProduct = async (productId: string) => {
    const prod = state.products.find((p) => p.id === productId);
    const title = prod ? prod.title : productId;
    try {
      // Delete from Firestore first
      await deleteProduct(productId);

      // Re-fetch products from the database to ensure state accuracy
      const freshProducts = await fetchProducts();

      setState((prev) => ({
        ...prev,
        products: freshProducts
      }));

      addNotification(
        'حذف سلعة 🗑',
        `تم إزالة السلعة "${title}" نهائياً من قاعدة البيانات.`,
        'system'
      );
    } catch (error) {
      console.error('Error deleting product from Firestore:', error);
      addNotification(
        'خطأ في حذف السلعة ⚠️',
        `فشل حذف المنتج من قاعدة البيانات.`,
        'system'
      );
      throw error;
    }
  };

  const handleUpdateOrderStatus = (orderId: string, status: OrderStatus, cancelReason?: string) => {
    setState((prev) => ({
      ...prev,
      orders: prev.orders.map((o) => (o.id === orderId ? { ...o, status } : o))
    }));

    // Find order to notify the specific customer in Firestore
    const targetOrder = state.orders.find((o) => o.id === orderId);
    if (targetOrder) {
      notifyOrderStatusUpdate(
        orderId, 
        targetOrder.customerId || 'customer_guest', 
        targetOrder.customerName, 
        status, 
        cancelReason
      );
    }

    addNotification(
      'تحديث حالة الشحن 🚚',
      `تم تغيير حالة الطلب ${orderId} إلى "${status === 'processing' ? 'قيد التجهيز' : status === 'shipped' ? 'تم الشحن' : status === 'delivered' ? 'تم التسليم' : 'ملغي'}".`,
      'order'
    );
  };

  // --- CHAT MESSAGING FUNCTIONS ---
  const handleSendMessage = (receiverId: string, content: string, productId?: string, productTitle?: string) => {
    const newMsg: Message = {
      id: `msg_${Date.now()}`,
      senderId: currentRole === 'customer' ? 'customer_guest' : chatVendorId,
      senderRole: currentRole,
      receiverId,
      content,
      timestamp: new Date().toISOString(),
      productId,
      productTitle
    };

    setState((prev) => ({
      ...prev,
      messages: [...prev.messages, newMsg]
    }));
  };

  const handleOpenDirectChat = (vendorId: string, productTitle?: string, productId?: string) => {
    setChatVendorId(vendorId);
    setChatProductId(productId);
    setChatProductTitle(productTitle);
    setIsChatOpen(true);
  };

  // --- ADMIN FUNCTIONS ---
  const handleVerifyVendor = (vendorId: string) => {
    setState((prev) => ({
      ...prev,
      vendors: prev.vendors.map((v) => (v.id === vendorId ? { ...v, isVerified: !v.isVerified } : v))
    }));

    const vendor = state.vendors.find((v) => v.id === vendorId);
    if (vendor) {
      addNotification(
        'تعديل حالة توثيق متجر 🛡',
        `تم تعديل حالة توثيق البائع "${vendor.shopName}" على المنصة.`,
        'system'
      );
    }
  };

  const handleUpdateVendorCommission = (vendorId: string, rate: number) => {
    setState((prev) => ({
      ...prev,
      vendors: prev.vendors.map((v) => (v.id === vendorId ? { ...v, commissionRate: rate } : v))
    }));

    const vendor = state.vendors.find((v) => v.id === vendorId);
    if (vendor) {
      addNotification(
        'تعديل نسبة عمولة ⚙️',
        `تم تعديل نسبة عمولة متجر "${vendor.shopName}" إلى ${rate}%.`,
        'system'
      );
    }
  };

  const handleAddCoupon = (newCoupon: Coupon) => {
    setState((prev) => ({
      ...prev,
      coupons: [newCoupon, ...prev.coupons]
    }));

    addNotification(
      'تفعيل كوبون خصم جديد 🏷',
      `تم إطلاق كود الخصم "${newCoupon.code}" بنسبة خصم ${newCoupon.value}%.`,
      'offer'
    );
  };

  const handleDeleteCoupon = (code: string) => {
    setState((prev) => ({
      ...prev,
      coupons: prev.coupons.filter((c) => c.code !== code)
    }));

    addNotification('إيقاف كوبون خصم 🗑', `تم إيقاف تفعيل كود الخصم "${code}" في المتجر.`, 'system');
  };

  const handleUpdateVendorProfile = (updatedVendor: User) => {
    setState((prev) => ({
      ...prev,
      vendors: prev.vendors.map((v) => (v.id === updatedVendor.id ? updatedVendor : v)),
      products: prev.products.map((p) =>
        p.vendorId === updatedVendor.id ? { ...p, vendorName: updatedVendor.shopName || p.vendorName } : p
      )
    }));
    addNotification(
      'تحديث إعدادات المتجر ⚙️',
      `تم تحديث بيانات وشعار وحسابات متجر "${updatedVendor.shopName}" بنجاح.`,
      'system'
    );
  };

  // --- EMPLOYEE & ADMIN ADDITIONAL HANDLERS ---
  const [activeEmployeeId, setActiveEmployeeId] = useState<string>('emp_1');

  const handleAddEmployee = (emp: Employee) => {
    setState((prev) => ({
      ...prev,
      employees: [emp, ...prev.employees]
    }));
    addNotification('إضافة موظف جديد 💼', `تم تسجيل الموظف "${emp.name}" ومنحه صلاحية "${emp.permission === 'products' ? 'المنتجات' : emp.permission === 'orders' ? 'الطلبات' : emp.permission === 'customers' ? 'خدمة العملاء' : 'التسويق'}".`, 'system');
  };

  const handleDeleteEmployee = (id: string) => {
    const emp = state.employees.find(e => e.id === id);
    setState((prev) => ({
      ...prev,
      employees: prev.employees.filter(e => e.id !== id)
    }));
    if (emp) {
      addNotification('سحب صلاحيات موظف 🗑', `تم سحب صلاحيات الموظف "${emp.name}" وإلغاء حسابه المهني.`, 'system');
    }
  };

  const handleUpdateShippingMethod = (id: string, updated: Partial<ShippingMethod>) => {
    setState((prev) => {
      const exists = prev.shippingMethods.some(sh => sh.id === id);
      if (exists) {
        return {
          ...prev,
          shippingMethods: prev.shippingMethods.map(sh => sh.id === id ? { ...sh, ...updated } : sh)
        };
      } else {
        const newShip: ShippingMethod = {
          id,
          name: updated.name || 'شركة شحن جديدة',
          cost: updated.cost || 2000,
          regions: updated.regions || ['جميع المحافظات'],
          isActive: updated.isActive !== undefined ? updated.isActive : true,
          deliveryTime: updated.deliveryTime || '2-3 أيام'
        };
        return {
          ...prev,
          shippingMethods: [...prev.shippingMethods, newShip]
        };
      }
    });
  };

  const handleUpdatePaymentGateway = (id: string, updated: Partial<PaymentGateway>) => {
    setState((prev) => ({
      ...prev,
      paymentGateways: prev.paymentGateways.map(pay => pay.id === id ? { ...pay, ...updated } : pay)
    }));
  };

  const handleAddPaymentGateway = (newGateway: PaymentGateway) => {
    setState((prev) => ({
      ...prev,
      paymentGateways: [...prev.paymentGateways, newGateway]
    }));
  };

  const handleDeletePaymentGateway = (id: string) => {
    setState((prev) => ({
      ...prev,
      paymentGateways: prev.paymentGateways.filter(pay => pay.id !== id)
    }));
  };

  const handleSendCartReminder = (id: string) => {
    const cartObj = state.abandonedCarts.find(c => c.id === id);
    if (cartObj) {
      addNotification(
        'إرسال تذكير سلة متروكة 💬',
        `تم إرسال تذكير مخصص وحافز حسم بقيمة 10% للعميل "${cartObj.customerName}" تلقائياً عبر الواتساب بنجاح.`,
        'offer'
      );
    }
  };

  // --- REVIEW FUNCTIONS ---
  const handleAddReview = (newReviewData: Omit<Review, 'id' | 'createdAt'>) => {
    const newRev: Review = {
      ...newReviewData,
      id: `rev_${Date.now()}`,
      createdAt: new Date().toLocaleDateString('ar-YE', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      })
    };

    setState((prev) => {
      // Recalculate rating and reviewsCount for that product
      const updatedProducts = prev.products.map((prod) => {
        if (prod.id === newReviewData.productId) {
          const prodReviews = [...prev.reviews.filter((r) => r.productId === prod.id), newRev];
          const avgRating = prodReviews.reduce((sum, r) => sum + r.rating, 0) / prodReviews.length;
          return {
            ...prod,
            rating: avgRating,
            reviewsCount: prodReviews.length
          };
        }
        return prod;
      });

      return {
        ...prev,
        reviews: [...prev.reviews, newRev],
        products: updatedProducts
      };
    });
  };

  // Clear unread alerts
  const handleClearNotifications = () => {
    setState((prev) => ({
      ...prev,
      notifications: prev.notifications.map((n) => ({ ...n, isRead: true }))
    }));
  };

  // --- SEARCH AND FILTERING ALGORITHMS ---
  const filteredProducts = state.products.filter((product) => {
    if (!product) return false;
    // Search query matching (in title, description, or vendor name)
    const matchesSearch =
      (product.title || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (product.description || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (product.vendorName || '').toLowerCase().includes(searchQuery.toLowerCase());

    // Category filter
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;

    // Special quick filters
    const matchesQuickFilter =
      activeFilter === 'all' ||
      (activeFilter === 'bestSeller' && product.isBestSeller) ||
      (activeFilter === 'offers' && product.isDailyOffer);

    return matchesSearch && matchesCategory && matchesQuickFilter;
  });

  const unreadNotificationsCount = firebaseNotifications.filter((n) => {
    if (currentRole === 'admin' || currentRole === 'employee') {
      return !n.readBy?.includes(currentCustomer?.id || '');
    } else {
      return !n.isRead;
    }
  }).length;

  return (
    <div id="maha-applet-root" className="min-h-screen bg-zinc-50 flex flex-col font-sans pb-12 w-full max-w-full overflow-x-hidden">
      {/* Top Role Selector & Banner */}
      <RoleSelector
        currentRole={currentRole}
        onChangeRole={(role) => {
          setCurrentRole(role);
          // Auto switch buyer tab back to shop when returning to customer view
          if (role === 'customer') {
            setBuyerTab('shop');
          }
        }}
        notificationsCount={unreadNotificationsCount}
        onOpenNotifications={() => {
          setIsNotificationsOpen(!isNotificationsOpen);
        }}
        employees={state.employees}
        activeEmployeeId={activeEmployeeId}
        onChangeEmployeeId={setActiveEmployeeId}
        userRole={currentCustomer ? currentCustomer.role : null}
        androidAppLink={state.storeSettings.androidAppLink}
        iphoneAppLink={state.storeSettings.iphoneAppLink}
      />

      {/* Slide-out Notifications Area */}
      {isNotificationsOpen && (
        <div id="notifications-overlay" className="bg-zinc-900 border-b border-zinc-800 text-white p-4 transition-all z-40 relative shadow-inner select-none" dir="rtl">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-4">
            <h4 className="font-extrabold text-xs text-amber-400 flex items-center gap-2">
              <Bell className="w-4.5 h-4.5" />
              <span>مركز الإشعارات والتنبيهات المباشرة ({firebaseNotifications.length})</span>
            </h4>
            <div className="flex items-center gap-3.5 self-stretch sm:self-auto justify-between sm:justify-start">
              {unreadNotificationsCount > 0 && currentCustomer && (
                <button
                  onClick={async () => {
                    const subRole = currentRole === 'admin' || currentRole === 'employee' ? currentRole : 'customer';
                    await markAllNotificationsAsRead(firebaseNotifications, currentCustomer.id, subRole);
                  }}
                  className="text-[10.5px] text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <CheckCheck className="w-3.5 h-3.5" />
                  <span>تحديد الكل كمقروء</span>
                </button>
              )}
              <button
                onClick={() => setIsNotificationsOpen(false)}
                className="text-[10.5px] text-zinc-400 hover:text-white underline cursor-pointer"
              >
                إخفاء الإشعارات
              </button>
            </div>
          </div>

          {firebaseNotifications.length === 0 ? (
            <div className="max-w-7xl mx-auto text-center py-8 bg-zinc-950/40 rounded-2xl border border-zinc-800 text-zinc-400 text-xs">
              <Bell className="w-6 h-6 mx-auto mb-2 text-zinc-600 animate-pulse" />
              <p>لا يوجد إشعارات حالياً بالمتجر ✨</p>
            </div>
          ) : (
            <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5 max-h-56 overflow-y-auto pr-1">
              {firebaseNotifications.map((notif) => {
                const isUnread = currentRole === 'admin' || currentRole === 'employee'
                  ? !notif.readBy?.includes(currentCustomer?.id || '')
                  : !notif.isRead;

                return (
                  <div
                    key={notif.id}
                    className={`p-3.5 rounded-xl border flex gap-3 items-start text-right transition-all duration-300 relative ${
                      isUnread
                        ? 'bg-zinc-950 border-amber-500/30 ring-1 ring-amber-500/10'
                        : 'bg-zinc-950/60 border-zinc-800 text-zinc-300'
                    }`}
                  >
                    {/* Unread Glow Indicator */}
                    {isUnread && (
                      <span className="absolute top-3.5 left-3 w-2 h-2 rounded-full bg-amber-400 animate-pulse shadow-sm shadow-amber-400"></span>
                    )}

                    <span className="text-sm bg-zinc-900 p-1.5 rounded-lg border border-zinc-800 block shrink-0">
                      {notif.type === 'order' && '📦'}
                      {notif.type === 'offer' && '🔥'}
                      {notif.type === 'system' && '⚙️'}
                      {notif.type === 'chat' && '💬'}
                    </span>
                    <div className="min-w-0 flex-grow text-right pr-1">
                      <h5 className="font-extrabold text-xs text-zinc-100 flex items-center gap-1.5">
                        <span>{notif.title}</span>
                      </h5>
                      <p className="text-[10.5px] text-zinc-400 mt-1 leading-relaxed">{notif.message}</p>
                      
                      {/* Subtitle / Timestamp */}
                      <div className="flex items-center gap-2 mt-2">
                        <span className="text-[9px] text-zinc-500 font-mono">
                          {new Date(notif.createdAt).toLocaleTimeString('ar-YE', {
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </span>
                        <span className="text-[9px] text-zinc-600">•</span>
                        <span className="text-[9px] text-zinc-500">
                          {new Date(notif.createdAt).toLocaleDateString('ar-YE', {
                            month: 'short',
                            day: 'numeric'
                          })}
                        </span>
                      </div>

                      {/* Interactive Controls */}
                      <div className="flex items-center gap-2.5 mt-3 border-t border-zinc-800/40 pt-2.5">
                        {/* 1. Mark as Read */}
                        {isUnread && currentCustomer && (
                          <button
                            onClick={async (e) => {
                              e.stopPropagation();
                              const subRole = currentRole === 'admin' || currentRole === 'employee' ? currentRole : 'customer';
                              await markNotificationAsRead(notif.id, currentCustomer.id, subRole);
                            }}
                            className="bg-zinc-900 hover:bg-zinc-800 text-amber-400 border border-zinc-800 text-[9px] font-bold py-1 px-2 rounded flex items-center gap-1 transition-all cursor-pointer"
                            title="تحديد كمقروء"
                          >
                            <Check className="w-3 h-3" />
                            <span>قرأت</span>
                          </button>
                        )}

                        {/* 2. Open Order Details */}
                        {notif.orderId && (
                          <button
                            onClick={async (e) => {
                              e.stopPropagation();
                              // Mark as read first
                              if (isUnread && currentCustomer) {
                                const subRole = currentRole === 'admin' || currentRole === 'employee' ? currentRole : 'customer';
                                await markNotificationAsRead(notif.id, currentCustomer.id, subRole);
                              }

                              // Dispatch event to switch tab and scroll to order
                              if (currentRole === 'admin' || currentRole === 'employee') {
                                const evt = new CustomEvent('open_order_deep_link', { detail: { orderId: notif.orderId } });
                                window.dispatchEvent(evt);
                              } else {
                                setBuyerTab('tracker');
                                setTimeout(() => {
                                  const evt = new CustomEvent('open_order_deep_link', { detail: { orderId: notif.orderId } });
                                  window.dispatchEvent(evt);
                                }, 300);
                              }
                            }}
                            className="bg-amber-500 hover:bg-amber-600 text-zinc-950 text-[9px] font-black py-1 px-2.5 rounded flex items-center gap-1 transition-all cursor-pointer"
                          >
                            <ExternalLink className="w-3 h-3" />
                            <span>عرض التفاصيل</span>
                          </button>
                        )}

                        {/* 3. Delete Notification */}
                        <button
                          onClick={async (e) => {
                            e.stopPropagation();
                            await deleteNotification(notif.id);
                          }}
                          className="bg-zinc-900 hover:bg-red-950 hover:text-red-400 text-zinc-500 border border-zinc-800 text-[9px] font-bold py-1 px-2 rounded flex items-center gap-1 transition-all cursor-pointer ml-auto"
                          title="حذف الإشعار"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>حذف</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ROLE SCREEN ROUTING */}

      {/* 1. CUSTOMER VIEW */}
      {currentRole === 'customer' && (
        <div id="customer-storefront-wrapper" className="flex-grow flex flex-col">
          {/* Storefront Secondary Header & Navigation Tabs */}
          <div className="bg-white border-b border-zinc-150 sticky top-14 z-40 shadow-xs py-3 px-4">
            <div className="max-w-7xl mx-auto flex justify-between items-center">
              {/* Secondary Navigation */}
              <div className="flex items-center gap-4">
                <button
                  id="tab-btn-shop"
                  onClick={() => setBuyerTab('shop')}
                  className={`text-xs font-bold transition-all py-1.5 px-3.5 rounded-xl cursor-pointer ${
                    buyerTab === 'shop'
                      ? 'bg-zinc-950 text-white'
                      : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-100'
                  }`}
                >
                  الرئيسية والمعرض
                </button>

                <button
                  id="tab-btn-tracker"
                  onClick={() => setBuyerTab('tracker')}
                  className={`text-xs font-bold transition-all py-1.5 px-3.5 rounded-xl cursor-pointer relative ${
                    buyerTab === 'tracker'
                      ? 'bg-zinc-950 text-white'
                      : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-100'
                  }`}
                >
                  طلبياتي السابقة وتتبع الشحن
                  {state.orders.length > 0 && (
                    <span className="absolute -top-1 -left-1 w-2 h-2 bg-amber-500 rounded-full"></span>
                  )}
                </button>
              </div>

              <div className="flex items-center gap-2.5">
                {/* Customer Login Button or Profile Indicator */}
                {currentCustomer ? (
                  <div className="flex items-center gap-2 bg-zinc-100 py-1.5 px-3 rounded-xl border border-zinc-200">
                    <span className="text-[10.5px] font-bold text-zinc-800">
                      أهلاً، <span className="text-amber-600">{currentCustomer.name}</span>
                    </span>
                    <button
                      onClick={async () => {
                        try {
                          await logoutUser();
                          addNotification('تسجيل خروج 🔒', 'تم تسجيل خروجك بنجاح. تصفحك الآن كزائر.', 'system');
                        } catch (err) {
                          console.error('Error logging out:', err);
                        }
                      }}
                      className="text-[9.5px] text-red-500 hover:text-red-700 font-bold underline cursor-pointer"
                    >
                      خروج
                    </button>
                  </div>
                ) : (
                  <button
                    id="customer-login-trigger"
                    onClick={() => setIsCustomerLoginOpen(true)}
                    className="bg-zinc-950 hover:bg-zinc-850 text-white font-bold py-2 px-3 rounded-xl text-xs flex items-center gap-1 cursor-pointer transition-all border border-zinc-800"
                  >
                    <span>دخول العميل 👤</span>
                  </button>
                )}

                {/* Shopping Cart Trigger */}
                <button
                  id="cart-trigger-btn"
                  onClick={() => setIsCartOpen(true)}
                  className="bg-amber-500 hover:bg-amber-600 text-zinc-950 font-black py-2 px-4.5 rounded-xl text-xs flex items-center gap-1.5 shadow-md shadow-amber-500/10 cursor-pointer transition-all"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>سلة التسوق</span>
                  <span className="bg-zinc-950 text-amber-400 font-bold font-mono text-[10px] px-1.5 py-0.5 rounded-full">
                    {cart.reduce((acc, item) => acc + item.quantity, 0)}
                  </span>
                </button>
              </div>
            </div>
          </div>

          {buyerTab === 'shop' ? (
            <div className="flex-grow flex flex-col">
              {/* Hero Showcase Area */}
              <div className="bg-zinc-950 text-white relative py-12 md:py-16 px-6 overflow-hidden border-b border-amber-500/10">
                <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-zinc-900 via-zinc-950 to-black"></div>
                <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl"></div>

                <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8 items-center relative z-10 text-right">
                  {/* Left (Hero Text) */}
                  <div className="space-y-4">
                    <span className="bg-amber-500/10 text-amber-400 text-[10px] font-bold px-3 py-1 rounded-full border border-amber-500/20 uppercase tracking-wide inline-flex items-center gap-1">
                      <Sparkles className="w-3 h-3 fill-amber-400" />
                      <span>المتجر الرسمي للأناقة والموضة</span>
                    </span>
                    <h2 className="text-2xl md:text-4xl font-extrabold leading-tight">
                      تسوق أرقى منتجات الموضة، العطور، والإكسسوارات الفاخرة
                    </h2>
                    <p className="text-zinc-400 text-xs md:text-sm leading-relaxed max-w-lg">
                      تسوق تشكيلة حصرية من الأرقى والأنقى في اليمن مع طرق دفع آمنة وسهلة: الكريمي، محفظة جيب، والتحويل البنكي أو الدفع عند الاستلام مع مندوبنا الموثوق لضمان تجربة تسوق فريدة وسريعة.
                    </p>
                    <div className="flex gap-3 pt-2 justify-start flex-wrap">
                      <button
                        onClick={() => {
                          setSelectedCategory('all');
                          setActiveFilter('offers');
                        }}
                        className="bg-amber-500 hover:bg-amber-600 text-zinc-950 font-black px-5 py-2.5 rounded-xl text-xs transition-all cursor-pointer shadow-md"
                      >
                        ⚡ استكشف عروض اليوم
                      </button>
                      <button
                        onClick={() => {
                          setSelectedCategory('all');
                          setActiveFilter('bestSeller');
                        }}
                        className="bg-white/10 hover:bg-white/20 text-white font-bold px-5 py-2.5 rounded-xl text-xs transition-all cursor-pointer"
                      >
                        🔥 الأكثر مبيعاً
                      </button>
                    </div>
                  </div>

                  {/* Right (Dynamic Active Banners Showcase) */}
                  <div className="hidden md:flex justify-end relative w-full max-w-[340px]">
                    {(() => {
                      const activeBanners = banners.filter(b => b.isActive);
                      const displayBanner = activeBanners[0] || {
                        title: 'تشكيلة الصيف الفاخرة',
                        subtitle: 'خصم 15% على جميع الفساتين بمناسبة العيد',
                        imageUrl: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=600',
                        couponCode: 'EID15'
                      };
                      return (
                        <div className="relative group w-full aspect-square rounded-3xl overflow-hidden border border-zinc-800 shadow-2xl transition-all duration-500">
                          <img
                            src={displayBanner.imageUrl}
                            alt={displayBanner.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/50 to-transparent p-5 flex flex-col justify-end text-right" dir="rtl">
                            <span className="text-amber-400 font-bold text-[9px] uppercase tracking-wider block mb-1">🔥 عرض نشط</span>
                            <h4 className="font-black text-white text-sm md:text-base leading-tight">{displayBanner.title}</h4>
                            <p className="text-zinc-300 text-[10.5px] mt-1 leading-snug">{displayBanner.subtitle}</p>
                            
                            {displayBanner.couponCode && (
                              <div className="bg-amber-500 text-zinc-950 font-bold px-2 py-1 rounded text-[10px] mt-2.5 self-start flex items-center gap-1 font-mono">
                                <span>كوبون:</span>
                                <span>{displayBanner.couponCode}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })()}
                  </div>
                </div>
              </div>

              {/* Flagship Boutique Identity Header Banner */}
              {(() => {
                const mainVendor = state.vendors[0]; // Maha Boutique
                if (!mainVendor) return null;
                const storeName = state.storeSettings?.name || mainVendor.shopName;
                const storeLogo = state.storeSettings?.logo || mainVendor.shopLogo || '👑';
                const storeDesc = state.storeSettings?.description || mainVendor.shopDescription;
                const storePhone = state.storeSettings?.phone || mainVendor.phone;
                const storeAddress = state.storeSettings?.address || 'صنعاء، اليمن';
                
                return (
                  <div id="store-visual-banner" className="bg-white border-b border-zinc-150 py-6 px-4" dir="rtl">
                    <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
                      <div className="flex flex-col md:flex-row items-center gap-5 text-center md:text-right">
                        <div className="w-16 h-16 md:w-20 md:h-20 rounded-full overflow-hidden border-2 border-amber-500/20 shadow-md flex-shrink-0 bg-zinc-950 flex items-center justify-center text-3xl font-black">
                          {storeLogo.startsWith('http') || storeLogo.startsWith('data:') ? (
                            <img
                              src={storeLogo}
                              alt={storeName}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <span className="text-white">{storeLogo}</span>
                          )}
                        </div>
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 justify-center md:justify-start">
                            <h3 className="font-extrabold text-lg md:text-xl text-zinc-900">{storeName}</h3>
                            <span className="text-[10px] bg-amber-500/10 text-amber-700 font-bold px-2 py-0.5 rounded-full border border-amber-500/20">
                              بوتيك موثق 🛡️
                            </span>
                          </div>
                          <p className="text-zinc-600 text-xs md:text-sm max-w-2xl leading-relaxed">
                            {storeDesc}
                          </p>
                          <div className="flex flex-wrap gap-x-4 gap-y-1 text-[10.5px] text-zinc-400 font-medium justify-center md:justify-start">
                            <span>📅 عضو مميز منذ {mainVendor.joinedDate || '2026'}</span>
                            <span>📍 {storeAddress}</span>
                            <span>📞 الدعم: {storePhone}</span>
                          </div>
                        </div>
                      </div>

                      {/* Store Stats Quick indicators */}
                      <div className="flex gap-4">
                        <div className="bg-zinc-50 border border-zinc-150 px-4 py-2.5 rounded-xl text-center min-w-[85px]">
                          <span className="text-zinc-400 text-[9px] block">المنتجات</span>
                          <span className="font-bold text-sm text-zinc-850 font-mono">
                            {state.products.filter(p => p.vendorId === mainVendor.id).length}
                          </span>
                        </div>
                        <div className="bg-zinc-50 border border-zinc-150 px-4 py-2.5 rounded-xl text-center min-w-[85px]">
                          <span className="text-zinc-400 text-[9px] block">التقييم</span>
                          <span className="font-bold text-sm text-amber-600 font-mono">4.9 ★</span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* Storefront Navigation & Filter Rails */}
              <div className="bg-white border-b border-zinc-150 py-4 px-4 sticky top-[108px] z-30">
                <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
                  {/* Category Filter Scroll */}
                  <div className="flex gap-2 overflow-x-auto pb-1 max-w-full">
                    <button
                      onClick={() => setSelectedCategory('all')}
                      className={`text-xs px-4 py-2 rounded-full font-bold whitespace-nowrap cursor-pointer transition-all ${
                        selectedCategory === 'all'
                          ? 'bg-zinc-950 text-amber-400'
                          : 'bg-zinc-100 text-zinc-600 hover:bg-zinc-200'
                      }`}
                    >
                      الكل المعروض
                    </button>
                    {categories.map((cat) => (
                      <button
                        key={cat.id}
                        onClick={() => setSelectedCategory(cat.slug)}
                        className={`text-xs px-4 py-2 rounded-full font-bold whitespace-nowrap cursor-pointer transition-all ${
                          selectedCategory === cat.slug
                            ? 'bg-zinc-950 text-amber-400'
                            : 'bg-zinc-100 text-zinc-600 hover:bg-zinc-200'
                        }`}
                      >
                        {cat.name}
                      </button>
                    ))}
                  </div>

                  {/* Search Bar Input */}
                  <div className="relative w-full md:w-72">
                    <Search className="w-4 h-4 text-zinc-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      placeholder="ابحث عن العطور، الملابس، المجوهرات..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full text-xs pr-10 pl-4 py-2 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white focus:outline-none focus:border-amber-500 transition-all text-right"
                    />
                  </div>
                </div>
              </div>

              {/* Category-Specific Animated Banners Section */}
              {(() => {
                const displayBanners = banners.filter(b => b.isActive && (selectedCategory === 'all' ? !b.categorySlug : b.categorySlug === selectedCategory));
                const finalBanners = displayBanners.length > 0 ? displayBanners : banners.filter(b => b.isActive && !b.categorySlug);
                
                if (finalBanners.length === 0) return null;
                
                // Ensure index is valid
                const currentIndex = activeBannerIndex % finalBanners.length;
                const activeBanner = finalBanners[currentIndex];
                
                // Get variants based on animationType
                const getAnimationVariants = (type?: string) => {
                  switch (type) {
                    case 'fade':
                      return {
                        initial: { opacity: 0 },
                        animate: { opacity: 1 },
                        exit: { opacity: 0 },
                        transition: { duration: 0.8 }
                      };
                    case 'slide':
                      return {
                        initial: { x: 150, opacity: 0 },
                        animate: { x: 0, opacity: 1 },
                        exit: { x: -150, opacity: 0 },
                        transition: { type: 'spring', stiffness: 120, damping: 14 }
                      };
                    case 'zoom':
                      return {
                        initial: { scale: 0.85, opacity: 0 },
                        animate: { scale: 1, opacity: 1 },
                        exit: { scale: 1.1, opacity: 0 },
                        transition: { duration: 0.6 }
                      };
                    case 'bounce':
                      return {
                        initial: { y: -40, opacity: 0 },
                        animate: { y: 0, opacity: 1 },
                        exit: { y: 40, opacity: 0 },
                        transition: { type: 'spring', bounce: 0.5, duration: 0.7 }
                      };
                    default:
                      return {
                        initial: { opacity: 1 },
                        animate: { opacity: 1 },
                        exit: { opacity: 1 },
                        transition: { duration: 0.1 }
                      };
                  }
                };

                const variants = getAnimationVariants(activeBanner.animationType);

                return (
                  <div className="max-w-7xl mx-auto px-4 mt-6">
                    <div className="relative h-48 sm:h-64 md:h-80 w-full rounded-3xl overflow-hidden border border-zinc-150 shadow-lg bg-zinc-900 group">
                      <AnimatePresence mode="wait">
                        <motion.div
                          key={`${activeBanner.id}-${currentIndex}`}
                          initial={variants.initial}
                          animate={variants.animate}
                          exit={variants.exit}
                          transition={variants.transition}
                          className="absolute inset-0 w-full h-full"
                        >
                          <img
                            src={activeBanner.imageUrl}
                            alt={activeBanner.title}
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/90 via-zinc-950/40 to-transparent p-6 md:p-10 flex flex-col justify-end text-right" dir="rtl">
                            <span className="text-amber-400 font-bold text-[10px] md:text-xs uppercase tracking-wider block mb-1">
                              {activeBanner.categorySlug ? '✨ عرض مخصص للقسم' : '🔥 عروض ومفاجآت متجر مها'}
                            </span>
                            <h3 className="font-black text-white text-base sm:text-xl md:text-3xl leading-tight">
                              {activeBanner.title}
                            </h3>
                            <p className="text-zinc-200 text-xs md:text-sm mt-1.5 max-w-xl leading-relaxed">
                              {activeBanner.subtitle}
                            </p>
                            
                            {activeBanner.couponCode && (
                              <div className="mt-4 flex items-center gap-2">
                                <span className="text-[10px] md:text-xs text-zinc-300 font-bold">استخدم رمز الكوبون للحصول على الخصم:</span>
                                <span className="bg-amber-500 text-zinc-950 font-black px-3 py-1 rounded-xl text-xs md:text-sm font-mono tracking-wider">
                                  {activeBanner.couponCode}
                                </span>
                              </div>
                            )}
                          </div>
                        </motion.div>
                      </AnimatePresence>

                      {/* Controls */}
                      {finalBanners.length > 1 && (
                        <>
                          <button
                            type="button"
                            onClick={() => setActiveBannerIndex(prev => (prev - 1 + finalBanners.length) % finalBanners.length)}
                            className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/10 hover:bg-white/30 text-white backdrop-blur-md w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center cursor-pointer transition-all border border-white/10 z-10"
                          >
                            ❮
                          </button>
                          <button
                            type="button"
                            onClick={() => setActiveBannerIndex(prev => (prev + 1) % finalBanners.length)}
                            className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/10 hover:bg-white/30 text-white backdrop-blur-md w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center cursor-pointer transition-all border border-white/10 z-10"
                          >
                            ❯
                          </button>

                          {/* Dots */}
                          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-1.5 z-10">
                            {finalBanners.map((_, idx) => (
                              <button
                                key={idx}
                                type="button"
                                onClick={() => setActiveBannerIndex(idx)}
                                className={`w-2 h-2 rounded-full transition-all cursor-pointer ${
                                  idx === currentIndex ? 'bg-amber-500 w-5' : 'bg-white/40 hover:bg-white/60'
                                }`}
                              />
                            ))}
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                );
              })()}

              {/* Dynamic Filter Badges (Offers vs Bestseller) */}
              <div className="max-w-7xl mx-auto px-4 pt-6 flex gap-2">
                <button
                  onClick={() => setActiveFilter('all')}
                  className={`text-xs px-3.5 py-1.5 rounded-lg font-bold border transition-all cursor-pointer ${
                    activeFilter === 'all'
                      ? 'bg-amber-500/15 border-amber-500 text-amber-800'
                      : 'border-zinc-200 text-zinc-500 hover:bg-zinc-50'
                  }`}
                >
                  جميع المنتجات
                </button>
                <button
                  onClick={() => setActiveFilter('offers')}
                  className={`text-xs px-3.5 py-1.5 rounded-lg font-bold border transition-all cursor-pointer ${
                    activeFilter === 'offers'
                      ? 'bg-amber-500/15 border-amber-500 text-amber-800'
                      : 'border-zinc-200 text-zinc-500 hover:bg-zinc-50'
                  }`}
                >
                  🔥 العروض اليومية والتخفيضات
                </button>
                <button
                  onClick={() => setActiveFilter('bestSeller')}
                  className={`text-xs px-3.5 py-1.5 rounded-lg font-bold border transition-all cursor-pointer ${
                    activeFilter === 'bestSeller'
                      ? 'bg-amber-500/15 border-amber-500 text-amber-800'
                      : 'border-zinc-200 text-zinc-500 hover:bg-zinc-50'
                  }`}
                >
                  ✨ الأكثر مبيعاً ورواجاً
                </button>
              </div>

              {/* Product Grid */}
              <div className="max-w-7xl mx-auto px-4 py-8 flex-grow">
                {filteredProducts.length === 0 ? (
                  <div className="text-center py-20 bg-white rounded-3xl border border-zinc-150 p-6">
                    <p className="text-zinc-500 text-sm">عذراً، لم نعثر على أي منتجات تطابق بحثك حالياً.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    {filteredProducts.map((prod) => (
                      <ProductCard
                        key={prod.id}
                        product={prod}
                        onAddToCart={(p, e) => {
                          e.stopPropagation();
                          handleAddToCart(p);
                        }}
                        onViewDetails={(p) => setActiveProduct(p)}
                        onToggleWishlist={(id, e) => {
                          e.stopPropagation();
                          handleToggleWishlist(id);
                        }}
                        isWishlisted={wishlist.includes(prod.id)}
                      />
                    ))}
                  </div>
                )}
              </div>

            </div>
          ) : buyerTab === 'tracker' ? (
            /* Customer Tracker Dashboard */
            <CustomerPanel
              orders={state.orders}
              wishlist={wishlist}
              products={state.products}
              currentCustomer={currentCustomer}
              onTriggerLogin={() => setIsCustomerLoginOpen(true)}
              onLogout={async () => {
                try {
                  await logoutUser();
                  addNotification('تسجيل خروج 🔒', 'تم تسجيل خروجك بنجاح. تصفحك الآن كزائر.', 'system');
                } catch (err) {
                  console.error('Error logging out:', err);
                }
              }}
              onToggleWishlist={handleToggleWishlist}
              onAddToCart={handleAddToCart}
              onOpenChat={handleOpenDirectChat}
              onSelectProduct={(p) => setActiveProduct(p)}
              vendors={state.vendors}
            />
          ) : buyerTab === 'privacy' ? (
            /* Privacy Policy Page */
            <div className="max-w-4xl mx-auto px-6 py-12 text-right w-full" dir="rtl">
              <div className="bg-white p-8 md:p-12 rounded-3xl border border-zinc-150 shadow-sm space-y-6">
                <div className="border-b border-zinc-100 pb-4">
                  <span className="text-3xl">📜</span>
                  <h2 className="text-2xl font-black text-zinc-950 mt-3 font-sans">سياسة الخصوصية وسرية البيانات</h2>
                  <p className="text-[11px] text-zinc-400 mt-1">آخر تحديث: يونيو 2026</p>
                </div>
                <div className="text-zinc-700 text-sm leading-relaxed whitespace-pre-line font-sans space-y-4">
                  {state.storeSettings.privacyPolicy || 'نحن في متجر مها نلتزم تماماً بحماية خصوصية بيانات عملاء المتجر والزوار.'}
                </div>
                <div className="pt-6 border-t border-zinc-100 flex justify-end">
                  <button
                    onClick={() => setBuyerTab('shop')}
                    className="bg-amber-500 hover:bg-amber-600 text-zinc-950 font-black px-6 py-2.5 rounded-xl text-xs transition-colors cursor-pointer"
                  >
                    🛍️ العودة للتسوق في المتجر
                  </button>
                </div>
              </div>
            </div>
          ) : buyerTab === 'terms' ? (
            /* Terms & Conditions Page */
            <div className="max-w-4xl mx-auto px-6 py-12 text-right w-full" dir="rtl">
              <div className="bg-white p-8 md:p-12 rounded-3xl border border-zinc-150 shadow-sm space-y-6">
                <div className="border-b border-zinc-100 pb-4">
                  <span className="text-3xl">⚖️</span>
                  <h2 className="text-2xl font-black text-zinc-950 mt-3 font-sans">الشروط والأحكام وسياسات البيع</h2>
                  <p className="text-[11px] text-zinc-400 mt-1">آخر تحديث: يونيو 2026</p>
                </div>
                <div className="text-zinc-700 text-sm leading-relaxed whitespace-pre-line font-sans space-y-4">
                  {state.storeSettings.termsConditions || 'شروط وأحكام الاستخدام والبيع المعمول بها لجميع طلبيات متجر مها.'}
                </div>
                <div className="pt-6 border-t border-zinc-100 flex justify-end">
                  <button
                    onClick={() => setBuyerTab('shop')}
                    className="bg-amber-500 hover:bg-amber-600 text-zinc-950 font-black px-6 py-2.5 rounded-xl text-xs transition-colors cursor-pointer"
                  >
                    🛍️ العودة للتسوق في المتجر
                  </button>
                </div>
              </div>
            </div>
          ) : (
            /* Contact Us Page */
            <div className="max-w-4xl mx-auto px-6 py-12 text-right w-full font-sans animate-fade-in" dir="rtl">
              <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
                {/* Contact Info Bento */}
                <div className="md:col-span-5 bg-zinc-950 text-white p-8 rounded-3xl border border-zinc-800 space-y-6 flex flex-col justify-between">
                  <div className="space-y-4">
                    <span className="bg-amber-500/10 text-amber-400 text-[10px] font-bold px-3 py-1 rounded-full border border-amber-500/20 inline-block">
                      تواصل معنا مباشرة 👑
                    </span>
                    <h3 className="text-xl font-black text-amber-400 leading-snug">يسعدنا دائماً الاستماع إليك ومساعدتك!</h3>
                    <p className="text-xs text-zinc-400 leading-relaxed">
                      فريق خدمة عملاء متجر مها متواجد على مدار الساعة للرد على استفساراتكم حول الملابس المتاحة، تفصيل الفساتين، العطور، وتنسيق الهدايا والشحن السريع لجميع المحافظات اليمنية.
                    </p>
                  </div>

                  <div className="space-y-4 border-t border-zinc-900 pt-6">
                    <div className="flex items-center gap-3">
                      <span className="text-xl">📞</span>
                      <div>
                        <div className="text-[10px] text-zinc-500">رقم الهاتف للتواصل المباشر</div>
                        <a href={`tel:${state.storeSettings.phone}`} className="text-xs font-bold text-amber-400 font-mono inline-block">{state.storeSettings.phone}</a>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-xl">💬</span>
                      <div>
                        <div className="text-[10px] text-zinc-500">رقم الواتساب السريع</div>
                        <a href={`https://wa.me/${state.storeSettings.whatsapp?.replace(/[^0-9]/g, '')}`} target="_blank" rel="noopener noreferrer" className="text-xs font-bold text-emerald-400 font-mono inline-block">{state.storeSettings.whatsapp}</a>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-xl">📧</span>
                      <div>
                        <div className="text-[10px] text-zinc-500">البريد الإلكتروني الرسمي</div>
                        <a href={`mailto:${state.storeSettings.email}`} className="text-xs font-bold text-zinc-300 font-mono">{state.storeSettings.email}</a>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-xl">📍</span>
                      <div>
                        <div className="text-[10px] text-zinc-500">مقر ومعرض متجر مها الرئيسي</div>
                        <div className="text-xs font-bold text-zinc-300">{state.storeSettings.address}</div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Direct Message Form */}
                <div className="md:col-span-7 bg-white p-8 rounded-3xl border border-zinc-150 shadow-sm space-y-6">
                  <div className="border-b border-zinc-100 pb-3">
                    <h3 className="text-lg font-black text-zinc-900">أرسل لنا رسالة فورية 📨</h3>
                    <p className="text-[10.5px] text-zinc-400 mt-1">سيقوم موظفونا بالتواصل معك فوراً والرد على استفسارك.</p>
                  </div>

                  <form onSubmit={(e) => {
                    e.preventDefault();
                    const form = e.currentTarget;
                    const name = (form.elements.namedItem('name') as HTMLInputElement).value;
                    const contact = (form.elements.namedItem('contact') as HTMLInputElement).value;
                    const message = (form.elements.namedItem('message') as HTMLTextAreaElement).value;
                    handleAddInquiry(name, contact, message);
                    form.reset();
                    alert('✨ تم إرسال رسالتك واستفسارك بنجاح! سيقوم فريق خدمة العملاء بالرد عليك فوراً عبر الهاتف أو الواتساب.');
                  }} className="space-y-4">
                    <div>
                      <label className="text-[10px] text-zinc-400 font-bold block mb-1">الاسم الكامل *</label>
                      <input
                        type="text"
                        name="name"
                        required
                        placeholder="أدخل اسمك الكريم..."
                        className="w-full text-xs p-3 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-zinc-400 font-bold block mb-1">رقم الهاتف أو البريد الإلكتروني للتواصل *</label>
                      <input
                        type="text"
                        name="contact"
                        required
                        placeholder="مثال: 777111222 أو email@example.com"
                        className="w-full text-xs p-3 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white text-right"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-zinc-400 font-bold block mb-1">نص الرسالة أو الاستفسار بالتفصيل *</label>
                      <textarea
                        name="message"
                        required
                        rows={4}
                        placeholder="اكتب هنا ما تود الاستفسار عنه (مثال: توفر منتج، المقاسات، الشحن للمحافظات...)"
                        className="w-full text-xs p-3 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white leading-relaxed resize-none"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-amber-500 hover:bg-amber-600 text-zinc-950 font-black py-3 rounded-xl text-xs transition-colors cursor-pointer"
                    >
                      🚀 إرسال الاستفسار الفوري لخدمة العملاء
                    </button>
                  </form>
                </div>
              </div>
            </div>
          )
        }

          {/* Floating WhatsApp contact button widget */}
          <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-3 font-sans print:hidden">
            <div className="relative flex flex-col items-end">
              {/* WhatsApp Support Popup */}
              {isWhatsAppOpen && (
                <div
                  className="bg-white border border-zinc-150 p-4 rounded-2xl shadow-2xl mb-3 w-72 text-right"
                  dir="rtl"
                >
                  <div className="bg-[#128C7E] text-white p-3.5 rounded-xl flex gap-3 items-center mb-3">
                    <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center text-xl">👩‍💼</div>
                    <div>
                      <h4 className="font-bold text-xs">خدمة عملاء متجر مها</h4>
                      <p className="text-[10px] text-zinc-100">عادة ما نرد خلال دقائق معدودة</p>
                    </div>
                  </div>
                  
                  <p className="text-[11px] text-zinc-600 leading-relaxed mb-3">
                    مرحباً بك في متجر مها للأناقة! كيف يمكننا مساعدتك اليوم؟ يمكنك مراسلتنا مباشرة عبر واتساب للإجابة عن جميع استفساراتك.
                  </p>

                  <a
                    href="https://wa.me/967777000111?text=%D9%85%D8%B1%D8%AD%D8%A8%D8%A7%D9%8B%20%D9%85%D8%AA%D8%AC%D8%B1%20%D9%85%D9%87%D8%A7%D8%8C%20%D8%A3%D9%88%D8%AF%20%D8%A7%D9%84%D8%A7%D8%B3%D8%AA%D9%81%D8%B3%D8%A7%D8%B1%20%D8%B9%D9%86%20%D8%A8%D8%B9%D8%B6%20%D8%A7%D9%84%D9%85%D9%86%D8%AA%D8%AC%D8%A7%D8%AA%20%D8%A7%D9%84%D9%85%D8%B9%D8%B1%D9%88%D8%B6%D8%A9"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-[#25D366] hover:bg-[#128C7E] text-white font-bold text-xs py-2 px-4 rounded-xl flex items-center justify-center gap-1.5 transition-all shadow-sm"
                  >
                    <span>💬 تواصل عبر واتساب الفوري</span>
                  </a>
                </div>
              )}

              {/* Trigger Button */}
              <button
                onClick={() => setIsWhatsAppOpen(!isWhatsAppOpen)}
                className="w-13 h-13 rounded-full bg-[#25D366] hover:bg-[#128C7E] text-white shadow-xl flex items-center justify-center transition-all cursor-pointer hover:scale-115 relative group"
                title="تواصل معنا عبر واتساب"
              >
                <span className="text-xl">💬</span>
                {/* Pulsing indicator */}
                <span className="absolute top-0 right-0 w-3 h-3 bg-red-500 rounded-full border-2 border-white animate-pulse"></span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. ADMIN PANEL VIEW */}
      {(currentRole === 'admin' || currentRole === 'employee') && (
        (() => {
          const isAuthorized =
            (currentRole === 'admin' && currentCustomer?.role === 'admin') ||
            (currentRole === 'employee' && (currentCustomer?.role === 'employee' || currentCustomer?.role === 'admin'));

          if (!isAuthorized) {
            return (
              <AccessDenied
                onReturn={() => {
                  setCurrentRole('customer');
                  setBuyerTab('shop');
                }}
              />
            );
          }

          return (
            <AdminPanel
              products={state.products}
              orders={state.orders}
              vendors={state.vendors}
              coupons={state.coupons}
              employees={state.employees}
              shippingMethods={state.shippingMethods}
              paymentGateways={state.paymentGateways}
              abandonedCarts={state.abandonedCarts}
              currentRole={currentRole}
              activeEmployeeId={activeEmployeeId}
              onVerifyVendor={handleVerifyVendor}
              onUpdateVendorCommission={handleUpdateVendorCommission}
              onAddCoupon={handleAddCoupon}
              onDeleteCoupon={handleDeleteCoupon}
              onAddEmployee={handleAddEmployee}
              onDeleteEmployee={handleDeleteEmployee}
              onUpdateShippingMethod={handleUpdateShippingMethod}
              onUpdatePaymentGateway={handleUpdatePaymentGateway}
              onAddPaymentGateway={handleAddPaymentGateway}
              onDeletePaymentGateway={handleDeletePaymentGateway}
              onSendCartReminder={handleSendCartReminder}
              onUpdateOrderStatus={handleUpdateOrderStatus}
              onAddProduct={handleAddProduct}
              onEditProduct={handleEditProduct}
              onDeleteProduct={handleDeleteProduct}
              onOpenChat={handleOpenDirectChat}
              categories={categories}
              onAddCategory={(name, slug) => {
                const newCat: Category = { id: `cat_${Date.now()}`, name, slug, icon: 'Package' };
                setCategories(prev => [...prev, newCat]);
              }}
              banners={banners}
              onUpdateBanners={handleUpdateBanners}
              onAddNotification={(title, msg, type) => addNotification(title, msg, type)}
              inquiries={inquiries}
              onMarkInquiryRead={handleMarkInquiryRead}
              onDeleteInquiry={handleDeleteInquiry}
              storeSettings={state.storeSettings}
              onUpdateStoreSettings={(settings) => setState(prev => ({ ...prev, storeSettings: sanitizeStoreSettings({ ...prev.storeSettings, ...settings }) }))}
            />
          );
        })()
      )}

      {/* App Download Section (Bottom of Page) */}
      {currentRole === 'customer' && (
        <div id="app-download-section-home" className="bg-zinc-50 border-t border-b border-zinc-150 py-12 px-6 relative overflow-hidden w-full">
          <div className="absolute inset-0 opacity-40 bg-[radial-gradient(#f59e0b_1px,transparent_1px)] [background-size:16px_16px]"></div>
          <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 items-center relative z-10 text-right">
            <div className="md:col-span-7 space-y-4">
              <span className="bg-amber-500/10 text-amber-700 text-[10px] font-bold px-3 py-1 rounded-full border border-amber-500/20 uppercase tracking-wide inline-flex items-center gap-1">
                <span>تطبيق متجر مها الرسمي 👑</span>
              </span>
              <h3 className="text-xl md:text-2xl font-black text-zinc-900">
                حمّل تطبيق متجر مها على هاتفك المحمول لتجربة تسوق أسرع!
              </h3>
              <p className="text-zinc-500 text-xs md:text-sm leading-relaxed max-w-xl">
                استمتع بتصفح تشكيلاتنا الفاخرة، تتبع طلبياتك لحظة بلحظة، واحصل على إشعارات العروض الحصرية والتخفيضات اليومية قبل الجميع مباشرة على هاتفك.
              </p>
              
              <div className="flex flex-wrap gap-4 pt-3 justify-start items-center">
                {/* Android App Link Button */}
                {state.storeSettings.androidAppLink ? (
                  <a
                    href={state.storeSettings.androidAppLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-zinc-900 hover:bg-black text-white px-5 py-3 rounded-2xl flex items-center gap-3 transition-all hover:-translate-y-0.5 shadow-md border border-zinc-800"
                  >
                    <svg className="w-6 h-6 text-emerald-400 fill-current" viewBox="0 0 24 24">
                      <path d="M17.523 15.3l1.82 3.15a.5.5 0 01-.183.682.496.496 0 01-.68-.18l-1.84-3.18a9.432 9.432 0 01-6.19 0l-1.84 3.18a.496.496 0 01-.68.18.5.5 0 01-.183-.682l1.82-3.15A9.458 9.458 0 013 7.82V7a.5.5 0 01.5-.5h17a.5.5 0 01.5.5v.82a9.458 9.458 0 01-3.477 7.48M7 10.5a.75.75 0 100-1.5.75.75 0 000 1.5m10 0a.75.75 0 100-1.5.75.75 0 000 1.5"/>
                    </svg>
                    <div className="text-right">
                      <div className="text-[9px] text-zinc-400">تحميل للأندرويد</div>
                      <div className="text-xs font-black font-sans">Google Play</div>
                    </div>
                  </a>
                ) : (
                  <div className="bg-zinc-150 text-zinc-400 px-5 py-3 rounded-2xl border border-dashed border-zinc-200 text-center flex flex-col justify-center min-w-[140px]">
                    <span className="text-[9px] block">تطبيق الأندرويد</span>
                    <span className="text-xs font-bold text-zinc-500">التطبيق قريبًا ⏳</span>
                  </div>
                )}

                {/* iPhone App Link Button */}
                {state.storeSettings.iphoneAppLink ? (
                  <a
                    href={state.storeSettings.iphoneAppLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-zinc-900 hover:bg-black text-white px-5 py-3 rounded-2xl flex items-center gap-3 transition-all hover:-translate-y-0.5 shadow-md border border-zinc-800"
                  >
                    <svg className="w-6 h-6 text-white fill-current" viewBox="0 0 24 24">
                      <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 4.17c.66-.81 1.11-1.93.99-3.06-1 .04-2.14.67-2.86 1.5-.61.73-1.15 1.87-1 2.97 1.11.09 2.21-.59 2.87-1.41z"/>
                    </svg>
                    <div className="text-right">
                      <div className="text-[9px] text-zinc-400">تحميل للآيفون</div>
                      <div className="text-xs font-black font-sans">App Store</div>
                    </div>
                  </a>
                ) : (
                  <div className="bg-zinc-150 text-zinc-400 px-5 py-3 rounded-2xl border border-dashed border-zinc-200 text-center flex flex-col justify-center min-w-[140px]">
                    <span className="text-[9px] block">تطبيق الآيفون</span>
                    <span className="text-xs font-bold text-zinc-500">التطبيق قريبًا ⏳</span>
                  </div>
                )}
              </div>
            </div>

            {/* Right side phones graphic */}
            <div className="md:col-span-5 flex justify-center md:justify-end">
              <div className="relative w-full max-w-[280px] h-48 md:h-56">
                {/* Back Phone Shadow Mock */}
                <div className="absolute top-4 left-4 w-32 h-44 rounded-2xl bg-zinc-950 border border-zinc-800 shadow-xl overflow-hidden flex flex-col justify-between p-3 opacity-90 rotate-12 transition-transform duration-500 hover:rotate-6">
                  <div className="w-6 h-1.5 bg-zinc-800 rounded-full mx-auto"></div>
                  <div className="text-[7px] text-zinc-400 font-mono text-center">MAHA APP</div>
                  <div className="w-12 h-12 bg-amber-500/10 rounded-full mx-auto flex items-center justify-center border border-amber-500/20">
                    <span className="text-lg animate-pulse">👑</span>
                  </div>
                  <div className="w-full h-1 bg-zinc-800 rounded"></div>
                </div>
                
                {/* Front Phone Mock */}
                <div className="absolute top-0 right-4 w-32 h-44 rounded-2xl bg-zinc-950 border-2 border-zinc-800 shadow-2xl overflow-hidden flex flex-col justify-between p-3 -rotate-6 transition-transform duration-500 hover:rotate-0">
                  <div className="w-6 h-1.5 bg-zinc-800 rounded-full mx-auto"></div>
                  <div className="flex justify-between items-center text-[6px] text-zinc-500 font-bold font-sans">
                    <span>12:00</span>
                    <span>📶🔋</span>
                  </div>
                  <div className="text-center">
                    <span className="text-base block">👑</span>
                    <span className="text-[8px] text-amber-400 font-black tracking-tight block mt-1">متجر مها للأناقة</span>
                  </div>
                  <div className="bg-amber-500 text-zinc-950 text-[6px] font-black py-1 rounded text-center">
                    اطلب الآن بخصم 15%
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* FOOTER */}
      <footer className="mt-auto bg-zinc-950 text-zinc-400 border-t border-zinc-900 py-12 text-right text-xs font-sans print:hidden" dir="rtl">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Column 1: Store Intro & Credentials */}
          <div className="lg:col-span-5 space-y-4">
            <h3 className="font-black text-sm text-white flex items-center gap-2">
              <span className="text-xl">{state.storeSettings?.logo || '👑'}</span>
              <span>{state.storeSettings?.name || 'متجر مها الرسمي للأناقة والموضة'}</span>
            </h3>
            <p className="text-zinc-400 leading-relaxed text-[11px] max-w-sm">
              {state.storeSettings?.description || 'الوجهة اليمنية الأولى والوحيدة لشراء أرقى الملابس والفساتين الفاخرة، العطور الشرقية الساحرة، والإكسسوارات المصممة يدوياً. ملتزمون بتقديم أعلى مستويات الجودة والتوصيل السريع لجميع المحافظات.'}
            </p>
            <div className="pt-2 space-y-2">
              <div className="flex items-center gap-2 text-[11px] text-zinc-300">
                <span>📍</span>
                <span>{state.storeSettings?.address || 'المقر الرئيسي: صنعاء، الجمهورية اليمنية'}</span>
              </div>
              <div className="flex items-center gap-2 text-[11px] text-zinc-300">
                <span>📞</span>
                <span>رقم الدعم الفني المباشر: {state.storeSettings?.phone || '+967 777 000 111'}</span>
              </div>
            </div>
            
            <div className="pt-4 border-t border-zinc-900 flex flex-wrap gap-2.5">
              <span className="bg-zinc-900 text-zinc-400 px-2 py-1 rounded text-[10px] font-bold">💳 بنك الكريمي</span>
              <span className="bg-zinc-900 text-zinc-400 px-2 py-1 rounded text-[10px] font-bold">📱 محفظة جيب</span>
              <span className="bg-zinc-900 text-zinc-400 px-2 py-1 rounded text-[10px] font-bold">📦 الدفع عند الاستلام</span>
            </div>
          </div>

          {/* Column 2: Quick Links & Policies */}
          <div className="lg:col-span-3 space-y-6">
            <div>
              <h4 className="font-extrabold text-xs text-white pb-1.5 border-b border-zinc-900">أقسام المتجر</h4>
              <ul className="space-y-2 text-[11px] mt-3">
                <li>
                  <button
                    onClick={() => {
                      setSelectedCategory('all');
                      setBuyerTab('shop');
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="hover:text-amber-400 transition-colors text-right flex items-center gap-1 cursor-pointer"
                  >
                    <span>•</span> <span>الرئيسية (كل المنتجات)</span>
                  </button>
                </li>
                {categories.slice(0, 5).map((cat) => (
                  <li key={cat.id}>
                    <button
                      onClick={() => {
                        setSelectedCategory(cat.slug);
                        setBuyerTab('shop');
                        window.scrollTo({ top: 400, behavior: 'smooth' });
                      }}
                      className="hover:text-amber-400 transition-colors text-right flex items-center gap-1 cursor-pointer"
                    >
                      <span>•</span> <span>{cat.name}</span>
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="font-extrabold text-xs text-white pb-1.5 border-b border-zinc-900">روابط وسياسات هامة</h4>
              <ul className="space-y-2 text-[11px] mt-3">
                <li>
                  <button
                    onClick={() => {
                      setBuyerTab('tracker');
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="hover:text-amber-400 transition-colors text-right flex items-center gap-1 cursor-pointer"
                  >
                    <span>•</span> <span>تتبع حالة الطلب 📦</span>
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => {
                      setBuyerTab('privacy');
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="hover:text-amber-400 transition-colors text-right flex items-center gap-1 cursor-pointer"
                  >
                    <span>•</span> <span>سياسة الخصوصية وسرية البيانات 📜</span>
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => {
                      setBuyerTab('terms');
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="hover:text-amber-400 transition-colors text-right flex items-center gap-1 cursor-pointer"
                  >
                    <span>•</span> <span>الشروط والأحكام وسياسة البيع ⚖️</span>
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => {
                      setBuyerTab('contact');
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="hover:text-amber-400 transition-colors text-right flex items-center gap-1 cursor-pointer"
                  >
                    <span>•</span> <span>اتصل بنا وخدمة العملاء 📞</span>
                  </button>
                </li>
              </ul>
            </div>
          </div>

          {/* Column 3: Beautiful Embedded Contact Form */}
          <div className="lg:col-span-4 bg-zinc-900/60 p-5 rounded-2xl border border-zinc-900/80 space-y-3.5 w-full">
            <h4 className="font-extrabold text-xs text-white flex items-center gap-1.5">
              <span>✉️</span>
              <span>تواصل معنا مباشرة</span>
            </h4>
            <p className="text-[10.5px] text-zinc-400 leading-normal">
              لديك سؤال، شكوى أو اقتراح؟ أرسل رسالتك فوراً وسيتم الرد عليك في غضون ساعات قليلة من قبل طاقم الإدارة.
            </p>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                const formData = new FormData(e.currentTarget);
                const name = formData.get('name') as string;
                const contact = formData.get('contact') as string;
                const message = formData.get('message') as string;
                if (!name || !contact || !message) return;

                handleAddInquiry(name, contact, message);
                setFooterFormSubmitted(true);
                e.currentTarget.reset();
                
                setTimeout(() => {
                  setFooterFormSubmitted(false);
                }, 8000);
              }}
              className="space-y-2.5 text-right"
            >
              {footerFormSubmitted ? (
                <div className="bg-emerald-950/50 border border-emerald-500/20 text-emerald-400 p-3 rounded-xl text-[10.5px] font-bold text-center leading-relaxed">
                  🎉 تم إرسال استفسارك بنجاح! شكراً لتواصلك، لقد وصلت رسالتك إلى لوحة الإدارة وسيتواصل معك فريقنا قريباً.
                </div>
              ) : (
                <>
                  <div>
                    <input
                      type="text"
                      name="name"
                      required
                      placeholder="الاسم الكامل *"
                      className="w-full text-[11px] p-2 rounded-lg bg-zinc-950 border border-zinc-800 text-white placeholder-zinc-500 focus:border-amber-500 focus:outline-none transition-all"
                    />
                  </div>
                  <div>
                    <input
                      type="text"
                      name="contact"
                      required
                      placeholder="رقم الهاتف أو البريد الإلكتروني للتواصل *"
                      className="w-full text-[11px] p-2 rounded-lg bg-zinc-950 border border-zinc-800 text-white placeholder-zinc-500 focus:border-amber-500 focus:outline-none transition-all"
                    />
                  </div>
                  <div>
                    <textarea
                      name="message"
                      required
                      rows={2}
                      placeholder="اكتب استفسارك أو رسالتك هنا بالتفصيل..."
                      className="w-full text-[11px] p-2 rounded-lg bg-zinc-950 border border-zinc-800 text-white placeholder-zinc-500 focus:border-amber-500 focus:outline-none resize-none transition-all"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-amber-500 hover:bg-amber-600 text-zinc-950 font-extrabold py-2 rounded-lg text-[10.5px] transition-all cursor-pointer shadow-md"
                  >
                    إرسال الاستفسار الآن
                  </button>
                </>
              )}
            </form>
          </div>

        </div>

        {/* Lower footer segment */}
        <div className="max-w-7xl mx-auto px-6 mt-8 pt-6 border-t border-zinc-900 flex flex-col md:flex-row items-center justify-between gap-4 text-[10.5px] text-zinc-500">
          <p>
            متجر مها للأناقة والموضة © {new Date().getFullYear()} • جميع الحقوق محفوظة لمتجر مها
          </p>
        </div>
      </footer>

      {/* OVERLAY MODALS & PORTALS CONTAINER */}

      {/* Product Details Modal */}
      {activeProduct && (
        <ProductDetailsModal
          product={activeProduct}
          onClose={() => setActiveProduct(null)}
          onAddToCart={handleAddToCart}
          onStartChat={handleOpenDirectChat}
          reviews={state.reviews}
          onAddReview={handleAddReview}
          isWishlisted={wishlist.includes(activeProduct.id)}
          onToggleWishlist={handleToggleWishlist}
        />
      )}

      {/* Chat Component Drawer */}
      <ChatComponent
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        messages={state.messages}
        onSendMessage={handleSendMessage}
        vendors={state.vendors}
        activeVendorId={chatVendorId}
        activeProductId={chatProductId}
        activeProductTitle={chatProductTitle}
      />

      {/* Cart Modal Drawer */}
      <CartModal
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveFromCart}
        onCheckout={() => {
          setIsCartOpen(false);
          setIsCheckoutOpen(true);
        }}
        appliedCoupon={appliedCoupon}
        onApplyCoupon={handleApplyCoupon}
        onRemoveCoupon={handleRemoveCoupon}
      />

      {/* Checkout Modal Overlay */}
      {isCheckoutOpen && (
        <CheckoutModal
          isOpen={isCheckoutOpen}
          onClose={() => setIsCheckoutOpen(false)}
          cartItems={cart}
          appliedCoupon={appliedCoupon}
          currentCustomer={currentCustomer}
          onPlaceOrder={handlePlaceOrder}
        />
      )}

      {/* Customer Login Modal */}
      {isCustomerLoginOpen && (
        <CustomerLoginModal
          isOpen={isCustomerLoginOpen}
          onClose={() => setIsCustomerLoginOpen(false)}
          onLoginSuccess={(customer) => {
            setCurrentCustomer(customer);
            addNotification('تم تسجيل الدخول 🎉', `مرحباً بك مجدداً يا ${customer.name}. تم تسجيل الدخول بنجاح.`, 'system');
          }}
        />
      )}
    </div>
  );
}
