import React from 'react';
import { Star, Heart, ShoppingCart, Eye, Tag } from 'lucide-react';
import { Product } from '../types';
import { motion } from 'motion/react';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product, e: React.MouseEvent) => void;
  onViewDetails: (product: Product) => void;
  onToggleWishlist: (productId: string, e: React.MouseEvent) => void;
  isWishlisted: boolean;
}

const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onAddToCart,
  onViewDetails,
  onToggleWishlist,
  isWishlisted,
}) => {
  const hasDiscount = product.originalPrice && product.originalPrice > product.price;
  const discountPercentage = hasDiscount
    ? Math.round(((product.originalPrice! - product.price) / product.originalPrice!) * 100)
    : 0;

  return (
    <motion.div
      id={`product-card-${product.id}`}
      whileHover={{ y: -6, transition: { duration: 0.2 } }}
      className="bg-white rounded-2xl overflow-hidden border border-zinc-100 shadow-sm hover:shadow-xl transition-all group flex flex-col h-full relative"
    >
      {/* Product Image Area */}
      <div className="relative aspect-square w-full bg-zinc-50 overflow-hidden cursor-pointer" onClick={() => onViewDetails(product)}>
        <img
          src={product.images?.[0] || 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=600'}
          alt={product.title}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />

        {/* Badges Overlay */}
        <div className="absolute top-3 right-3 flex flex-col gap-1.5 z-10">
          {hasDiscount && (
            <span className="bg-red-500 text-white text-[11px] font-bold px-2.5 py-1 rounded-full shadow-md flex items-center gap-1">
              <Tag className="w-3 h-3" />
              <span>خصم {discountPercentage}%</span>
            </span>
          )}
          {product.isBestSeller && (
            <span className="bg-zinc-900 text-amber-400 text-[10px] font-bold px-2.5 py-1 rounded-full border border-amber-500/30 shadow-md">
              🔥 الأكثر مبيعاً
            </span>
          )}
          {product.isDailyOffer && (
            <span className="bg-gradient-to-r from-amber-500 to-yellow-500 text-zinc-950 text-[10px] font-bold px-2.5 py-1 rounded-full shadow-md">
              ⚡ عرض اليوم
            </span>
          )}
        </div>

        {/* Wishlist Button */}
        <button
          id={`wishlist-btn-${product.id}`}
          onClick={(e) => onToggleWishlist(product.id, e)}
          className="absolute top-3 left-3 w-8.5 h-8.5 rounded-full bg-white/90 backdrop-blur-xs flex items-center justify-center text-zinc-600 hover:text-red-500 hover:scale-110 shadow-sm transition-all cursor-pointer z-10"
        >
          <Heart
            className={`w-4 h-4 transition-colors ${
              isWishlisted ? 'fill-red-500 text-red-500 scale-110' : ''
            }`}
          />
        </button>

        {/* Quick View Button overlay on hover */}
        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-2">
          <button
            onClick={() => onViewDetails(product)}
            className="bg-white text-zinc-900 px-4 py-2 rounded-full text-xs font-bold flex items-center gap-1.5 shadow-lg transform translate-y-4 group-hover:translate-y-0 transition-all duration-300 cursor-pointer"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>عرض التفاصيل</span>
          </button>
        </div>
      </div>

      {/* Product Information */}
      <div className="p-4 flex flex-col flex-grow">
        {/* Category & Seller */}
        <div className="flex justify-between items-center text-[11px] text-zinc-500 mb-1.5">
          <span className="bg-zinc-100 text-zinc-700 px-2 py-0.5 rounded-sm">
            {product.category === 'clothing' && 'ملابس وأزياء'}
            {product.category === 'accessories' && 'إكسسوارات'}
            {product.category === 'perfumes' && 'عطور وبخور'}
            {product.category === 'cosmetics' && 'مستحضرات تجميل'}
            {product.category === 'gifts' && 'هدايا وتغليف'}
            {product.category === 'electronics' && 'إلكترونيات ذكية'}
          </span>
          <span className="text-amber-600 font-medium hover:underline cursor-pointer">
            متجر مها
          </span>
        </div>

        {/* Title */}
        <h3
          onClick={() => onViewDetails(product)}
          className="font-bold text-sm text-zinc-900 mb-2 line-clamp-2 leading-snug hover:text-amber-600 cursor-pointer transition-colors flex-grow"
        >
          {product.title}
        </h3>

        {/* Ratings and Sales count */}
        <div className="flex items-center gap-1.5 mb-3">
          <div className="flex items-center text-amber-400">
            <Star className="w-3.5 h-3.5 fill-amber-400" />
            <span className="text-xs font-bold text-zinc-700 mr-1">{(product.rating ?? 5).toFixed(1)}</span>
          </div>
          <span className="text-[10px] text-zinc-400">({product.reviewsCount ?? 0} تقييم)</span>
          <span className="text-zinc-300">•</span>
          <span className="text-[10px] text-zinc-500">{product.salesCount ?? 0} مبيعات</span>
        </div>

        {/* Price and Cart Button */}
        <div className="flex items-center justify-between pt-3 border-t border-zinc-100 mt-auto">
          <div className="flex flex-col">
            {hasDiscount && (
              <span className="text-xs text-zinc-400 line-through font-mono">
                {product.originalPrice?.toLocaleString()} ر.ي
              </span>
            )}
            <span className="text-md font-extrabold text-zinc-950 font-mono flex items-baseline gap-0.5">
              {(product.price ?? 0).toLocaleString()}{' '}
              <span className="text-[10px] text-zinc-500 font-sans font-normal">ر.ي</span>
            </span>
          </div>

          {product.stock > 0 ? (
            <button
              id={`add-to-cart-btn-${product.id}`}
              onClick={(e) => onAddToCart(product, e)}
              className="bg-zinc-900 hover:bg-amber-500 hover:text-zinc-950 text-white p-2.5 rounded-xl transition-all shadow-sm flex items-center justify-center cursor-pointer"
              title="إضافة إلى السلة"
            >
              <ShoppingCart className="w-4 h-4" />
            </button>
          ) : (
            <span className="text-[11px] font-bold text-red-500 bg-red-50 px-2 py-1.5 rounded-lg border border-red-100">
              نفذت الكمية
            </span>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default ProductCard;
