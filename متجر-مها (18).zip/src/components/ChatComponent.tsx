import React, { useState, useRef, useEffect } from 'react';
import { Send, X, MessageCircle, Sparkles, ShoppingBag, Check } from 'lucide-react';
import { Message, User } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface ChatComponentProps {
  isOpen: boolean;
  onClose: () => void;
  messages: Message[];
  onSendMessage: (receiverId: string, content: string, productId?: string, productTitle?: string) => void;
  vendors: User[];
  activeVendorId: string;
  activeProductId?: string;
  activeProductTitle?: string;
}

export default function ChatComponent({
  isOpen,
  onClose,
  messages,
  onSendMessage,
  vendors,
  activeVendorId,
  activeProductId,
  activeProductTitle
}: ChatComponentProps) {
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const activeVendor = vendors.find((v) => v.id === activeVendorId) || vendors[0];

  // Filter messages for current chat session
  // Current session is between 'customer_guest' and activeVendorId
  const currentChatMessages = messages.filter(
    (m) =>
      (m.senderId === 'customer_guest' && m.receiverId === activeVendorId) ||
      (m.senderId === activeVendorId && m.receiverId === 'customer_guest')
  );

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      setTimeout(scrollToBottom, 100);
    }
  }, [isOpen, messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const userMsg = inputText;
    setInputText('');

    // Send user message
    onSendMessage(activeVendorId, userMsg, activeProductId, activeProductTitle);

    // Trigger vendor auto-response simulator
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      let reply = 'أهلاً بك عميلنا العزيز في متجرنا! كيف يمكنني مساعدتك اليوم؟';

      const query = userMsg.toLowerCase();
      if (query.includes('سعر') || query.includes('كم السعر') || query.includes('بكم')) {
        reply = `مرحباً بك، الأسعار موضحة على صفحة المنتج مباشرة، ونضمن لك الحصول على أعلى جودة وأفضل سعر في السوق اليمني حالياً.`;
      } else if (query.includes('مقاس') || query.includes('متوفر') || query.includes('اللون')) {
        reply = `نعم يا فندم، يتوفر منه كميات محدودة حالياً في مخازننا، وننصحك بإضافته للسلة وإكمال الطلب لحجز القطعة قبل نفاذ الكمية.`;
      } else if (query.includes('كريمي') || query.includes('جيب') || query.includes('دفع') || query.includes('طريقة الدفع')) {
        reply = `أهلاً بك، ندعم الدفع عبر بنك الكريمي (حساب أو صرافة)، محفظة جيب الذكية، التحويل البنكي، أو الدفع نقداً عند الاستلام مباشرة لراحتك الكاملة!`;
      } else if (query.includes('توصيل') || query.includes('صنعاء') || query.includes('عدن') || query.includes('تعز')) {
        reply = `نوفر خدمة التوصيل السريع إلى جميع المحافظات اليمنية (صنعاء، عدن، تعز، حضرموت، إب وغيرها) خلال 24 إلى 48 ساعة فقط كحد أقصى.`;
      } else if (query.includes('خصم') || query.includes('كوبون') || query.includes('تخفيض')) {
        reply = `يسعدنا توفير خصومات رائعة! يمكنك استخدام الكود الفعال MAHA10 للحصول على خصم 10% إضافي فوراً عند الدفع!`;
      } else if (activeProductTitle) {
        reply = `أهلاً بك، بخصوص استفسارك عن "${activeProductTitle}"، المنتج متوفر بجودة ممتازة وجاهز للشحن الفوري. هل تود تأكيد حجز طلبك الآن؟`;
      }

      onSendMessage(activeVendorId, reply);
    }, 1500);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div id="chat-sidebar-wrapper" className="fixed inset-y-0 left-0 w-full sm:w-96 bg-white shadow-2xl z-50 flex flex-col border-r border-zinc-200">
          {/* Chat Header */}
          <div className="bg-zinc-950 text-white p-4 flex justify-between items-center border-b border-amber-500/20">
            <div className="flex items-center gap-3">
              <div className="relative">
                <img
                  src={activeVendor.shopLogo || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'}
                  alt={activeVendor.shopName}
                  referrerPolicy="no-referrer"
                  className="w-10 h-10 rounded-full border border-amber-500/30 object-cover"
                />
                <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 border-2 border-zinc-950 rounded-full"></span>
              </div>
              <div>
                <h4 className="font-bold text-sm text-white">{activeVendor.shopName}</h4>
                <p className="text-[10px] text-zinc-400">متصل الآن • يرد غالباً خلال دقيقتين</p>
              </div>
            </div>

            <button
              id="btn-close-chat"
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-zinc-800 text-zinc-400 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Reference Product Alert */}
          {activeProductId && activeProductTitle && (
            <div className="bg-amber-50/70 border-b border-amber-100 p-2.5 px-4 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0">
                <ShoppingBag className="w-4 h-4 text-amber-600 flex-shrink-0" />
                <span className="text-[11px] text-zinc-700 font-medium truncate">
                  استفسار عن: <span className="font-bold text-zinc-900">{activeProductTitle}</span>
                </span>
              </div>
              <span className="text-[9px] bg-amber-500 text-zinc-950 px-2 py-0.5 rounded font-bold whitespace-nowrap">
                نشط
              </span>
            </div>
          )}

          {/* Chat Messages */}
          <div className="flex-grow overflow-y-auto p-4 space-y-3.5 bg-zinc-50/50">
            {currentChatMessages.length === 0 ? (
              <div className="text-center py-12 px-6">
                <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center text-amber-600 mx-auto mb-3">
                  <MessageCircle className="w-6 h-6" />
                </div>
                <h5 className="font-bold text-zinc-800 text-sm">تواصل مباشر وسريع</h5>
                <p className="text-[11px] text-zinc-500 mt-1">
                  اطرح استفسارك للبائع بخصوص توافر المقاسات، جودة الخامات، أو الشحن والتوصيل.
                </p>
              </div>
            ) : (
              currentChatMessages.map((msg) => {
                const isMe = msg.senderId === 'customer_guest';
                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${isMe ? 'items-start' : 'items-end'}`}
                  >
                    {/* Message Bubble */}
                    <div
                      className={`max-w-[85%] rounded-2xl p-3 text-xs leading-relaxed ${
                        isMe
                          ? 'bg-amber-500 text-zinc-950 font-medium rounded-tr-none shadow-xs'
                          : 'bg-white text-zinc-800 border border-zinc-200/80 rounded-tl-none shadow-xs'
                      }`}
                    >
                      {/* Product Reference inside bubble if attached */}
                      {msg.productTitle && (
                        <div className="border-b border-zinc-950/10 pb-1.5 mb-1.5 text-[10px] font-bold text-zinc-900/70 flex items-center gap-1">
                          <ShoppingBag className="w-3 h-3" />
                          <span>المنتج: {msg.productTitle}</span>
                        </div>
                      )}
                      <p>{msg.content}</p>
                    </div>

                    {/* Timestamp */}
                    <span className="text-[9px] text-zinc-400 mt-1 px-1">
                      {new Date(msg.timestamp).toLocaleTimeString('ar-YE', {
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </span>
                  </div>
                );
              })
            )}

            {/* Seller Typing Indicator */}
            {isTyping && (
              <div className="flex flex-col items-end">
                <div className="bg-white text-zinc-400 border border-zinc-150 rounded-2xl rounded-tl-none p-3 shadow-xs">
                  <div className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 bg-zinc-400 rounded-full animate-bounce"></span>
                    <span className="w-1.5 h-1.5 bg-zinc-400 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                    <span className="w-1.5 h-1.5 bg-zinc-400 rounded-full animate-bounce [animation-delay:0.4s]"></span>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Form */}
          <form onSubmit={handleSubmit} className="p-3 border-t border-zinc-200 bg-white flex gap-2">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="اكتب استفسارك هنا للبائع..."
              className="flex-grow text-xs px-3.5 py-2.5 rounded-xl border border-zinc-200 focus:border-amber-500 focus:outline-none bg-zinc-50 focus:bg-white transition-all"
            />
            <button
              id="btn-send-message"
              type="submit"
              className="bg-zinc-900 hover:bg-amber-500 hover:text-zinc-950 text-white p-2.5 rounded-xl transition-all flex items-center justify-center cursor-pointer flex-shrink-0 shadow-xs"
            >
              <Send className="w-4 h-4 transform rotate-180" />
            </button>
          </form>
        </div>
      )}
    </AnimatePresence>
  );
}
