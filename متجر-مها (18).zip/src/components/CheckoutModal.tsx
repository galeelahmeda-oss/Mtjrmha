import React, { useState, useEffect } from 'react';
import { X, CheckCircle, CreditCard, ShieldCheck, MapPin, Phone, User as UserIcon, Receipt } from 'lucide-react';
import { CartItem, Coupon, Order, User } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  appliedCoupon: Coupon | null;
  currentCustomer?: User | null;
  onPlaceOrder: (orderData: {
    name: string;
    phone: string;
    address: string;
    paymentMethod: 'kuraimi' | 'jeeb' | 'bank_transfer' | 'cod';
    paymentDetails: string;
  }) => void;
}

export default function CheckoutModal({
  isOpen,
  onClose,
  cartItems,
  appliedCoupon,
  currentCustomer,
  onPlaceOrder,
}: CheckoutModalProps) {
  const [name, setName] = useState(currentCustomer?.name || '');
  const [phone, setPhone] = useState(currentCustomer?.phone || '');

  useEffect(() => {
    if (currentCustomer) {
      setName(currentCustomer.name || '');
      setPhone(currentCustomer.phone || '');
    }
  }, [currentCustomer]);
  const [province, setProvince] = useState('صنعاء');
  const [addressDetails, setAddressDetails] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'kuraimi' | 'jeeb' | 'bank_transfer' | 'cod'>('cod');
  const [paymentRefId, setPaymentRefId] = useState('');
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [generatedOrderId, setGeneratedOrderId] = useState('');

  const subtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);

  // Calculate discount
  let discountAmount = 0;
  if (appliedCoupon && subtotal >= (appliedCoupon.minSpend || 0)) {
    if (appliedCoupon.discountType === 'percentage') {
      discountAmount = (subtotal * appliedCoupon.value) / 100;
    } else {
      discountAmount = appliedCoupon.value;
    }
  }

  const finalTotal = Math.max(0, subtotal - discountAmount);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim() || !addressDetails.trim()) return;

    const fullAddress = `${province} - ${addressDetails}`;
    const ordId = `ord_${Math.floor(1000 + Math.random() * 9000)}`;

    // Build details
    let paymentDetails = '';
    if (paymentMethod !== 'cod') {
      paymentDetails = `رقم الحوالة/العملية المرجعي: ${paymentRefId || 'غير مدخل'}`;
    } else {
      paymentDetails = 'الدفع نقداً عند استلام الشحنة من المندوب';
    }

    onPlaceOrder({
      name: name.trim(),
      phone: phone.trim(),
      address: fullAddress,
      paymentMethod,
      paymentDetails,
    });

    setGeneratedOrderId(ordId);
    setOrderPlaced(true);
  };

  const provinces = ['صنعاء', 'عدن', 'تعز', 'حضرموت', 'إب', 'الحديدة', 'مأرب', 'ذمار', 'عمران', 'شبوة'];

  return (
    <div id="checkout-modal-overlay" className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl relative border border-zinc-100 flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="bg-zinc-950 text-white p-5 flex justify-between items-center border-b border-amber-500/20">
          <h3 className="font-bold text-sm flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-amber-400" />
            <span>إتمام طلب الشراء والدفع</span>
          </h3>
          {!orderPlaced && (
            <button
              id="btn-close-checkout"
              onClick={onClose}
              className="p-1 rounded-full hover:bg-zinc-800 text-zinc-400 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        <div className="overflow-y-auto p-6 md:p-8">
          <AnimatePresence mode="wait">
            {!orderPlaced ? (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Column 1: Customer Details */}
                  <div className="space-y-4">
                    <h4 className="font-bold text-zinc-800 text-xs flex items-center gap-1.5 border-b border-zinc-100 pb-2">
                      <UserIcon className="w-4 h-4 text-amber-500" />
                      <span>بيانات الشحن والتوصيل</span>
                    </h4>

                    <div>
                      <label className="text-[11px] font-bold text-zinc-500 block mb-1">اسم المستلم الكامل *</label>
                      <input
                        type="text"
                        required
                        placeholder="مثال: أحمد عبد الله اليماني"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-zinc-200 focus:border-amber-500 focus:outline-none bg-zinc-50 focus:bg-white"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-bold text-zinc-500 block mb-1">رقم الهاتف النشط (واتساب) *</label>
                      <input
                        type="tel"
                        required
                        placeholder="مثال: 777123456"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-zinc-200 focus:border-amber-500 focus:outline-none bg-zinc-50 focus:bg-white text-left font-mono"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[11px] font-bold text-zinc-500 block mb-1">المحافظة *</label>
                        <select
                          value={province}
                          onChange={(e) => setProvince(e.target.value)}
                          className="w-full text-xs px-3 py-2.5 rounded-xl border border-zinc-200 focus:border-amber-500 focus:outline-none bg-zinc-50 cursor-pointer"
                        >
                          {provinces.map((prov) => (
                            <option key={prov} value={prov}>
                              {prov}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="text-[11px] font-bold text-zinc-500 block mb-1">الحي / الشارع *</label>
                        <input
                          type="text"
                          required
                          placeholder="مثال: شارع الخمسين"
                          value={addressDetails}
                          onChange={(e) => setAddressDetails(e.target.value)}
                          className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-zinc-200 focus:border-amber-500 focus:outline-none bg-zinc-50 focus:bg-white"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Column 2: Payment Gateways */}
                  <div className="space-y-4">
                    <h4 className="font-bold text-zinc-800 text-xs flex items-center gap-1.5 border-b border-zinc-100 pb-2">
                      <Receipt className="w-4 h-4 text-amber-500" />
                      <span>اختر طريقة الدفع المناسبة</span>
                    </h4>

                    <div className="grid grid-cols-2 gap-2.5">
                      {/* COD */}
                      <div
                        onClick={() => setPaymentMethod('cod')}
                        className={`border rounded-2xl p-3 cursor-pointer transition-all flex flex-col items-center justify-center text-center gap-1.5 ${
                          paymentMethod === 'cod'
                            ? 'border-amber-500 bg-amber-500/5 font-bold'
                            : 'border-zinc-200 hover:border-zinc-300'
                        }`}
                      >
                        <span className="text-sm">💵</span>
                        <span className="text-[11px] text-zinc-800 block">عند الاستلام</span>
                      </div>

                      {/* Kuraimi */}
                      <div
                        onClick={() => setPaymentMethod('kuraimi')}
                        className={`border rounded-2xl p-3 cursor-pointer transition-all flex flex-col items-center justify-center text-center gap-1.5 ${
                          paymentMethod === 'kuraimi'
                            ? 'border-amber-500 bg-amber-500/5 font-bold'
                            : 'border-zinc-200 hover:border-zinc-300'
                        }`}
                      >
                        <span className="text-sm">🏦</span>
                        <span className="text-[11px] text-zinc-800 block">الكريمي</span>
                      </div>

                      {/* Jeeb */}
                      <div
                        onClick={() => setPaymentMethod('jeeb')}
                        className={`border rounded-2xl p-3 cursor-pointer transition-all flex flex-col items-center justify-center text-center gap-1.5 ${
                          paymentMethod === 'jeeb'
                            ? 'border-amber-500 bg-amber-500/5 font-bold'
                            : 'border-zinc-200 hover:border-zinc-300'
                        }`}
                      >
                        <span className="text-sm">📱</span>
                        <span className="text-[11px] text-zinc-800 block">محفظة جيب</span>
                      </div>

                      {/* Bank Transfer */}
                      <div
                        onClick={() => setPaymentMethod('bank_transfer')}
                        className={`border rounded-2xl p-3 cursor-pointer transition-all flex flex-col items-center justify-center text-center gap-1.5 ${
                          paymentMethod === 'bank_transfer'
                            ? 'border-amber-500 bg-amber-500/5 font-bold'
                            : 'border-zinc-200 hover:border-zinc-300'
                        }`}
                      >
                        <span className="text-sm">💳</span>
                        <span className="text-[11px] text-zinc-800 block">تحويل بنكي</span>
                      </div>
                    </div>

                    {/* Payment Instruction Screen */}
                    <div className="bg-zinc-50 p-3 rounded-2xl border border-zinc-100 text-[10.5px] text-zinc-600 leading-relaxed space-y-2">
                      {paymentMethod === 'cod' && (
                        <p>💡 سيقوم مندوب التوصيل بالاتصال بك فور تجهيز الطلب. يرجى تجهيز المبلغ نقداً عند تسليم البضاعة.</p>
                      )}

                      {paymentMethod === 'kuraimi' && (
                        <div className="space-y-1">
                          <p className="font-bold text-zinc-800 text-xs">🏦 تعليمات بنك الكريمي:</p>
                          <p>يرجى إرسال حوالة مصرفية أو إيداع إلى الحساب التالي:</p>
                          <p className="font-bold text-zinc-900 font-mono">رقم الحساب: 3004561239</p>
                          <p className="font-bold text-zinc-900">باسم: مها أحمد محمد الصنعاني</p>
                          <p className="text-red-500">ثم أدخل الرقم المرجعي للحوالة بالأسفل لإتمام الحجز.</p>
                        </div>
                      )}

                      {paymentMethod === 'jeeb' && (
                        <div className="space-y-1">
                          <p className="font-bold text-zinc-800 text-xs">📱 تعليمات محفظة جيب (Jeeb):</p>
                          <p>يرجى تحويل مبلغ الفاتورة إلى حساب محفظة جيب التالي:</p>
                          <p className="font-bold text-zinc-900 font-mono">رقم الحساب: 777123456</p>
                          <p className="font-bold text-zinc-900">باسم: متجر مها للتجارة الإلكترونية</p>
                          <p className="text-red-500">ثم أدخل رمز العملية المرجعي بالأسفل.</p>
                        </div>
                      )}

                      {paymentMethod === 'bank_transfer' && (
                        <div className="space-y-1">
                          <p className="font-bold text-zinc-800 text-xs">💳 تعليمات التحويل البنكي:</p>
                          <p>يمكنك التحويل لبنك التضامن الإسلامي عبر رقم الحساب:</p>
                          <p className="font-bold text-zinc-900 font-mono">IBAN: YE7702200000003001827</p>
                          <p className="font-bold text-zinc-900">باسم: مؤسسة مها أحمد التجارية</p>
                          <p className="text-red-500">ثم أدخل رقم مستند التحويل المصرفي بالأسفل.</p>
                        </div>
                      )}
                    </div>

                    {paymentMethod !== 'cod' && (
                      <div>
                        <label className="text-[11px] font-bold text-zinc-500 block mb-1">الرقم المرجعي للحوالة / الإيداع *</label>
                        <input
                          type="text"
                          required
                          placeholder="أدخل رقم الإشعار المالي المكون من 8-10 أرقام"
                          value={paymentRefId}
                          onChange={(e) => setPaymentRefId(e.target.value)}
                          className="w-full text-xs px-3 py-2.5 rounded-xl border border-zinc-200 focus:border-amber-500 focus:outline-none font-mono"
                        />
                      </div>
                    )}
                  </div>
                </div>

                {/* Bill Summary Block */}
                <div className="bg-zinc-900 text-zinc-300 p-4 rounded-2xl flex justify-between items-center">
                  <div>
                    <span className="text-[10px] text-zinc-400 block">إجمالي الفاتورة النهائية للطلب</span>
                    <span className="text-lg font-black font-mono text-amber-400">{finalTotal.toLocaleString()} ريال يمني</span>
                  </div>
                  <div className="text-left text-xs text-zinc-400">
                    <span>عدد السلع: {cartItems.reduce((acc, i) => acc + i.quantity, 0)} قطع</span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={onClose}
                    className="flex-1 border border-zinc-200 hover:border-zinc-300 text-zinc-700 font-bold py-3 px-4 rounded-xl text-xs transition-colors cursor-pointer"
                  >
                    تراجع
                  </button>
                  <button
                    id="btn-confirm-order-placement"
                    type="submit"
                    className="flex-1 bg-amber-500 hover:bg-amber-600 text-zinc-950 font-black py-3 px-4 rounded-xl text-xs transition-colors shadow-lg shadow-amber-500/10"
                  >
                    تأكيد وإرسال الطلب للبائعين
                  </button>
                </div>
              </form>
            ) : (
              /* Order Placed Success View */
              <div className="text-center py-10 space-y-6">
                <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-600 mx-auto">
                  <CheckCircle className="w-12 h-12" />
                </div>

                <div className="space-y-2">
                  <h4 className="font-extrabold text-xl text-zinc-900">مبارك! تم تسجيل طلبك بنجاح 💐</h4>
                  <p className="text-zinc-500 text-xs max-w-md mx-auto leading-relaxed">
                    تم إرسال تفاصيل طلبك مباشرة إلى لوحات تحكم البائعين المعنيين للبدء بتجهيز طلبك وتوصيله إليك في أسرع وقت.
                  </p>
                </div>

                {/* Details Invoice Card */}
                <div className="bg-zinc-50 p-5 rounded-2xl border border-zinc-100 max-w-md mx-auto space-y-3.5 text-xs text-zinc-600 text-right">
                  <div className="flex justify-between items-center border-b border-zinc-200/60 pb-2">
                    <span className="font-bold text-zinc-800">رقم الطلب الفريد:</span>
                    <span className="font-bold font-mono text-zinc-950 text-sm">{generatedOrderId}</span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span>المستلم:</span>
                    <span className="font-bold text-zinc-900">{name}</span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span>رقم الهاتف:</span>
                    <span className="font-mono text-zinc-950 font-bold">{phone}</span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span>العنوان:</span>
                    <span className="font-bold text-zinc-900">{province} - {addressDetails}</span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span>طريقة الدفع:</span>
                    <span className="bg-amber-500/10 text-amber-700 px-2 py-0.5 rounded font-bold">
                      {paymentMethod === 'cod' && 'الدفع عند الاستلام'}
                      {paymentMethod === 'kuraimi' && 'تحويل بنك الكريمي'}
                      {paymentMethod === 'jeeb' && 'محفظة جيب الإلكترونية'}
                      {paymentMethod === 'bank_transfer' && 'تحويل مصرفي'}
                    </span>
                  </div>

                  <div className="flex justify-between items-center border-t border-zinc-200/60 pt-2 text-zinc-900 font-extrabold">
                    <span>المبلغ الإجمالي المدفوع:</span>
                    <span className="font-mono text-amber-600 text-sm">{finalTotal.toLocaleString()} ر.ي</span>
                  </div>
                </div>

                <div className="flex justify-center pt-4">
                  <button
                    id="btn-finish-checkout-success"
                    onClick={onClose}
                    className="bg-zinc-950 hover:bg-zinc-900 text-white font-bold py-3 px-8 rounded-xl text-xs transition-colors cursor-pointer shadow-md"
                  >
                    العودة للتسوق
                  </button>
                </div>
              </div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
}
