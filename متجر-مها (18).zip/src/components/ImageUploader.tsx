import React, { useState, useRef } from 'react';
import { Upload, X, Image as ImageIcon } from 'lucide-react';

interface ImageUploaderProps {
  value: string;
  onChange: (value: string) => void;
  label?: string;
  placeholderUrl?: string;
}

export default function ImageUploader({ value, onChange, label, placeholderUrl }: ImageUploaderProps) {
  const [isDragActive, setIsDragActive] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFile = (file: File) => {
    setError(null);
    if (!file.type.startsWith('image/')) {
      setError('يرجى اختيار ملف صورة صالح (PNG, JPG, JPEG, WEBP)');
      return;
    }

    // Limit to 2.5MB to prevent huge localStorage consumption
    if (file.size > 2.5 * 1024 * 1024) {
      setError('حجم الصورة كبير جداً، يرجى اختيار صورة أقل من 2.5 ميجابايت لضمان سرعة التحميل');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target?.result && typeof e.target.result === 'string') {
        onChange(e.target.result);
      }
    };
    reader.onerror = () => {
      setError('حدث خطأ أثناء قراءة الملف، يرجى المحاولة مرة أخرى');
    };
    reader.readAsDataURL(file);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setIsDragActive(true);
    } else if (e.type === 'dragleave') {
      setIsDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const clearImage = () => {
    onChange('');
    setError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  const isBase64 = value && value.startsWith('data:image/');

  return (
    <div className="space-y-1.5 text-right font-sans" dir="rtl">
      {label && <label className="text-[10px] text-zinc-400 font-bold block">{label}</label>}
      
      <div
        onDragEnter={handleDrag}
        onDragOver={handleDrag}
        onDragLeave={handleDrag}
        onDrop={handleDrop}
        onClick={!value ? triggerFileInput : undefined}
        className={`relative rounded-2xl border-2 border-dashed transition-all p-4 flex flex-col items-center justify-center text-center cursor-pointer min-h-[140px] ${
          isDragActive
            ? 'border-amber-500 bg-amber-50/40'
            : value
            ? 'border-zinc-200 bg-zinc-50/50 hover:bg-zinc-50'
            : 'border-zinc-200 hover:border-zinc-300 bg-zinc-50/20 hover:bg-zinc-50/40'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileInputChange}
          className="hidden"
        />

        {value ? (
          <div className="w-full flex flex-col sm:flex-row items-center gap-4">
            <div className="relative w-24 h-24 rounded-xl overflow-hidden border border-zinc-150 bg-white flex-shrink-0 group">
              <img
                src={value}
                alt="معاينة الصورة"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  clearImage();
                }}
                className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 transition-colors shadow"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
            <div className="flex-grow text-right space-y-1">
              <span className="text-[11px] font-bold text-zinc-700 block">تم تحميل الصورة بنجاح 🎉</span>
              <p className="text-[9.5px] text-zinc-400 break-all leading-normal max-w-xs font-mono">
                {isBase64 ? 'صورة مرفوعة من الجهاز (Base64 Data)' : value}
              </p>
              <div className="flex gap-2 pt-1.5">
                <button
                  type="button"
                  onClick={triggerFileInput}
                  className="text-[9.5px] font-bold text-amber-600 hover:text-amber-700 underline"
                >
                  تغيير الصورة
                </button>
                <button
                  type="button"
                  onClick={clearImage}
                  className="text-[9.5px] font-bold text-red-500 hover:text-red-600 underline"
                >
                  حذف الصورة
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-2 py-3 flex flex-col items-center">
            <div className="w-10 h-10 rounded-full bg-amber-500/10 flex items-center justify-center text-amber-600">
              <Upload className="w-5 h-5" />
            </div>
            <div className="space-y-0.5">
              <span className="text-xs font-extrabold text-zinc-800 block">اسحب وأفلت الصورة هنا، أو انقر للتصفح</span>
              <span className="text-[9.5px] text-zinc-400 block">يدعم صيغ PNG, JPG, WEBP بحد أقصى 2.5 ميجابايت</span>
            </div>
            {placeholderUrl && (
              <span className="text-[9px] text-zinc-400 block bg-zinc-100 px-2 py-0.5 rounded-full font-mono">
                سيتم استخدام الصورة الافتراضية إذا تُرِكت فارغة
              </span>
            )}
          </div>
        )}

        {error && (
          <div className="absolute bottom-2 left-2 right-2 bg-red-50 text-red-600 p-1.5 rounded-xl text-[10px] font-bold border border-red-100 text-center animate-fade-in">
            ⚠️ {error}
          </div>
        )}
      </div>
    </div>
  );
}
