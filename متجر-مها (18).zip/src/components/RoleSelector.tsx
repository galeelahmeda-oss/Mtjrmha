import React from 'react';
import { Store, User, Shield, Bell, Briefcase } from 'lucide-react';
import { UserRole, Employee } from '../types';

interface RoleSelectorProps {
  currentRole: UserRole;
  onChangeRole: (role: UserRole) => void;
  notificationsCount: number;
  onOpenNotifications: () => void;
  activeVendorName?: string;
  employees: Employee[];
  activeEmployeeId: string;
  onChangeEmployeeId: (id: string) => void;
  userRole?: UserRole | null;
  androidAppLink?: string;
  iphoneAppLink?: string;
}

export default function RoleSelector({
  currentRole,
  onChangeRole,
  notificationsCount,
  onOpenNotifications,
  activeVendorName = 'بوتيك مها للأناقة',
  employees,
  activeEmployeeId,
  onChangeEmployeeId,
  userRole,
  androidAppLink = '',
  iphoneAppLink = '',
}: RoleSelectorProps) {
  const activeEmpObj = employees.find(e => e.id === activeEmployeeId);

  return (
    <div id="role-selector-container" className="bg-zinc-950 text-white border-b border-amber-500/20 py-2.5 px-4 sticky top-0 z-50 shadow-md">
      <div className="max-w-7xl mx-auto flex flex-col justify-between gap-3">
        {/* Main Header Bar */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-3 w-full">
          {/* Logo / Title */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-500 via-yellow-400 to-amber-600 flex items-center justify-center shadow-lg shadow-amber-500/10">
              <span className="text-zinc-950 font-bold text-lg font-sans">م</span>
            </div>
            <div>
              <h1 className="text-lg font-bold font-sans tracking-wide flex items-center gap-1.5 text-right">
                متجر مَهَا <span className="text-xs px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 font-normal border border-amber-500/30">سلة اليمن</span>
              </h1>
              <p className="text-[10px] text-zinc-400 text-right">تسوّق بأمان • أرقى تشكيلات الأزياء والجمال • دفع سهل وسريع</p>
            </div>
          </div>

          {/* Roles Switcher */}
          <div className="flex items-center bg-zinc-900 rounded-full p-1 border border-zinc-800 flex-wrap justify-center gap-0.5">
            <button
              id="role-btn-customer"
              onClick={() => onChangeRole('customer')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-300 cursor-pointer ${
                currentRole === 'customer'
                  ? 'bg-amber-500 text-zinc-950 shadow-md font-bold'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              <span>واجهة المشتري</span>
            </button>

            {/* Render Employee panel button only if userRole is admin or employee */}
            {(userRole === 'admin' || userRole === 'employee') && (
              <button
                id="role-btn-employee"
                onClick={() => onChangeRole('employee')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-300 cursor-pointer ${
                  currentRole === 'employee'
                    ? 'bg-amber-500 text-zinc-950 shadow-md font-bold'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                <Briefcase className="w-3.5 h-3.5" />
                <span>لوحة الموظف</span>
              </button>
            )}

            {/* Render Admin panel button only if userRole is admin */}
            {userRole === 'admin' && (
              <button
                id="role-btn-admin"
                onClick={() => onChangeRole('admin')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-300 cursor-pointer ${
                  currentRole === 'admin'
                    ? 'bg-amber-500 text-zinc-950 shadow-md font-bold'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                <Shield className="w-3.5 h-3.5" />
                <span>المدير الرئيسي</span>
              </button>
            )}
          </div>

          {/* Right Actions & Badge */}
          <div className="flex items-center gap-3">
            {/* Notifications */}
            <button
              id="btn-notifications-toggle"
              onClick={onOpenNotifications}
              className="relative p-2 rounded-full bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 transition-colors cursor-pointer text-amber-400"
            >
              <Bell className="w-4 h-4" />
              {notificationsCount > 0 && (
                <span className="absolute -top-1 -left-1 w-4 h-4 bg-red-500 text-white text-[9px] rounded-full flex items-center justify-center font-bold font-mono">
                  {notificationsCount}
                </span>
              )}
            </button>

            {/* Quick Context Indicator */}
            <div className="hidden lg:flex flex-col text-right border-r border-zinc-800 pr-3 mr-1">
              <span className="text-[10px] text-zinc-400">الحساب النشط</span>
              <span className="text-xs font-bold text-amber-400">
                {currentRole === 'customer' && 'مشتري زائر'}
                {currentRole === 'employee' && `موظف: ${activeEmpObj?.name || 'مساعد'}`}
                {currentRole === 'admin' && 'المدير الرئيسي لمتجر مها'}
              </span>
            </div>
          </div>
        </div>

        {/* Employee Sub-Bar Selection */}
        {currentRole === 'employee' && (
          <div className="mt-1 pt-2.5 border-t border-zinc-800 flex flex-wrap items-center justify-center md:justify-start gap-2 text-xs w-full">
            <span className="text-zinc-400 font-bold flex items-center gap-1">
              <Briefcase className="w-3.5 h-3.5 text-amber-400" />
              <span>اختر ملف الموظف للمحاكاة:</span>
            </span>
            <div className="flex flex-wrap gap-1.5">
              {employees.map((emp) => {
                const getLabel = (p: string) => {
                  if (p === 'products') return 'إدارة المنتجات';
                  if (p === 'orders') return 'إدارة الطلبات';
                  if (p === 'customers') return 'خدمة العملاء';
                  return 'التسويق والكوبونات';
                };
                return (
                  <button
                    key={emp.id}
                    onClick={() => onChangeEmployeeId(emp.id)}
                    className={`px-3 py-1 rounded-lg font-bold text-[10.5px] transition-all cursor-pointer ${
                      activeEmployeeId === emp.id
                        ? 'bg-amber-500 text-zinc-950 shadow-sm'
                        : 'bg-zinc-900 text-zinc-300 hover:bg-zinc-850'
                    }`}
                  >
                    {emp.name} • <span className="opacity-80">{getLabel(emp.permission)}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
